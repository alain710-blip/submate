<?php
// Naver Search API 키를 넣으면 실시간 한국영화(개봉/예정) 검색 품질이 향상됩니다.
// 없으면 TMDB 기반 fallback 데이터로 자동 표시됩니다.
if (!defined('NAVER_CLIENT_ID')) {
    define('NAVER_CLIENT_ID', '');
}
if (!defined('NAVER_CLIENT_SECRET')) {
    define('NAVER_CLIENT_SECRET', '');
}
