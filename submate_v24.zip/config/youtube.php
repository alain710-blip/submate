<?php
define('YOUTUBE_API_KEY', 'AIzaSyAKV_l9x4vjAJaryFZ49TNMce5jHjo-fZ8');
