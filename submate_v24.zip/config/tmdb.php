<?php
define('TMDB_API_KEY', '7448f692397f064db6d5f366592dcafc');
define('TMDB_TOKEN', 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3NDQ4ZjY5MjM5N2YwNjRkYjZkNWYzNjY1OTJkY2FmYyIsIm5iZiI6MTczODkxNjcyMS42NDksInN1YiI6IjY3YTU0MjExMGE1NjdkNzFiNTBhNjE0MyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.fqKDFMBiHiJth-MzlsUclOEFEREsRmFHRNaIZmMNvPE');
define('TMDB_IMG', 'https://image.tmdb.org/t/p/w500');
define('TMDB_IMG_BG', 'https://image.tmdb.org/t/p/w1280');
define('SITE_NAME', 'SubMate PRO');
define('SITE_URL', '');
