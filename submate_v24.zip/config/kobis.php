<?php
// 한국영상자료원 (KMDb) API
if (!defined('KMDB_API_KEY')) define('KMDB_API_KEY', 'G39ZV6V4Z4J36H17N77N');

// KOBIS 영화관입장권 통합전산망 (박스오피스)
if (!defined('KOBIS_API_KEY')) define('KOBIS_API_KEY', '07c478c543d65d398b80edf27276e75e');

// SportDB / FlashScore API
if (!defined('SPORTDB_API_KEY')) define('SPORTDB_API_KEY', 'atklcjTaQHFLNYuGLxgDe7vS1C1g7STosWsYaAtD');

// RapidAPI (ESPN, FlashScore)
if (!defined('RAPIDAPI_KEY')) define('RAPIDAPI_KEY', 'f013e2257bmsh4a35e1aaba04b7ap1c3183jsn70c03b0a4084');

// Yahoo Sports
if (!defined('YAHOO_APP_ID')) define('YAHOO_APP_ID', 'ICms7dYf');
if (!defined('YAHOO_CLIENT_ID')) define('YAHOO_CLIENT_ID', 'dj0yJmk9WXB2azVYYmpxWU05JmQ9WVdrOVNVTnRjemRrV1dZbWNHbzlNQT09JnM9Y29uc3VtZXJzZWNyZXQmc3Y9MCZ4PTlk');
