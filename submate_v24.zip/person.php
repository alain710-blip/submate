<?php
if (!function_exists('sm_trim_text')) {
  function sm_trim_text($text, $width=100){
    $text=(string)$text;
    if (function_exists('mb_strimwidth')) return mb_strimwidth($text,0,$width,'...','UTF-8');
    return (strlen($text)>$width)?substr($text,0,$width).'...':$text;
  }
}
ini_set("display_errors", 1); error_reporting(E_ALL);
$page_title = '출연자 정보'; require_once 'includes/header.php';
$pid = (int)($_GET['id'] ?? 0);
if (!$pid) { echo '<div class="sm-panel">잘못된 접근</div>'; require_once 'includes/footer.php'; exit; }
$p = tmdb_cache("person_{$pid}", 7200, function() use($pid) { return tmdb_req("person/{$pid}", ["append_to_response"=>"combined_credits"]); });
$name = $p['name'] ?? ''; $bio = $p['biography'] ?? '';
$credits = $p['combined_credits']['cast'] ?? [];
usort($credits, function($a,$b) { return ($b['popularity']??0) <=> ($a['popularity']??0); });
?>
<div style="display:grid;grid-template-columns:250px 1fr;gap:24px;margin-bottom:20px">
<div><?php if($p['profile_path']??''): ?><img src="<?php echo TMDB_IMG . $p['profile_path']; ?>" style="width:100%;border-radius:18px"><?php endif; ?></div>
<div>
<h1 style="font-size:26px;font-weight:900;margin-bottom:8px"><?php echo htmlspecialchars($name); ?></h1>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
<?php if($p['birthday']??''): ?><span class="sm-badge">🎂 <?php echo $p['birthday']; ?></span><?php endif; ?>
<?php if($p['place_of_birth']??''): ?><span class="sm-badge">📍 <?php echo htmlspecialchars($p['place_of_birth']); ?></span><?php endif; ?>
<?php if($p['known_for_department']??''): ?><span class="sm-badge">🎬 <?php echo htmlspecialchars($p['known_for_department']); ?></span><?php endif; ?>
</div>
<?php if($bio): ?><p style="color:var(--muted);line-height:1.8;font-size:14px"><?php echo nl2br(htmlspecialchars(sm_trim_text($bio, 600))); ?></p><?php endif; ?>
</div></div>

<?php if($credits): ?>
<div class="sm-section-header"><h2>🎬 출연 작품 (<?php echo count($credits); ?>)</h2></div>
<div class="sm-scroll-row"><?php foreach(array_slice($credits, 0, 20) as $m): $mt = $m['media_type'] ?? 'movie'; ?>
<div class="sm-card"><a href="movie.php?id=<?php echo (int)$m['id']; ?>&media=<?php echo $mt; ?>">
<?php if($m['poster_path']??''): ?><img class="sm-poster" src="<?php echo TMDB_IMG . $m['poster_path']; ?>" loading="lazy"><?php else: ?><div style="height:200px;background:var(--panel);display:flex;align-items:center;justify-content:center;color:var(--muted)">🎬</div><?php endif; ?>
<div class="sm-card-body"><div class="sm-card-title"><?php echo htmlspecialchars($m['title']??($m['name']??'')); ?></div><div class="sm-card-meta"><span><?php echo htmlspecialchars($m['character']??''); ?></span></div></div></a></div>
<?php endforeach; ?></div>
<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
