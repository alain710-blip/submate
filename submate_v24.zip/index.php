<?php
ini_set("display_errors",1); error_reporting(E_ALL);
$page_title = 'SubMate PRO - OTT 구독관리 플랫폼';
require_once 'includes/header.php';
require_once 'includes/subscriptions.php';
require_once 'includes/reviews.php';
if (file_exists(__DIR__ . '/config/youtube.php')) { require_once __DIR__ . '/config/youtube.php'; }

$platforms = sm_platforms();
$tr_movie = @tmdb_trending('movie') ?: [];
$tr_tv = @tmdb_trending('tv') ?: [];
$now_play = @tmdb_now_playing() ?: [];
$upcoming_data = @tmdb_upcoming() ?: [];
$top_tv = @tmdb_top_tv() ?: [];
$kr_movies = @tmdb_kr_movies() ?: [];
$kr_dramas = @tmdb_kr_dramas() ?: [];
$kr_variety = @tmdb_discover('tv', ["with_original_language"=>"ko","with_genres"=>"10764","sort_by"=>"popularity.desc"]) ?: [];
$yt_data = @youtube_trending(8) ?: [];
$events = get_ott_events();
$kr_2026 = @sm_kr_theatrical_trending(20) ?: ['results'=>[]];

$memberPrefRaw = read_json('ott_subscribers.json');
$memberPrefDefault = ['넷플릭스'=>42,'티빙'=>18,'웨이브'=>12,'디즈니+'=>10,'왓챠'=>6,'쿠팡플레이'=>5,'Apple TV+'=>4,'Prime Video'=>3];
$memberPref = !empty($memberPrefRaw) && is_array($memberPrefRaw) ? $memberPrefRaw : $memberPrefDefault;
$ottTotal = ['넷플릭스'=>1300,'티빙'=>500,'웨이브'=>400,'디즈니+'=>450,'왓챠'=>250,'쿠팡플레이'=>600,'Apple TV+'=>200,'Prime Video'=>350];
$pieColors = ['넷플릭스'=>'#E50914','티빙'=>'#FF0000','웨이브'=>'#00C8FF','디즈니+'=>'#113CCF','왓챠'=>'#FF0066','쿠팡플레이'=>'#ff7a00','Apple TV+'=>'#0A84FF','Prime Video'=>'#00A8E1'];

function sm_pie_gradient($data, $colors) {
    $sum = max(1, array_sum($data)); $segs = []; $pos = 0;
    foreach ($data as $n => $v) {
        $pct = $v / $sum * 100; $c = $colors[$n] ?? '#94a3b8';
        $segs[] = "{$c} {$pos}% " . ($pos + $pct) . "%";
        $pos += $pct;
    }
    return 'conic-gradient(' . implode(', ', $segs) . ')';
}
$memberPie = sm_pie_gradient($memberPref, $pieColors);
$totalPie = sm_pie_gradient($ottTotal, $pieColors);
$heroSlides = array_slice($tr_movie['results'] ?? [], 0, 10);

// --- 그리드+더보기 렌더링 ---
function render_grid_section($items, $media, $titleKey, $sectionId, $initCount=10, $showRank=true) {
    if (empty($items)) { echo '<div style="text-align:center;padding:20px;color:var(--muted)">데이터를 불러올 수 없습니다.</div>'; return; }
    echo '<div class="sm-grid-wrap" id="'.$sectionId.'">';
    foreach ($items as $i => $m) {
        $hidden = ($i >= $initCount) ? ' style="display:none"' : '';
        $id = (int)($m['id']??0);
        $poster = TMDB_IMG . ($m['poster_path']??'');
        $title = htmlspecialchars($m[$titleKey] ?? ($m['title'] ?? ($m['name'] ?? '')));
        $vote = $m['vote_average'] ?? '';
        $rank = $showRank ? '<span class="sm-rank">'.($i+1).'</span>' : '';
        echo '<div class="sm-grid-item" data-idx="'.$i.'"'.$hidden.'>';
        echo '<div class="sm-card sm-grid-card"><a href="movie.php?id='.$id.'&media='.$media.'"><div style="position:relative;overflow:hidden;border-radius:14px"><img class="sm-poster" src="'.$poster.'" loading="lazy">'.$rank.'</div><div class="sm-card-body"><div class="sm-card-title">'.$title.'</div><div class="sm-card-meta"><span>⭐ '.$vote.'</span></div></div></a></div>';
        echo '</div>';
    }
    echo '</div>';
    if (count($items) > $initCount) {
        echo '<div class="sm-more-wrap" id="'.$sectionId.'More"><button class="sm-btn sm-btn-sm" onclick="smMore(\''.$sectionId.'\',10)" style="margin:8px auto;display:block">더보기 ▼</button></div>';
    }
}
?>

<!-- 소개 -->
<div style="text-align:center;padding:30px 16px 20px">
  <img src="images/submatelogo/submatelogo.png" alt="SubMate" height="48" style="margin:0 auto 12px;display:block;max-width:200px;border-radius:12px;background:rgba(10,14,26,.9);padding:6px 18px">
  <h1 style="font-size:clamp(20px,4vw,30px);font-weight:900;line-height:1.3">당신의 <span style="color:var(--accent)">모든 구독</span>을 한 곳에서</h1>
  <p style="color:var(--muted);font-size:clamp(12px,2.5vw,15px);margin-top:8px">넷플릭스·티빙·웨이브·디즈니+ 등 9개 OTT 비교 · 구독관리 · 콘텐츠 검색</p>
  <div style="display:flex;gap:8px;justify-content:center;margin-top:14px;flex-wrap:wrap">
    <a href="search.php" class="sm-btn sm-btn-primary sm-btn-sm">🔍 콘텐츠 검색</a>
    <a href="match.php" class="sm-btn sm-btn-sm">🎯 OTT 매칭</a>
    <a href="mypage.php" class="sm-btn sm-btn-sm">💳 구독관리</a>
  </div>
</div>

<!-- OTT 로고 배너 -->
<div style="display:flex;gap:10px;justify-content:center;align-items:center;margin-bottom:20px;flex-wrap:wrap;padding:0 8px">
<?php
$ott_logos = [
  ['n'=>'넷플릭스','u'=>'https://www.netflix.com'],
  ['n'=>'티빙','u'=>'https://www.tving.com'],
  ['n'=>'웨이브','u'=>'https://www.wavve.com'],
  ['n'=>'왓챠','u'=>'https://watcha.com'],
  ['n'=>'디즈니+','u'=>'https://www.disneyplus.com'],
  ['n'=>'Apple TV+','u'=>'https://tv.apple.com'],
  ['n'=>'Prime Video','u'=>'https://www.primevideo.com'],
  ['n'=>'쿠팡플레이','u'=>'https://www.coupangplay.com'],
  ['n'=>'유튜브 프리미엄','u'=>'https://www.youtube.com/premium'],
];
foreach($ott_logos as $o): $logo_url = sm_ott_logo($o['n']); ?>
<a href="<?php echo $o['u']; ?>" target="_blank" style="display:flex;align-items:center;gap:6px;padding:6px 10px;border:1px solid var(--stroke);border-radius:10px;background:var(--panel)">
<img src="<?php echo $logo_url; ?>" style="width:28px;height:28px;border-radius:6px;object-fit:cover">
<span style="font-weight:700;font-size:11px;white-space:nowrap"><?php echo $o['n']; ?></span></a>
<?php endforeach; ?>
</div>

<!-- 기능 카드 -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px">
<div class="sm-panel" style="text-align:center;padding:16px"><div style="font-size:24px">📡</div><div style="font-weight:900;font-size:13px;margin-top:4px">OTT 비교</div></div>
<div class="sm-panel" style="text-align:center;padding:16px"><div style="font-size:24px">💳</div><div style="font-weight:900;font-size:13px;margin-top:4px">구독 관리</div></div>
<div class="sm-panel" style="text-align:center;padding:16px"><div style="font-size:24px">🎯</div><div style="font-weight:900;font-size:13px;margin-top:4px">AI 매칭</div></div>
<div class="sm-panel" style="text-align:center;padding:16px"><div style="font-size:24px">💬</div><div style="font-weight:900;font-size:13px;margin-top:4px">커뮤니티</div></div>
</div>

<!-- OTT 이벤트/할인 -->
<div class="sm-section-header"><h2>🎉 OTT 할인/이벤트</h2><a href="ott_info.php" style="font-size:11px;color:var(--accent)">전체보기 →</a></div>
<div class="sm-event-banner">
<?php foreach(array_slice($events, 0, 5) as $ev): ?>
<a href="<?php echo $ev['url']; ?>" target="_blank" class="sm-event-item">
<img src="<?php echo $ev['logo']; ?>" style="width:24px;height:24px;border-radius:6px">
<span style="color:<?php echo $ev['color']; ?>"><?php echo $ev['ott']; ?></span>
<span style="color:var(--muted)"><?php echo $ev['event']; ?></span>
<span class="sm-pill" style="color:var(--yellow)"><?php echo $ev['expire']; ?></span></a>
<?php endforeach; ?>
</div>

<!-- 히어로 캐러셀 -->
<?php if($heroSlides): ?>
<div class="sm-hero-carousel" id="heroCarousel">
  <button class="sm-hero-nav prev" onclick="smHero(-1)">‹</button>
  <button class="sm-hero-nav next" onclick="smHero(1)">›</button>
  <div class="sm-hero-track" id="heroTrack">
  <?php foreach($heroSlides as $i => $ft):
    $bd = TMDB_IMG_BG . ($ft['backdrop_path'] ?? '');
    $fp = @tmdb_kr_prov('movie', (int)$ft['id']) ?: ['has'=>false,'pn'=>[]];
  ?>
  <div class="sm-hero-slide">
    <div class="sm-hero-bg" style="background-image:url('<?php echo $bd; ?>')"></div>
    <div class="sm-hero-overlay"></div>
    <div class="sm-hero-content"><div class="sm-hero-info">
      <div class="sm-badge"><span class="dot"></span> 트렌딩 #<?php echo $i+1; ?></div>
      <div class="sm-hero-title"><?php echo htmlspecialchars($ft['title'] ?? ''); ?></div>
      <div class="sm-hero-desc"><?php echo htmlspecialchars(mb_strimwidth($ft['overview'] ?? '', 0, 120, '...')); ?></div>
      <div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap">
        <span class="sm-badge">⭐ <?php echo $ft['vote_average'] ?? '0'; ?></span>
        <?php if($fp['has']): foreach(array_slice($fp['pn'], 0, 2) as $pn): ?><span class="sm-pill"><?php echo htmlspecialchars($pn); ?></span><?php endforeach; endif; ?>
        <a class="sm-btn sm-btn-primary sm-btn-sm" href="movie.php?id=<?php echo (int)$ft['id']; ?>&media=movie">상세보기</a>
      </div>
    </div></div>
  </div>
  <?php endforeach; ?>
  </div>
  <div class="sm-hero-dots" id="heroDots"><?php for($i=0;$i<count($heroSlides);$i++): ?><span<?php echo $i===0?' class="active"':''; ?> onclick="smHeroTo(<?php echo $i; ?>)"></span><?php endfor; ?></div>
</div>
<?php endif; ?>

<!-- 파이차트 (컴팩트) -->
<div class="sm-pie-wrap" style="gap:10px">
  <div class="sm-pie-card" style="padding:12px"><h3 style="font-size:13px">👥 회원 선호 OTT</h3><div class="sm-pie" style="--pie: <?php echo $memberPie; ?>;width:120px"></div>
    <div class="sm-pie-legend"><?php $sum1=max(1,array_sum($memberPref)); foreach($memberPref as $n=>$v): $c=$pieColors[$n]??'#94a3b8'; ?>
      <div class="sm-pie-item" style="font-size:10px"><span class="dot" style="background:<?php echo $c; ?>;width:8px;height:8px"></span><b><?php echo $n; ?></b><strong><?php echo round($v/$sum1*100); ?>%</strong></div>
    <?php endforeach; ?></div></div>
  <div class="sm-pie-card" style="padding:12px"><h3 style="font-size:13px">📊 전체 OTT 구독자(만)</h3><div class="sm-pie" style="--pie: <?php echo $totalPie; ?>;width:120px"></div>
    <div class="sm-pie-legend"><?php $sum2=max(1,array_sum($ottTotal)); foreach($ottTotal as $n=>$v): $c=$pieColors[$n]??'#94a3b8'; ?>
      <div class="sm-pie-item" style="font-size:10px"><span class="dot" style="background:<?php echo $c; ?>;width:8px;height:8px"></span><b><?php echo $n; ?></b><strong><?php echo number_format($v); ?>만</strong></div>
    <?php endforeach; ?></div></div>
</div>

<!-- 트렌딩 영화/TV -->
<div class="sm-section-header"><h2>🔥 실시간 트렌딩</h2>
<div class="sm-toggle" id="trendToggle"><button class="active" onclick="smTT('m',this)">영화</button><button onclick="smTT('t',this)">TV</button></div></div>
<div id="smTM"><?php render_grid_section($tr_movie['results'] ?? [], 'movie', 'title', 'secTrM', 10); ?></div>
<div id="smTV" style="display:none"><?php render_grid_section($tr_tv['results'] ?? [], 'tv', 'name', 'secTrT', 10); ?></div>

<!-- 🎬 박스오피스 TOP 10 -->
<div class="sm-section-header"><h2>🎬 박스오피스 TOP 10</h2><a href="boxoffice.php" style="font-size:11px;color:var(--accent)">전체보기 →</a></div>
<?php
$daily_box_idx = @kobis_daily_boxoffice() ?: [];
if(!empty($daily_box_idx)):
?>
<div class="sm-panel" style="padding:0;overflow:hidden">
<?php foreach(array_slice($daily_box_idx,0,10) as $bm):
  $brank = (int)($bm['rank']??0);
  $btitle = $bm['movieNm']??'';
  $bopenDt = $bm['openDt']??'';
  $baudiAcc = (int)($bm['audiAcc']??0);
  $baudiDay = (int)($bm['audiCnt']??0);
  $bsalesAcc = (int)($bm['salesAcc']??0);
  $bisNew = ($bm['rankOldAndNew']??'')==='NEW';
  $baudiTxt = ($baudiAcc>=10000) ? number_format(round($baudiAcc/10000,1),1).'만' : number_format($baudiAcc);
  $bsalesTxt = ($bsalesAcc>0) ? number_format(round($bsalesAcc/100000000)).'억' : '';
  $brc = ($brank<=3) ? 'var(--accent)' : 'var(--text)';
  // TMDB 매칭
  $bsr = @tmdb_search($btitle, 'movie');
  $btmdb_id = 0; $bposter = '';
  if(!empty($bsr['results'])) { $btmdb_id=(int)$bsr['results'][0]['id']; $bposter=$bsr['results'][0]['poster_path']??''; }
  $blink = $btmdb_id ? "movie.php?id={$btmdb_id}&media=movie" : "boxoffice.php";
?>
<a href="<?php echo $blink; ?>" style="display:flex;align-items:center;gap:12px;padding:10px 14px;border-bottom:1px solid var(--stroke)">
<span style="font-weight:900;font-size:18px;color:<?php echo $brc; ?>;min-width:28px;text-align:center"><?php echo $brank; ?></span>
<?php if($bposter): ?><img src="<?php echo TMDB_IMG.$bposter; ?>" style="width:36px;height:52px;border-radius:4px;object-fit:cover"><?php endif; ?>
<div style="flex:1;min-width:0">
<div style="font-weight:800;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo htmlspecialchars($btitle); ?><?php if($bisNew): ?> <span style="color:var(--yellow);font-size:9px;font-weight:900">NEW</span><?php endif; ?></div>
<div style="font-size:10px;color:var(--muted)"><?php echo $bopenDt; ?> · 오늘 <?php echo number_format($baudiDay); ?>명</div>
</div>
<div style="text-align:right;flex-shrink:0">
<div style="font-weight:900;font-size:12px">👥 <?php echo $baudiTxt; ?></div>
<?php if($bsalesTxt): ?><div style="font-size:10px;color:var(--muted)">💰 <?php echo $bsalesTxt; ?></div><?php endif; ?>
</div>
</a>
<?php endforeach; ?>
</div>
<?php else: ?>
<div class="sm-panel" style="text-align:center;padding:20px;color:var(--muted)">박스오피스 데이터를 불러올 수 없습니다. <a href="boxoffice.php" style="color:var(--accent)">박스오피스 페이지 →</a></div>
<?php endif; ?>

<!-- 한국 인기 영화 -->
<div class="sm-section-header"><h2>🇰🇷 한국 인기 영화</h2></div>
<?php render_grid_section($kr_movies['results'] ?? [], 'movie', 'title', 'secKrM', 10); ?>

<!-- 한국 인기 예능/드라마 -->
<div class="sm-section-header"><h2>🇰🇷 한국 인기 예능/드라마</h2></div>
<?php
$kr_combined = array_merge($kr_dramas['results'] ?? [], $kr_variety['results'] ?? []);
$seen_ids = []; $kr_unique = [];
foreach ($kr_combined as $m) { $mid=(int)($m['id']??0); if($mid<=0||isset($seen_ids[$mid]))continue; $seen_ids[$mid]=true; $kr_unique[]=$m; }
usort($kr_unique, function($a,$b){return ($b['popularity']??0)<=>($a['popularity']??0);});
render_grid_section($kr_unique, 'tv', 'name', 'secKrTV', 10);
?>

<!-- 현재상영/예정/최고TV -->
<?php $sections = [
  ['t'=>'🎬 현재 상영작','d'=>$now_play,'m'=>'movie','k'=>'title','sid'=>'secNow'],
  ['t'=>'📅 개봉 예정','d'=>$upcoming_data,'m'=>'movie','k'=>'title','sid'=>'secUp'],
  ['t'=>'🏆 최고 평점 TV','d'=>$top_tv,'m'=>'tv','k'=>'name','sid'=>'secTop'],
];
foreach($sections as $sec): ?>
<div class="sm-section-header"><h2><?php echo $sec['t']; ?></h2></div>
<?php render_grid_section($sec['d']['results'] ?? [], $sec['m'], $sec['k'], $sec['sid'], 10); ?>
<?php endforeach; ?>

<!-- ═══ OTT 플랫폼별 인기 ═══ -->
<div class="sm-section-header"><h2>📡 OTT 플랫폼별 인기</h2></div>
<?php
$logoMap = []; foreach($platforms as $_p) $logoMap[$_p['n']] = sm_ott_logo($_p['n']);
?>
<div class="sm-slider" style="margin-bottom:10px">
<?php foreach($platforms as $i => $p): ?>
<div class="sm-slide" onclick="document.getElementById('smPl<?php echo $i; ?>').scrollIntoView({behavior:'smooth'})">
<img src="<?php echo $logoMap[$p['n']]??''; ?>" style="width:24px;height:24px;border-radius:6px;object-fit:cover">
<span style="font-weight:800;font-size:11px"><?php echo $p['n']; ?></span></div>
<?php endforeach; ?>
</div>

<?php foreach($platforms as $pi => $p):
  $pName = $p['n'];

  if ($pName === '유튜브 프리미엄'):
?>
<div id="smPl<?php echo $pi; ?>" style="scroll-margin-top:80px;margin-bottom:18px">
<?php if(!empty($yt_data['items'])): ?>
<div style="margin-bottom:6px"><span class="sm-badge"><span class="dot" style="background:<?php echo $p['c']; ?>"></span>▶️ 유튜브 프리미엄 인기 영상</span></div>
<div class="sm-grid-wrap" id="secYtApi">
<?php foreach($yt_data['items'] as $yi => $yt): $sn=$yt['snippet']??[]; $hidden=($yi>=10)?' style="display:none"':''; ?>
<div class="sm-grid-item" data-idx="<?php echo $yi; ?>"<?php echo $hidden; ?>>
<div class="sm-card sm-grid-card"><a href="https://www.youtube.com/watch?v=<?php echo $yt['id']; ?>" target="_blank">
<img style="width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:14px" src="<?php echo $sn['thumbnails']['medium']['url']??''; ?>" loading="lazy">
<div class="sm-card-body"><div class="sm-card-title"><?php echo htmlspecialchars(mb_strimwidth($sn['title']??'',0,40,'...')); ?></div>
<div class="sm-card-meta"><span><?php echo htmlspecialchars($sn['channelTitle']??''); ?></span></div></div></a></div></div>
<?php endforeach; ?>
</div>
<?php if(count($yt_data['items'])>10): ?>
<div class="sm-more-wrap" id="secYtApiMore"><button class="sm-btn sm-btn-sm" onclick="smMore('secYtApi',10)" style="margin:8px auto;display:block">더보기 ▼</button></div>
<?php endif; endif; ?>
<?php
  $ytm = @tmdb_discover('movie', ["with_watch_providers"=>$p['pid'],"watch_region"=>"KR","sort_by"=>"popularity.desc"]) ?: [];
  $ytt = @tmdb_discover('tv', ["with_watch_providers"=>$p['pid'],"watch_region"=>"KR","sort_by"=>"popularity.desc"]) ?: [];
  if(!empty($ytm['results'])): ?>
<div style="margin:6px 0"><span class="sm-badge"><span class="dot" style="background:<?php echo $p['c']; ?>"></span>▶️ 유튜브 프리미엄 영화</span></div>
<?php render_grid_section($ytm['results'], 'movie', 'title', 'secYtM', 10); endif; ?>
<?php if(!empty($ytt['results'])): ?>
<div style="margin:6px 0"><span class="sm-badge"><span class="dot" style="background:<?php echo $p['c']; ?>"></span>▶️ 유튜브 프리미엄 TV</span></div>
<?php render_grid_section($ytt['results'], 'tv', 'name', 'secYtT', 10); endif; ?>
</div>

<?php elseif ($pName === 'Apple TV+' || $pName === 'Prime Video'):
    $crawlKey = ($pName === 'Apple TV+') ? 'apple' : 'prime';
    $crawl = @sm_ott_crawled_titles($crawlKey, 20) ?: ['titles'=>[],'source'=>''];
    $cards_m = @sm_titles_to_tmdb_cards($crawl['titles'], 'movie', 20) ?: [];
    $cards_t = @sm_titles_to_tmdb_cards($crawl['titles'], 'tv', 20) ?: [];
    $disc_m = @tmdb_discover('movie', ["with_watch_providers"=>$p['pid'],"watch_region"=>"KR","sort_by"=>"popularity.desc"]) ?: [];
    $disc_t = @tmdb_discover('tv', ["with_watch_providers"=>$p['pid'],"watch_region"=>"KR","sort_by"=>"popularity.desc"]) ?: [];
    $seenM=[]; foreach($cards_m as $c) $seenM[(int)$c['id']]=true;
    foreach(($disc_m['results']??[]) as $dm){ if(isset($seenM[(int)$dm['id']]))continue; $cards_m[]=['id'=>(int)$dm['id'],'media'=>'movie','title'=>$dm['title']??'','poster_path'=>$dm['poster_path']??'','vote_average'=>(float)($dm['vote_average']??0)]; }
    $seenT=[]; foreach($cards_t as $c) $seenT[(int)$c['id']]=true;
    foreach(($disc_t['results']??[]) as $dt){ if(isset($seenT[(int)$dt['id']]))continue; $cards_t[]=['id'=>(int)$dt['id'],'media'=>'tv','title'=>$dt['name']??'','poster_path'=>$dt['poster_path']??'','vote_average'=>(float)($dt['vote_average']??0)]; }
    $emoji = ($pName==='Apple TV+') ? '📱' : '📦';
    $sidM = 'sec'.preg_replace('/[^a-zA-Z]/','',$pName).'M';
    $sidT = 'sec'.preg_replace('/[^a-zA-Z]/','',$pName).'T';
?>
<div id="smPl<?php echo $pi; ?>" style="scroll-margin-top:80px;margin-bottom:18px">
<div style="margin-bottom:6px"><span class="sm-badge"><span class="dot" style="background:<?php echo $p['c']; ?>"></span><?php echo $emoji; ?> <?php echo $pName; ?> 영화</span></div>
<?php render_grid_section($cards_m, 'movie', 'title', $sidM, 10, true); ?>
<div style="margin:6px 0"><span class="sm-badge"><span class="dot" style="background:<?php echo $p['c']; ?>"></span><?php echo $emoji; ?> <?php echo $pName; ?> TV</span></div>
<?php render_grid_section($cards_t, 'tv', 'title', $sidT, 10, true); ?>
</div>

<?php else:
    $md = @tmdb_discover('movie', ["with_watch_providers"=>$p['pid'],"watch_region"=>"KR","sort_by"=>"popularity.desc"]) ?: [];
    $td = @tmdb_discover('tv', ["with_watch_providers"=>$p['pid'],"watch_region"=>"KR","sort_by"=>"popularity.desc"]) ?: [];
    $sidM = 'secP'.$pi.'M'; $sidT = 'secP'.$pi.'T';
?>
<div id="smPl<?php echo $pi; ?>" style="scroll-margin-top:80px;margin-bottom:18px">
<div style="margin-bottom:6px"><span class="sm-badge"><span class="dot" style="background:<?php echo $p['c']; ?>"></span><?php echo $p['n']; ?> 영화</span></div>
<?php render_grid_section($md['results'] ?? [], 'movie', 'title', $sidM, 10); ?>
<div style="margin:6px 0"><span class="sm-badge"><span class="dot" style="background:<?php echo $p['c']; ?>"></span><?php echo $p['n']; ?> TV</span></div>
<?php render_grid_section($td['results'] ?? [], 'tv', 'name', $sidT, 10); ?>
</div>
<?php endif; endforeach; ?>

<!-- ═══ 🏆 해외 스포츠 LIVE ═══ -->
<?php
$sport_live = @sport_live_events() ?: [];
$sport_items = [];
if (is_array($sport_live) && !isset($sport_live['_error'])) {
    $raw = $sport_live['events'] ?? $sport_live['data'] ?? $sport_live;
    if (is_array($raw)) $sport_items = array_slice($raw, 0, 6);
}
?>
<div class="sm-section-header"><h2>🏆 스포츠 LIVE</h2><a href="sports.php" style="font-size:11px;color:var(--accent)">전체보기 →</a></div>
<?php if(!empty($sport_items)): ?>
<div class="sm-grid-wrap" style="grid-template-columns:repeat(3,1fr)">
<?php foreach($sport_items as $ev):
    $home = $ev['homeTeam']['name'] ?? $ev['home'] ?? '';
    $away = $ev['awayTeam']['name'] ?? $ev['away'] ?? '';
    $sh = $ev['homeScore']['current'] ?? '-';
    $sa = $ev['awayScore']['current'] ?? '-';
    $tour = $ev['tournament']['name'] ?? $ev['league'] ?? '';
?>
<div class="sm-grid-item"><div class="sm-panel" style="margin-bottom:0;padding:12px;border-left:3px solid var(--green)">
<div style="font-size:10px;color:var(--muted);margin-bottom:4px">🔴 <?php echo htmlspecialchars($tour); ?></div>
<div style="font-weight:900;font-size:13px"><?php echo htmlspecialchars($home); ?> <?php echo $sh; ?> : <?php echo $sa; ?> <?php echo htmlspecialchars($away); ?></div>
</div></div>
<?php endforeach; ?>
</div>
<?php else: ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px;margin-bottom:16px">
<?php
$sp_otts = [
    ['n'=>'쿠팡플레이','d'=>'EPL · K리그 · MLB','c'=>'#ff7a00'],
    ['n'=>'티빙','d'=>'프로야구 · 프로축구','c'=>'#FF0000'],
    ['n'=>'Prime Video','d'=>'챔피언스리그 · NFL','c'=>'#00A8E1'],
];
foreach($sp_otts as $so): ?>
<a href="sports.php" class="sm-panel" style="display:flex;align-items:center;gap:10px;border-left:3px solid <?php echo $so['c']; ?>;padding:12px;margin-bottom:0">
<img src="<?php echo sm_ott_logo($so['n']); ?>" style="width:28px;height:28px;border-radius:6px;object-fit:cover">
<div><div style="font-weight:900;font-size:12px"><?php echo $so['n']; ?></div><div style="font-size:10px;color:var(--muted)"><?php echo $so['d']; ?></div></div></a>
<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ═══ 💬 커뮤니티 최신글 ═══ -->
<?php
require_once 'includes/community.php';
$recent_all = get_recent_posts_all(3);
?>
<div class="sm-section-header"><h2>💬 커뮤니티 최신글</h2><a href="community.php" style="font-size:11px;color:var(--accent)">전체보기 →</a></div>
<?php if(empty($recent_all)): ?>
<div class="sm-panel" style="text-align:center;padding:20px;color:var(--muted)">아직 게시글이 없습니다. <a href="community.php" style="color:var(--accent)">첫 글을 작성해보세요!</a></div>
<?php else: ?>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;margin-bottom:16px">
<?php foreach($recent_all as $bk=>$bd):
    if (empty($bd['posts'])) continue;
    $board = $bd['board'];
?>
<div class="sm-panel" style="margin-bottom:0;padding:14px">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
<span style="font-weight:900;font-size:13px"><?php echo $board['icon']; ?> <?php echo $board['name']; ?></span>
<a href="board.php?b=<?php echo $bk; ?>" style="font-size:10px;color:var(--accent)">더보기 →</a>
</div>
<?php foreach(array_slice($bd['posts'],0,3) as $p): ?>
<a href="board.php?b=<?php echo $bk; ?>&view=<?php echo $p['id']; ?>" style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--stroke)">
<div style="font-size:12px;font-weight:700;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo htmlspecialchars($p['title']??''); ?>
<?php $cc=count($p['comments']??[]); if($cc): ?><span style="color:var(--accent);font-size:10px">[<?php echo $cc; ?>]</span><?php endif; ?></div>
<span style="font-size:10px;color:var(--muted);flex-shrink:0;margin-left:8px"><?php echo substr($p['created_at']??'',0,10); ?></span>
</a>
<?php endforeach; ?>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
<script>
var hIdx=0,hMax=<?php echo count($heroSlides); ?>,hTimer;
function smHeroTo(i){hIdx=i;document.getElementById('heroTrack').style.transform='translateX(-'+i*100+'%)';document.querySelectorAll('#heroDots span').forEach(function(d,j){d.className=j===i?'active':''})}
function smHero(d){smHeroTo((hIdx+d+hMax)%hMax);clearInterval(hTimer);hTimer=setInterval(function(){smHero(1)},5000)}
hTimer=setInterval(function(){smHero(1)},5000);
function smTT(t,b){document.getElementById('smTM').style.display=t==='m'?'':'none';document.getElementById('smTV').style.display=t==='t'?'':'none';document.querySelectorAll('#trendToggle button').forEach(function(x){x.classList.remove('active')});b.classList.add('active')}
function smMore(sid,step){
  var wrap=document.getElementById(sid);if(!wrap)return;
  var items=wrap.querySelectorAll('.sm-grid-item[style*="display:none"]');
  var shown=0;
  for(var i=0;i<items.length&&shown<step;i++){items[i].style.display='';shown++;}
  if(wrap.querySelectorAll('.sm-grid-item[style*="display:none"]').length===0){var btn=document.getElementById(sid+'More');if(btn)btn.style.display='none';}
}
</script>