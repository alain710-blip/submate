<?php
ini_set("display_errors",1); error_reporting(E_ALL);
$page_title = '검색'; require_once 'includes/header.php';
$q = trim($_GET['q'] ?? ''); $media = $_GET['media'] ?? 'multi'; $genre = (int)($_GET['genre'] ?? 0);
$results = []; $genres_list = [];

if ($genre && !$q) {
    $d = @tmdb_discover($media === 'tv' ? 'tv' : 'movie', ["with_genres" => $genre, "sort_by" => "popularity.desc"]) ?: [];
    $results = $d['results'] ?? [];
} elseif ($q) {
    if ($media === 'variety') {
        $d = @tmdb_search($q, 'tv');
        $results = array_filter($d['results'] ?? [], function($r) { return in_array(10764, $r['genre_ids']??[]); });
        $results = array_values($results);
    } elseif ($media === 'person') {
        $d = @tmdb_req("search/person", ["query" => $q, "language" => "ko-KR"]);
        $results = $d['results'] ?? [];
    } else {
        $d = @tmdb_search($q, $media === 'multi' ? 'multi' : $media);
        $results = $d['results'] ?? [];
    }
}

// 장르 목록
$gm = @tmdb_genres('movie') ?: []; $gt = @tmdb_genres('tv') ?: [];
$all_genres = array_merge($gm['genres']??[], $gt['genres']??[]);
$seen = []; $genres_list = [];
foreach ($all_genres as $g) { if (!isset($seen[$g['id']])) { $genres_list[] = $g; $seen[$g['id']] = true; } }
?>
<div class="sm-panel"><div class="sm-badge"><span class="dot"></span> 🔍 콘텐츠 검색</div>
<form method="get" style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
<input class="sm-input" name="q" placeholder="영화/드라마/예능/배우 검색" value="<?php echo htmlspecialchars($q); ?>" style="flex:1;min-width:200px">
<select name="media" class="sm-input" style="width:auto">
<option value="multi" <?php echo $media==='multi'?'selected':''; ?>>전체</option>
<option value="movie" <?php echo $media==='movie'?'selected':''; ?>>영화</option>
<option value="tv" <?php echo $media==='tv'?'selected':''; ?>>드라마</option>
<option value="variety" <?php echo $media==='variety'?'selected':''; ?>>예능</option>
<option value="person" <?php echo $media==='person'?'selected':''; ?>>배우</option>
</select>
<button class="sm-btn sm-btn-primary sm-btn-sm">검색</button>
</form>
<!-- 장르 바로가기 -->
<div style="margin-top:10px;display:flex;gap:4px;flex-wrap:wrap">
<?php foreach(array_slice($genres_list, 0, 15) as $g): ?>
<a href="?genre=<?php echo $g['id']; ?>&media=movie" class="sm-pill<?php echo $genre==(int)$g['id']?' style="background:var(--accent);color:#fff"':''; ?>"><?php echo htmlspecialchars($g['name']); ?></a>
<?php endforeach; ?>
</div></div>

<?php if($media === 'person' && $results): ?>
<div class="sm-grid"><?php foreach(array_slice($results,0,20) as $p): ?>
<div class="sm-card"><a href="person.php?id=<?php echo (int)$p['id']; ?>">
<?php if($p['profile_path']??''): ?><img class="sm-poster" src="<?php echo TMDB_IMG.$p['profile_path']; ?>" loading="lazy"><?php else: ?><div style="height:200px;display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:40px">🎭</div><?php endif; ?>
<div class="sm-card-body"><div class="sm-card-title"><?php echo htmlspecialchars($p['name']??''); ?></div><div class="sm-card-meta"><span><?php echo htmlspecialchars($p['known_for_department']??''); ?></span></div></div></a></div>
<?php endforeach; ?></div>
<?php elseif($results): ?>
<div class="sm-grid"><?php foreach(array_slice($results,0,20) as $m): $t=$m['title']??($m['name']??''); $type=$m['media_type']??($media==='tv'||$media==='variety'?'tv':'movie'); ?>
<div class="sm-card"><a href="movie.php?id=<?php echo (int)$m['id']; ?>&media=<?php echo $type; ?>">
<?php if($m['poster_path']??''): ?><img class="sm-poster" src="<?php echo TMDB_IMG.$m['poster_path']; ?>" loading="lazy"><?php else: ?><div style="height:200px;display:flex;align-items:center;justify-content:center;color:var(--muted)">No Poster</div><?php endif; ?>
<div class="sm-card-body"><div class="sm-card-title"><?php echo htmlspecialchars($t); ?></div><div class="sm-card-meta"><span>⭐ <?php echo $m['vote_average']??''; ?></span></div></div></a></div>
<?php endforeach; ?></div>
<?php elseif($q || $genre): ?><div class="sm-panel" style="text-align:center;padding:30px;color:var(--muted)">검색 결과 없음</div><?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
