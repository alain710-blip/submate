<?php
ini_set("display_errors",1); error_reporting(E_ALL);
$page_title = '해외 스포츠 중계'; require_once 'includes/header.php';

$sel_date = $_GET['date'] ?? date('Y-m-d');
$today_events = @sport_today_events($sel_date) ?: [];
$live_events = @sport_live_events() ?: [];

// 스포츠 카테고리
$sports = [
    'soccer'=>['name'=>'축구','icon'=>'⚽','color'=>'#22c55e'],
    'basketball'=>['name'=>'농구','icon'=>'🏀','color'=>'#f97316'],
    'baseball'=>['name'=>'야구','icon'=>'⚾','color'=>'#ef4444'],
    'tennis'=>['name'=>'테니스','icon'=>'🎾','color'=>'#eab308'],
    'hockey'=>['name'=>'하키','icon'=>'🏒','color'=>'#3b82f6'],
    'mma'=>['name'=>'격투기','icon'=>'🥊','color'=>'#dc2626'],
    'rugby'=>['name'=>'럭비','icon'=>'🏈','color'=>'#a855f7'],
    'cricket'=>['name'=>'크리켓','icon'=>'🏏','color'=>'#06b6d4'],
];

// 이벤트를 스포츠별로 분류
function classify_sport($event) {
    $name = strtolower($event['tournament']['name'] ?? $event['sport'] ?? '');
    if (strpos($name,'soccer')!==false||strpos($name,'football')!==false||strpos($name,'premier')!==false||strpos($name,'liga')!==false||strpos($name,'champions')!==false||strpos($name,'serie')!==false||strpos($name,'bundesliga')!==false) return 'soccer';
    if (strpos($name,'basket')!==false||strpos($name,'nba')!==false) return 'basketball';
    if (strpos($name,'baseball')!==false||strpos($name,'mlb')!==false) return 'baseball';
    if (strpos($name,'tennis')!==false||strpos($name,'atp')!==false||strpos($name,'wta')!==false) return 'tennis';
    if (strpos($name,'hockey')!==false||strpos($name,'nhl')!==false) return 'hockey';
    if (strpos($name,'mma')!==false||strpos($name,'ufc')!==false||strpos($name,'boxing')!==false) return 'mma';
    return 'soccer';
}

$events_list = [];
if (is_array($today_events) && !isset($today_events['_error'])) {
    $raw = $today_events['events'] ?? $today_events['data'] ?? $today_events;
    if (is_array($raw)) foreach($raw as $ev) {
        $ev['_sport'] = classify_sport($ev);
        $events_list[] = $ev;
    }
}
$live_list = [];
if (is_array($live_events) && !isset($live_events['_error'])) {
    $raw = $live_events['events'] ?? $live_events['data'] ?? $live_events;
    if (is_array($raw)) foreach($raw as $ev) {
        $ev['_sport'] = classify_sport($ev);
        $live_list[] = $ev;
    }
}
?>

<div class="sm-panel" style="text-align:center;padding:24px 20px">
  <h1 style="font-size:clamp(18px,4vw,26px);font-weight:900;margin-bottom:6px">🏆 해외 스포츠 중계</h1>
  <p style="color:var(--muted);font-size:13px">일자별 · 시간별 경기 일정 및 실시간 중계</p>
</div>

<!-- 스포츠 카테고리 -->
<div class="sm-slider" style="margin-bottom:14px">
<?php foreach($sports as $sk=>$sp): ?>
<div class="sm-slide" onclick="smSportFilter('<?php echo $sk; ?>',this)" style="cursor:pointer">
<span style="font-size:20px"><?php echo $sp['icon']; ?></span>
<span style="font-weight:800;font-size:11px"><?php echo $sp['name']; ?></span></div>
<?php endforeach; ?>
<div class="sm-slide active" onclick="smSportFilter('all',this)" style="cursor:pointer">
<span style="font-size:20px">📺</span>
<span style="font-weight:800;font-size:11px">전체</span></div>
</div>

<!-- 날짜 선택 -->
<div style="display:flex;gap:6px;align-items:center;margin-bottom:14px;flex-wrap:wrap">
<span style="font-weight:800;font-size:13px">📅 날짜:</span>
<?php for($d=-2;$d<=5;$d++):
  $dt = date('Y-m-d', strtotime("{$d} days"));
  $label = ($d===0) ? '오늘' : (($d===1) ? '내일' : (($d===-1) ? '어제' : date('m/d', strtotime($dt))));
  $active = ($dt === $sel_date) ? 'sm-btn-primary' : '';
?>
<a href="?date=<?php echo $dt; ?>" class="sm-btn sm-btn-sm <?php echo $active; ?>"><?php echo $label; ?></a>
<?php endfor; ?>
</div>

<!-- 실시간 LIVE -->
<?php if(!empty($live_list)): ?>
<div class="sm-section-header"><h2>🔴 실시간 LIVE</h2></div>
<div class="sm-grid-wrap" id="liveGrid" style="margin-bottom:18px">
<?php foreach($live_list as $ev):
    $sp = $sports[$ev['_sport']] ?? $sports['soccer'];
    $home = $ev['homeTeam']['name'] ?? $ev['home'] ?? '홈';
    $away = $ev['awayTeam']['name'] ?? $ev['away'] ?? '원정';
    $score_h = $ev['homeScore']['current'] ?? $ev['score_home'] ?? '-';
    $score_a = $ev['awayScore']['current'] ?? $ev['score_away'] ?? '-';
    $tourney = $ev['tournament']['name'] ?? $ev['league'] ?? '';
?>
<div class="sm-grid-item sm-sport-card" data-sport="<?php echo $ev['_sport']; ?>">
<div class="sm-panel" style="border-left:3px solid <?php echo $sp['color']; ?>;margin-bottom:0;padding:14px">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
<span style="font-size:10px;color:var(--muted)"><?php echo $sp['icon']; ?> <?php echo htmlspecialchars($tourney); ?></span>
<span style="background:var(--red);color:#fff;font-size:9px;font-weight:900;padding:2px 8px;border-radius:6px;animation:pulse 1.5s infinite">● LIVE</span>
</div>
<div style="display:flex;justify-content:space-between;align-items:center">
<div style="flex:1;text-align:center"><div style="font-weight:900;font-size:13px"><?php echo htmlspecialchars($home); ?></div></div>
<div style="font-weight:900;font-size:22px;color:var(--accent);padding:0 12px"><?php echo $score_h; ?> : <?php echo $score_a; ?></div>
<div style="flex:1;text-align:center"><div style="font-weight:900;font-size:13px"><?php echo htmlspecialchars($away); ?></div></div>
</div>
</div></div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<!-- 일정 -->
<div class="sm-section-header"><h2>📋 <?php echo $sel_date; ?> 경기 일정</h2></div>
<?php if(empty($events_list)): ?>
<div class="sm-panel" style="text-align:center;padding:30px">
<div style="font-size:40px;margin-bottom:8px">📡</div>
<p style="color:var(--muted)">해당 날짜의 경기 데이터를 불러올 수 없습니다.<br>API 서버 상태를 확인해주세요.</p>
<p style="font-size:12px;color:var(--muted);margin-top:12px">인기 스포츠 중계 사이트:</p>
<div style="display:flex;gap:6px;justify-content:center;margin-top:8px;flex-wrap:wrap">
<a href="https://www.flashscore.com" target="_blank" class="sm-btn sm-btn-sm">FlashScore</a>
<a href="https://www.espn.com" target="_blank" class="sm-btn sm-btn-sm">ESPN</a>
<a href="https://sports.yahoo.com" target="_blank" class="sm-btn sm-btn-sm">Yahoo Sports</a>
</div>
</div>
<?php else: ?>
<div class="sm-grid-wrap" id="scheduleGrid">
<?php foreach($events_list as $i=>$ev):
    $sp = $sports[$ev['_sport']] ?? $sports['soccer'];
    $home = $ev['homeTeam']['name'] ?? $ev['home'] ?? '홈';
    $away = $ev['awayTeam']['name'] ?? $ev['away'] ?? '원정';
    $time_raw = $ev['startTimestamp'] ?? $ev['time'] ?? '';
    $time_str = $time_raw ? date('H:i', is_numeric($time_raw) ? $time_raw : strtotime($time_raw)) : '--:--';
    $status = $ev['status']['description'] ?? $ev['status'] ?? '';
    $tourney = $ev['tournament']['name'] ?? $ev['league'] ?? '';
    $hidden = ($i >= 20) ? ' style="display:none"' : '';
?>
<div class="sm-grid-item sm-sport-card" data-sport="<?php echo $ev['_sport']; ?>" data-idx="<?php echo $i; ?>"<?php echo $hidden; ?>>
<div class="sm-panel" style="border-left:3px solid <?php echo $sp['color']; ?>;margin-bottom:0;padding:12px">
<div style="display:flex;justify-content:space-between;font-size:10px;color:var(--muted);margin-bottom:6px">
<span><?php echo $sp['icon']; ?> <?php echo htmlspecialchars($tourney); ?></span>
<span style="font-weight:800"><?php echo $time_str; ?></span>
</div>
<div style="font-weight:900;font-size:13px"><?php echo htmlspecialchars($home); ?> vs <?php echo htmlspecialchars($away); ?></div>
<?php if($status): ?><div style="font-size:10px;color:var(--accent);margin-top:4px"><?php echo htmlspecialchars($status); ?></div><?php endif; ?>
</div></div>
<?php endforeach; ?>
</div>
<?php if(count($events_list) > 20): ?>
<div class="sm-more-wrap" id="scheduleGridMore"><button class="sm-btn sm-btn-sm" onclick="smMore('scheduleGrid',20)" style="margin:8px auto;display:block">더보기 ▼</button></div>
<?php endif; endif; ?>

<!-- OTT 스포츠 채널 안내 -->
<div class="sm-section-header" style="margin-top:20px"><h2>📡 OTT 스포츠 채널</h2></div>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px;margin-bottom:16px">
<?php
$sport_otts = [
    ['n'=>'쿠팡플레이','desc'=>'EPL, K리그, MLB','logo'=>sm_ott_logo('쿠팡플레이'),'url'=>'https://www.coupangplay.com','c'=>'#ff7a00'],
    ['n'=>'티빙','desc'=>'프로야구, 프로축구','logo'=>sm_ott_logo('티빙'),'url'=>'https://www.tving.com','c'=>'#FF0000'],
    ['n'=>'Prime Video','desc'=>'챔피언스리그, NFL','logo'=>sm_ott_logo('Prime Video'),'url'=>'https://www.primevideo.com','c'=>'#00A8E1'],
    ['n'=>'Apple TV+','desc'=>'MLS, MLB Friday','logo'=>sm_ott_logo('Apple TV+'),'url'=>'https://tv.apple.com','c'=>'#0A84FF'],
];
foreach($sport_otts as $so): ?>
<a href="<?php echo $so['url']; ?>" target="_blank" class="sm-panel" style="display:flex;align-items:center;gap:12px;border-left:3px solid <?php echo $so['c']; ?>;padding:14px;margin-bottom:0">
<img src="<?php echo $so['logo']; ?>" style="width:36px;height:36px;border-radius:8px;object-fit:cover">
<div><div style="font-weight:900;font-size:14px"><?php echo $so['n']; ?></div>
<div style="font-size:11px;color:var(--muted)"><?php echo $so['desc']; ?></div></div></a>
<?php endforeach; ?>
</div>

<style>
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
</style>
<script>
function smSportFilter(s,el){
  document.querySelectorAll('.sm-slide').forEach(function(x){x.classList.remove('active')});
  if(el)el.classList.add('active');
  document.querySelectorAll('.sm-sport-card').forEach(function(c){
    c.style.display=(s==='all'||c.dataset.sport===s)?'':'none';
  });
}
function smMore(sid,step){
  var wrap=document.getElementById(sid);if(!wrap)return;
  var items=wrap.querySelectorAll('.sm-grid-item[style*="display:none"]');
  var shown=0;
  for(var i=0;i<items.length&&shown<step;i++){items[i].style.display='';shown++;}
  if(wrap.querySelectorAll('.sm-grid-item[style*="display:none"]').length===0){var btn=document.getElementById(sid+'More');if(btn)btn.style.display='none';}
}
</script>
<?php require_once 'includes/footer.php'; ?>
