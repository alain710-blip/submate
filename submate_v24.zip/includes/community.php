<?php
require_once __DIR__ . '/auth.php';

// 게시판 목록
function get_boards() {
    return [
        'notice'   => ['name'=>'공지사항','icon'=>'📢','desc'=>'운영진 공지','admin_only'=>true,'points'=>0],
        'greeting' => ['name'=>'가입인사','icon'=>'👋','desc'=>'새 회원 인사','admin_only'=>false,'points'=>5],
        'free'     => ['name'=>'자유게시판','icon'=>'💬','desc'=>'자유로운 이야기','admin_only'=>false,'points'=>3],
        'gallery'  => ['name'=>'갤러리','icon'=>'🖼️','desc'=>'이미지 공유','admin_only'=>false,'points'=>5],
        'qna'      => ['name'=>'질문답변','icon'=>'❓','desc'=>'궁금한 것','admin_only'=>false,'points'=>3],
        'review'   => ['name'=>'회원리뷰','icon'=>'⭐','desc'=>'OTT/콘텐츠 리뷰','admin_only'=>false,'points'=>10],
        'it_forum' => ['name'=>'IT포럼','icon'=>'💻','desc'=>'IT/기술 토론','admin_only'=>false,'points'=>5],
        'news'     => ['name'=>'정보소식','icon'=>'📰','desc'=>'OTT 뉴스/정보','admin_only'=>false,'points'=>5],
    ];
}

function get_posts($board, $page=1, $per=20, $search='') {
    $all = read_json("board_{$board}.json");
    if ($search) $all = array_filter($all, function($p) use($search) {
        return stripos($p['title']??'', $search) !== false || stripos($p['content']??'', $search) !== false || stripos($p['author_name']??'', $search) !== false;
    });
    $all = array_values(array_reverse($all));
    $total = count($all);
    $pages = max(1, ceil($total / $per));
    $offset = ($page - 1) * $per;
    return ['posts'=>array_slice($all, $offset, $per), 'total'=>$total, 'pages'=>$pages, 'page'=>$page];
}

function get_post($board, $id) {
    foreach (read_json("board_{$board}.json") as $p) { if ((int)($p['id']??0) === (int)$id) return $p; }
    return null;
}

function add_post($board, $data) {
    $all = read_json("board_{$board}.json"); $id = 1;
    foreach ($all as $p) $id = max($id, (int)($p['id']??0)+1);
    $data['id'] = $id; $data['created_at'] = date('c'); $data['views'] = 0;
    $data['comments'] = []; $data['likes'] = 0;
    $all[] = $data; write_json("board_{$board}.json", $all);
    // 포인트 부여
    $boards = get_boards();
    $pts = $boards[$board]['points'] ?? 0;
    if ($pts > 0 && isset($data['author_id'])) add_points($data['author_id'], $pts, "{$boards[$board]['name']} 글 작성");
    return $id;
}

function update_post($board, $id, $fields) {
    $all = read_json("board_{$board}.json");
    foreach ($all as &$p) { if ((int)($p['id']??0)===(int)$id) { foreach ($fields as $k=>$v) $p[$k]=$v; break; } }
    write_json("board_{$board}.json", $all);
}

function delete_post($board, $id) {
    $all = read_json("board_{$board}.json");
    $all = array_values(array_filter($all, function($p) use($id) { return (int)($p['id']??0) !== (int)$id; }));
    write_json("board_{$board}.json", $all);
}

function add_comment($board, $post_id, $comment) {
    $all = read_json("board_{$board}.json");
    foreach ($all as &$p) {
        if ((int)($p['id']??0)===(int)$post_id) {
            $cid = 1; foreach(($p['comments']??[]) as $c) $cid=max($cid,(int)($c['id']??0)+1);
            $comment['id'] = $cid; $comment['created_at'] = date('c');
            $p['comments'][] = $comment;
            // 댓글 포인트
            if (isset($comment['author_id'])) add_points($comment['author_id'], 2, "댓글 작성");
            break;
        }
    }
    write_json("board_{$board}.json", $all);
}

function increment_views($board, $id) {
    $all = read_json("board_{$board}.json");
    foreach ($all as &$p) { if ((int)($p['id']??0)===(int)$id) { $p['views'] = (int)($p['views']??0)+1; break; } }
    write_json("board_{$board}.json", $all);
}

// 포인트 시스템
function get_points($uid) {
    $pts = read_json('points.json');
    $total = 0;
    foreach ($pts as $p) { if (($p['user_id']??0)==$uid) $total += (int)($p['amount']??0); }
    return $total;
}

function add_points($uid, $amount, $reason='') {
    $pts = read_json('points.json');
    $pts[] = ['user_id'=>$uid, 'amount'=>$amount, 'reason'=>$reason, 'time'=>date('c')];
    write_json('points.json', $pts);
}

function get_point_ranking($limit=100) {
    $pts = read_json('points.json');
    $users = read_json('users.json');
    $totals = [];
    foreach ($pts as $p) {
        $uid = $p['user_id']??0;
        $totals[$uid] = ($totals[$uid]??0) + (int)($p['amount']??0);
    }
    arsort($totals);
    $rank = []; $i = 0;
    foreach ($totals as $uid => $pt) {
        if ($i >= $limit) break;
        $u = null; foreach($users as $uu) { if (($uu['id']??0)==$uid) { $u=$uu; break; } }
        if ($u) { $rank[] = ['rank'=>$i+1, 'user'=>$u, 'points'=>$pt]; $i++; }
    }
    return $rank;
}

// OTT 플랫폼 실제 로고 URL
function ott_logo_url($name) {
    // sm_ott_logo (TMDB API 기반) 우선 사용
    if (function_exists('sm_ott_logo')) {
        $url = sm_ott_logo($name);
        if ($url) return $url;
    }
    // 이름 매핑 시도
    $nameMap = ['Netflix'=>'넷플릭스','TVING'=>'티빙','wavve'=>'웨이브','WATCHA'=>'왓챠','Watcha'=>'왓챠','Disney Plus'=>'디즈니+','Coupang Play'=>'쿠팡플레이','Apple TV Plus'=>'Apple TV+','Amazon Prime Video'=>'Prime Video','YouTube Premium'=>'유튜브 프리미엄'];
    foreach($nameMap as $k=>$v) {
        if (stripos($name, $k) !== false && function_exists('sm_ott_logo')) {
            $url = sm_ott_logo($v);
            if ($url) return $url;
        }
    }
    return '';
}

// 모든 게시판 최신글 가져오기
function get_recent_posts_all($per_board = 3) {
    $boards = get_boards();
    $result = [];
    foreach ($boards as $bk => $board) {
        $all = read_json("board_{$bk}.json");
        if (!is_array($all) || empty($all)) continue;
        usort($all, function($a,$b){ return strcmp($b['created_at']??'', $a['created_at']??''); });
        $posts = array_slice($all, 0, $per_board);
        foreach ($posts as &$p) { $p['_board_key'] = $bk; $p['_board_name'] = $board['name']; $p['_board_icon'] = $board['icon']; }
        $result[$bk] = ['board'=>$board, 'posts'=>$posts];
    }
    return $result;
}

// OTT 시청 링크
function ott_watch_url($name, $title='') {
    $q = urlencode($title);
    $links = [
        'Netflix'=>"https://www.netflix.com/search?q={$q}",
        '넷플릭스'=>"https://www.netflix.com/search?q={$q}",
        'TVING'=>"https://www.tving.com/search?keyword={$q}",
        '티빙'=>"https://www.tving.com/search?keyword={$q}",
        'wavve'=>"https://www.wavve.com/search?searchWord={$q}",
        '웨이브'=>"https://www.wavve.com/search?searchWord={$q}",
        'WATCHA'=>"https://watcha.com/search?query={$q}",
        '왓챠'=>"https://watcha.com/search?query={$q}",
        'Disney Plus'=>"https://www.disneyplus.com/search?q={$q}",
        '디즈니+'=>"https://www.disneyplus.com/search?q={$q}",
        'Apple TV Plus'=>"https://tv.apple.com/search?term={$q}",
        'Apple TV+'=>"https://tv.apple.com/search?term={$q}",
        'Amazon Prime Video'=>"https://www.primevideo.com/search?phrase={$q}",
        'Prime Video'=>"https://www.primevideo.com/search?phrase={$q}",
        'Coupang Play'=>"https://www.coupangplay.com/search?q={$q}",
        '쿠팡플레이'=>"https://www.coupangplay.com/search?q={$q}",
        'YouTube Premium'=>"https://www.youtube.com/results?search_query={$q}",
        '유튜브프리미엄'=>"https://www.youtube.com/results?search_query={$q}",
        '유튜브 프리미엄'=>"https://www.youtube.com/results?search_query={$q}",
    ];
    foreach ($links as $k => $v) { if (stripos($name, $k) !== false) return $v; }
    return "https://www.google.com/search?q=" . urlencode($name . ' ' . $title . ' 보기');
}
