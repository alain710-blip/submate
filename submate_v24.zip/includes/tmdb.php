<?php
// config 파일 안전 로딩
$_tmdb_config_path = __DIR__ . '/../config/tmdb.php';
if (file_exists($_tmdb_config_path)) {
    require_once $_tmdb_config_path;
} else {
    // config/tmdb.php 누락 시 기본값 (서버 배포 시 config 폴더 확인 필요)
    if (!defined('TMDB_API_KEY'))  define('TMDB_API_KEY', '');
    if (!defined('TMDB_TOKEN'))    define('TMDB_TOKEN', '');
    if (!defined('TMDB_IMG'))      define('TMDB_IMG', 'https://image.tmdb.org/t/p/w500');
    if (!defined('TMDB_IMG_BG'))   define('TMDB_IMG_BG', 'https://image.tmdb.org/t/p/w1280');
    if (!defined('SITE_NAME'))     define('SITE_NAME', 'SubMate PRO');
    if (!defined('SITE_URL'))      define('SITE_URL', '');
    error_log('[SubMate] config/tmdb.php 파일을 찾을 수 없습니다: ' . $_tmdb_config_path);
}
if (file_exists(__DIR__ . '/../config/naver.php')) { require_once __DIR__ . '/../config/naver.php'; }

function tmdb_req($ep, $pa = []) {
    $url = "https://api.themoviedb.org/3/" . $ep . "?" . http_build_query(array_merge($pa, ["api_key" => TMDB_API_KEY, "language" => "ko-KR"]));
        $r = false; $c = 0;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_SSL_VERIFYPEER => false]);
        $r = curl_exec($ch); $c = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    } else {
        $ctx = stream_context_create(['http'=>['timeout'=>10], 'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
        $r = @file_get_contents($url, false, $ctx);
        if ($r !== false) { $c = 200; }
    }
    $j = json_decode($r, true);
    return ($j && $c < 400) ? $j : ["_error" => true];
}

function tmdb_cache($key, $ttl, $fn) {
    $dir = __DIR__ . '/../data/cache';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $f = $dir . '/tmdb_' . md5($key) . '.json';
    if (file_exists($f) && (time() - filemtime($f)) < $ttl) {
        $d = json_decode(file_get_contents($f), true);
        if ($d) return $d;
    }
    $d = $fn();
    if ($d && !isset($d['_error'])) @file_put_contents($f, json_encode($d, JSON_UNESCAPED_UNICODE));
    return $d;
}

function tmdb_trending($m = 'movie') { return tmdb_cache("tr_{$m}", 3600, function() use($m) { return tmdb_req("trending/{$m}/day"); }); }
function tmdb_now_playing() { return tmdb_cache("np", 3600, function() { return tmdb_req("movie/now_playing", ["region" => "KR"]); }); }
function tmdb_upcoming() { return tmdb_cache("up", 3600, function() { return tmdb_req("movie/upcoming", ["region" => "KR"]); }); }
function tmdb_top_tv() { return tmdb_cache("ttv", 7200, function() { return tmdb_req("tv/top_rated"); }); }
function tmdb_discover($m, $pa = []) { $k = "disc_{$m}_" . md5(serialize($pa)); return tmdb_cache($k, 3600, function() use($m, $pa) { return tmdb_req("discover/{$m}", $pa); }); }
function tmdb_detail($m, $id) { return tmdb_cache("det_{$m}_{$id}", 7200, function() use($m, $id) { return tmdb_req("{$m}/{$id}", ["append_to_response" => "videos,credits,watch/providers,similar,recommendations"]); }); }
function tmdb_search($q, $m = 'multi') { $ep = ($m === 'multi') ? "search/multi" : "search/{$m}"; return tmdb_req($ep, ["query" => $q, "page" => 1, "include_adult" => "false"]); }
function tmdb_genres($t = 'movie') { return tmdb_cache("genres_{$t}", 86400, function() use($t) { return tmdb_req("genre/{$t}/list"); }); }

function tmdb_kr_prov($m, $id) {
    return tmdb_cache("prov_{$m}_{$id}", 21600, function() use($m, $id) {
        $d = tmdb_req("{$m}/{$id}/watch/providers");
        $kr = $d['results']['KR'] ?? null; $has = false; $n = [];
        if ($kr) { $has = !empty($kr['flatrate']); foreach(($kr['flatrate'] ?? []) as $p) $n[] = $p['provider_name'] ?? ''; }
        return ["has" => $has, "pn" => $n];
    });
}

// 한국 영화 인기작
function tmdb_kr_movies() {
    return tmdb_cache("kr_movies", 3600, function() {
        return tmdb_req("discover/movie", ["with_original_language" => "ko", "sort_by" => "popularity.desc", "region" => "KR"]);
    });
}

// 한국 드라마 인기작
function tmdb_kr_dramas() {
    return tmdb_cache("kr_dramas", 3600, function() {
        return tmdb_req("discover/tv", ["with_original_language" => "ko", "sort_by" => "popularity.desc"]);
    });
}

// Apple TV+ 오리지널
function tmdb_apple_originals($type = 'movie') {
    return tmdb_cache("apple_{$type}", 3600, function() use($type) {
        return tmdb_req("discover/{$type}", ["with_watch_providers" => "2", "watch_region" => "KR", "sort_by" => "popularity.desc"]);
    });
}

// Prime Video 오리지널
function tmdb_prime_originals($type = 'movie') {
    return tmdb_cache("prime_{$type}", 3600, function() use($type) {
        return tmdb_req("discover/{$type}", ["with_watch_providers" => "9", "watch_region" => "KR", "sort_by" => "popularity.desc"]);
    });
}

function sm_platforms() {
    return [
        ["n"=>"넷플릭스","pid"=>8,"c"=>"#E50914","i"=>"🎬","d"=>"글로벌 오리지널","logo"=>"/pbpMk2JmcoNnQwN5JGpXngfoWtp.jpg"],
        ["n"=>"티빙","pid"=>350,"c"=>"#FF0000","i"=>"📺","d"=>"국내 예능/드라마","logo"=>"/dNAz0MMIPiqCD2axGUZPAMq2gio.jpg"],
        ["n"=>"웨이브","pid"=>356,"c"=>"#00C8FF","i"=>"🌊","d"=>"지상파 콘텐츠","logo"=>"/2ioan5BX5L9tz4fIGU93blTeFhv.jpg"],
        ["n"=>"왓챠","pid"=>97,"c"=>"#FF0066","i"=>"👁","d"=>"취향 영화","logo"=>"/cNi4Nv5EPsnvf5WR3bm0WGFCid0.jpg"],
        ["n"=>"쿠팡플레이","pid"=>96,"c"=>"#ff7a00","i"=>"🛒","d"=>"가성비 OTT","logo"=>"/wuVHPFhcIRVVxOSi0RS0YJDlhEq.jpg"],
        ["n"=>"디즈니+","pid"=>337,"c"=>"#113CCF","i"=>"🏰","d"=>"마블/픽사","logo"=>"/7rwgEs15tFwyR9NPQ5vpzxTj19Q.jpg"],
        ["n"=>"Apple TV+","pid"=>2,"c"=>"#0A84FF","i"=>"📱","d"=>"애플 오리지널","logo"=>"/6uhKBfmtzFqOcLousHwZuzcrScK.jpg"],
        ["n"=>"Prime Video","pid"=>9,"c"=>"#00A8E1","i"=>"📦","d"=>"아마존 오리지널","logo"=>"/emthp39XA2YScoYL1p0sdbAH2WA.jpg"],
        ["n"=>"유튜브 프리미엄","pid"=>188,"c"=>"#FF0000","i"=>"▶️","d"=>"광고 없이 YouTube","logo"=>"/oIkQkEkwfmcG7IGpje5x4AoMYBe.jpg"],
    ];
}

// TMDB 로고 URL 반환 (movie detail 시청하기와 동일한 방식)
function sm_ott_logo($name) {
    static $map = null;
    if ($map === null) {
        $map = [];
        // 1) 캐시에서 로드
        $dir = __DIR__ . '/../data/cache';
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $f = $dir . '/ott_logos_v2.json';
        if (file_exists($f) && (time() - filemtime($f)) < 86400) {
            $d = json_decode(file_get_contents($f), true);
            if ($d && is_array($d)) { $map = $d; return $map[$name] ?? ''; }
        }
        // 2) TMDB API에서 watch provider 목록 조회 (movie detail과 동일 소스)
        if (defined('TMDB_API_KEY') && TMDB_API_KEY) {
            $pid_name = [];
            foreach(sm_platforms() as $p) $pid_name[$p['pid']] = $p['n'];
            $url = "https://api.themoviedb.org/3/watch/providers/movie?api_key=" . TMDB_API_KEY . "&language=ko-KR&watch_region=KR";
            $ctx = stream_context_create(['http'=>['timeout'=>8],'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
            $r = @file_get_contents($url, false, $ctx);
            if ($r) {
                $data = json_decode($r, true);
                foreach (($data['results'] ?? []) as $prov) {
                    $pid = (int)($prov['provider_id'] ?? 0);
                    if (isset($pid_name[$pid]) && !empty($prov['logo_path'])) {
                        $map[$pid_name[$pid]] = 'https://image.tmdb.org/t/p/w92' . $prov['logo_path'];
                    }
                }
            }
        }
        // 3) 누락된 플랫폼 로컬 fallback
        $fallback = [
            '넷플릭스'=>'images/ottlogo/netflix.png','티빙'=>'images/ottlogo/tving.png',
            '웨이브'=>'images/ottlogo/wavve.png','왓챠'=>'images/ottlogo/watcha.png',
            '쿠팡플레이'=>'images/ottlogo/coupangplay.png','디즈니+'=>'images/ottlogo/disneyplus.png',
            'Apple TV+'=>'images/ottlogo/appletvplus.png','Prime Video'=>'images/ottlogo/primevideo.png',
            '유튜브 프리미엄'=>'images/ottlogo/youtubepremium.png',
        ];
        foreach($fallback as $k=>$v) { if(!isset($map[$k])) $map[$k] = $v; }
        // 캐시 저장
        if (!empty($map)) @file_put_contents($f, json_encode($map, JSON_UNESCAPED_UNICODE));
    }
    return $map[$name] ?? '';
}

// ===== KOBIS 박스오피스 API =====
if (file_exists(__DIR__ . '/../config/kobis.php')) require_once __DIR__ . '/../config/kobis.php';

function kobis_req($ep, $pa = []) {
    if (!defined('KOBIS_API_KEY') || !KOBIS_API_KEY) return ['_error'=>true];
    $url = "https://kobis.or.kr/kobisopenapi/webservice/rest/" . $ep . ".json?" . http_build_query(array_merge($pa, ['key'=>KOBIS_API_KEY]));
    $r = false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>12, CURLOPT_SSL_VERIFYPEER=>false, CURLOPT_FOLLOWLOCATION=>true]);
        $r = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code >= 400) $r = false;
    } else {
        $ctx = stream_context_create(['http'=>['timeout'=>12],'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
        $r = @file_get_contents($url, false, $ctx);
    }
    if (!$r) return ['_error'=>true];
    $j = json_decode($r, true);
    return is_array($j) ? $j : ['_error'=>true];
}

function kobis_daily_boxoffice($date = '') {
    if (!$date) $date = date('Ymd', strtotime('-1 day'));
    return tmdb_cache("kobis_daily_{$date}", 7200, function() use($date) {
        $r = kobis_req('boxoffice/searchDailyBoxOfficeList', ['targetDt'=>$date]);
        $list = $r['boxOfficeResult']['dailyBoxOfficeList'] ?? [];
        return !empty($list) ? $list : null;
    }) ?: [];
}

function kobis_weekly_boxoffice($date = '') {
    if (!$date) $date = date('Ymd', strtotime('-7 days'));
    return tmdb_cache("kobis_weekly_{$date}", 14400, function() use($date) {
        $r = kobis_req('boxoffice/searchWeeklyBoxOfficeList', ['targetDt'=>$date, 'weekGb'=>'0']);
        $list = $r['boxOfficeResult']['weeklyBoxOfficeList'] ?? [];
        return !empty($list) ? $list : null;
    }) ?: [];
}

function kobis_movie_list($year = '', $month = '') {
    if (!$year) $year = date('Y');
    if (!$month) $month = date('m');
    return tmdb_cache("kobis_list_{$year}{$month}", 14400, function() use($year) {
        $r = kobis_req('movie/searchMovieList', ['openStartDt'=>$year, 'openEndDt'=>$year, 'itemPerPage'=>'50']);
        $list = $r['movieListResult']['movieList'] ?? [];
        return !empty($list) ? $list : null;
    }) ?: [];
}

// ===== KMDb 한국영상자료원 API =====
function kmdb_req($pa = []) {
    if (!defined('KMDB_API_KEY') || !KMDB_API_KEY) return ['_error'=>true];
    $base = 'https://api.koreafilm.or.kr/openapi-data2/wisenut/search_api/search_json2.jsp';
    $pa['ServiceKey'] = KMDB_API_KEY;
    if (!isset($pa['collection'])) $pa['collection'] = 'kmdb_new2';
    $url = $base . '?' . http_build_query($pa);
    $r = @file_get_contents($url, false, stream_context_create(['http'=>['timeout'=>10],'ssl'=>['verify_peer'=>false]]));
    return $r ? (json_decode($r, true) ?: ['_error'=>true]) : ['_error'=>true];
}

function kmdb_recent_korean($limit = 20) {
    return tmdb_cache("kmdb_recent_kr", 14400, function() use($limit) {
        $y = date('Y');
        $r = kmdb_req(['releaseDts'=>$y.'0101','releaseDte'=>$y.'1231','nation'=>'대한민국','listCount'=>$limit,'sort'=>'prodYear,1']);
        $items = [];
        if (isset($r['Data'][0]['Result'])) {
            foreach($r['Data'][0]['Result'] as $m) {
                $title = trim(preg_replace('/\s*!HS.*?!HE\s*/', '', $m['title'] ?? ''));
                $poster = '';
                if (!empty($m['posters'])) { $pp = explode('|', $m['posters']); $poster = $pp[0] ?? ''; }
                $items[] = [
                    'title'=>$title,
                    'titleEng'=>$m['titleEng']??'',
                    'year'=>$m['prodYear']??$y,
                    'directors'=>$m['directors']['director'][0]['directorNm']??'',
                    'poster'=>$poster,
                    'kmdb_id'=>$m['DOCID']??'',
                    'genre'=>$m['genre']??'',
                    'rating'=>$m['rating']??'',
                    'releaseDate'=>$m['repRlsDate']??'',
                ];
            }
        }
        return $items;
    });
}

// ===== Sports API (RapidAPI + SportDB) =====
function sport_api_req($endpoint, $extra = []) {
    if (!defined('SPORTDB_API_KEY')) return ['_error'=>true];
    $url = 'https://api.sportdb.dev/api/flashscore/' . $endpoint;
    if ($extra) $url .= '?' . http_build_query($extra);
    $ctx = stream_context_create(['http'=>['timeout'=>10,'header'=>"X-API-Key: ".SPORTDB_API_KEY."\r\nAccept: application/json\r\n"],'ssl'=>['verify_peer'=>false]]);
    $r = @file_get_contents($url, false, $ctx);
    return $r ? (json_decode($r, true) ?: ['_error'=>true]) : ['_error'=>true];
}

function rapidapi_sport_req($host, $endpoint) {
    if (!defined('RAPIDAPI_KEY')) return ['_error'=>true];
    $url = "https://{$host}/{$endpoint}";
    $ctx = stream_context_create(['http'=>['timeout'=>10,'header'=>"x-rapidapi-key: ".RAPIDAPI_KEY."\r\nx-rapidapi-host: {$host}\r\nAccept: application/json\r\n"],'ssl'=>['verify_peer'=>false]]);
    $r = @file_get_contents($url, false, $ctx);
    return $r ? (json_decode($r, true) ?: ['_error'=>true]) : ['_error'=>true];
}

function sport_live_events() {
    return tmdb_cache("sport_live", 300, function() {
        // RapidAPI FlashScore 시도
        $r = rapidapi_sport_req('flashscore.p.rapidapi.com', 'v1/events/live');
        if (!isset($r['_error']) && !empty($r)) return $r;
        // Fallback: SportDB
        return sport_api_req('events/live');
    });
}

function sport_today_events($date = '') {
    if (!$date) $date = date('Y-m-d');
    return tmdb_cache("sport_today_{$date}", 1800, function() use($date) {
        $r = rapidapi_sport_req('flashscore.p.rapidapi.com', "v1/events/list?locale=ko&timezone=9&sport_id=1&indent_days=0");
        if (!isset($r['_error']) && !empty($r)) return $r;
        return sport_api_req("events/{$date}");
    });
}

// YouTube Data API
if (!function_exists('youtube_trending')) {
function youtube_trending($max = 8) {
    if (!defined('YOUTUBE_API_KEY') || !YOUTUBE_API_KEY) return ['items'=>[]];
    $url = "https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&chart=mostPopular&regionCode=KR&maxResults={$max}&key=" . YOUTUBE_API_KEY;
    $r = @file_get_contents($url, false, stream_context_create(['http'=>['timeout'=>8],'ssl'=>['verify_peer'=>false]]));
    return $r ? (json_decode($r, true) ?: ['items'=>[]]) : ['items'=>[]];
}
}


if (!function_exists('sm_mb_len_tmdb')) {
function sm_mb_len_tmdb($s){ $s=(string)$s; return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s); }
}
if (!function_exists('sm_mb_lc_tmdb')) {
function sm_mb_lc_tmdb($s){ $s=(string)$s; return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s); }
}

if (!function_exists('sm_http_get')) {
function sm_http_get($url, $timeout = 10) {
    $html = '';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122 Safari/537.36',
            CURLOPT_HTTPHEADER => [
                'Accept-Language: ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            ]
        ]);
        $out = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($out !== false && $code >= 200 && $code < 400) $html = (string)$out;
    } else {
        $ctx = stream_context_create([
            'http'=>[
                'timeout'=>$timeout,
                'ignore_errors'=>true,
                'header'=>"User-Agent: Mozilla/5.0
Accept-Language: ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7
"
            ],
            'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false],
        ]);
        $out = @file_get_contents($url, false, $ctx);
        if ($out !== false) $html = (string)$out;
    }
    return $html;
}
}

if (!function_exists('sm_unique_titles')) {
function sm_unique_titles($titles, $limit = 20) {
    $seen = []; $res = [];
    foreach ((array)$titles as $t) {
        $t = trim((string)$t);
        if ($t === '') continue;
        $k = sm_mb_lc_tmdb($t);
        if (isset($seen[$k])) continue;
        $seen[$k] = true;
        $res[] = $t;
        if (count($res) >= $limit) break;
    }
    return $res;
}
}

if (!function_exists('sm_extract_titles_from_html')) {
function sm_extract_titles_from_html($html, $limit = 60) {
    $titles = [];
    if (!is_string($html) || $html === '') return $titles;

    if (preg_match_all('#<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#is', $html, $m)) {
        foreach ($m[1] as $jsonTxt) {
            $jsonTxt = trim($jsonTxt);
            if ($jsonTxt === '') continue;
            $decoded = json_decode($jsonTxt, true);
            if (!$decoded) continue;
            $stack = (is_array($decoded) && array_keys($decoded) === range(0, count($decoded)-1)) ? $decoded : [$decoded];
            foreach ($stack as $node) {
                if (!is_array($node)) continue;
                if (!empty($node['itemListElement']) && is_array($node['itemListElement'])) {
                    foreach ($node['itemListElement'] as $it) {
                        $name = '';
                        if (is_array($it)) {
                            if (!empty($it['name'])) $name = $it['name'];
                            elseif (!empty($it['item']['name'])) $name = $it['item']['name'];
                        }
                        if ($name) $titles[] = html_entity_decode((string)$name, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    }
                }
                if (!empty($node['name'])) {
                    $titles[] = html_entity_decode((string)$node['name'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                }
            }
        }
    }

    $patterns = [
        '/"title"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/u',
        '/"name"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/u',
        '/data-title=["\']([^"\']+)["\']/u'
    ];
    foreach ($patterns as $p) {
        if (preg_match_all($p, $html, $mm)) {
            foreach ($mm[1] as $raw) {
                $v = stripcslashes((string)$raw);
                $v = html_entity_decode($v, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $v = trim($v);
                if ($v !== '' && sm_mb_len_tmdb($v) >= 2) $titles[] = $v;
                if (count($titles) >= $limit * 3) break;
            }
        }
    }

    $titles = array_filter($titles, function($t){
        $len = sm_mb_len_tmdb((string)$t);
        if ($len < 2 || $len > 80) return false;
        if (preg_match('/^(home|search|sign in|login|menu|help|privacy|terms)$/i', (string)$t)) return false;
        return true;
    });

    return sm_unique_titles(array_values($titles), $limit);
}
}

if (!function_exists('sm_ott_crawl_sources')) {
function sm_ott_crawl_sources($provider) {
    $p = strtolower(trim((string)$provider));
    if (in_array($p, ['appletv', 'apple', 'appletv+', 'apple tv+'], true)) $p = 'apple';
    if (in_array($p, ['primevideo', 'amazon', 'prime video'], true)) $p = 'prime';

    $map = [
        'apple' => [
            'https://www.justwatch.com/kr/provider/apple-tv-plus/movies',
            'https://www.justwatch.com/kr/provider/apple-tv-plus/tv-shows',
            'https://tv.apple.com/kr/channel/tvs.sbd.4000'
        ],
        'prime' => [
            'https://www.justwatch.com/kr/provider/amazon-prime-video/movies',
            'https://www.justwatch.com/kr/provider/amazon-prime-video/tv-shows',
            'https://www.primevideo.com/storefront/home/ref=atv_nb_lcl_ko_KR'
        ],
    ];
    return [$p, $map[$p] ?? []];
}
}

if (!function_exists('sm_ott_crawled_titles')) {
function sm_ott_crawled_titles($provider = 'apple', $limit = 20) {
    list($prov, $urls) = sm_ott_crawl_sources($provider);
    $limit = max(5, min(50, (int)$limit));

    return tmdb_cache("crawl_titles_{$prov}", 21600, function() use ($prov, $urls, $limit) {
        $titles = [];
        foreach ($urls as $u) {
            $html = sm_http_get($u, 10);
            if ($html) {
                $ext = sm_extract_titles_from_html($html, $limit * 2);
                if ($ext) $titles = array_merge($titles, $ext);
            }
            if (count($titles) >= $limit) break;
        }

        $fallback = [
            'apple' => ['세브란스: 단절', '파친코', '슬로 호시스', '테드 래소', '파운데이션', '실로', '모닝쇼', '하이재킹'],
            'prime' => ['더 보이즈', '반지의 제왕: 힘의 반지', '잭 라이언', '리처', '폴아웃', '로드 하우스', '젠 V', '미스터 & 미세스 스미스']
        ];

        $titles = sm_unique_titles($titles, $limit);
        $source = 'crawl';
        if (count($titles) < 6) {
            $titles = array_slice($fallback[$prov] ?? [], 0, $limit);
            $source = 'fallback';
        }

        return [
            'provider' => $prov,
            'titles' => $titles,
            'source' => $source,
            'updated_at' => date('c')
        ];
    });
}
}

if (!function_exists('sm_titles_to_tmdb_cards')) {
function sm_titles_to_tmdb_cards($titles, $media = 'multi', $limit = 10) {
    $out = [];
    $seen = [];
    foreach ((array)$titles as $t) {
        $q = trim((string)$t);
        if ($q === '') continue;
        $sr = tmdb_search($q, $media === 'multi' ? 'multi' : ($media === 'tv' ? 'tv' : 'movie'));
        $list = $sr['results'] ?? [];
        if (!$list) continue;

        $picked = null;
        foreach ($list as $it) {
            $mt = $it['media_type'] ?? ($media === 'tv' ? 'tv' : 'movie');
            if ($media !== 'multi' && $mt !== $media) continue;
            if (!empty($it['poster_path']) && !empty($it['id'])) { $picked = $it; break; }
            if (!$picked && !empty($it['id'])) $picked = $it;
        }
        if (!$picked) continue;

        $id = (int)($picked['id'] ?? 0);
        $mt = $picked['media_type'] ?? ($media === 'tv' ? 'tv' : 'movie');
        $key = $mt . ':' . $id;
        if ($id <= 0 || isset($seen[$key])) continue;
        $seen[$key] = true;

        $out[] = [
            'id' => $id,
            'media' => $mt,
            'title' => (string)($picked['title'] ?? $picked['name'] ?? $q),
            'poster_path' => (string)($picked['poster_path'] ?? ''),
            'vote_average' => (float)($picked['vote_average'] ?? 0),
        ];
        if (count($out) >= $limit) break;
    }
    return $out;
}
}

if (!function_exists('sm_naver_api_enabled')) {
function sm_naver_api_enabled() {
    return defined('NAVER_CLIENT_ID') && defined('NAVER_CLIENT_SECRET') && NAVER_CLIENT_ID !== '' && NAVER_CLIENT_SECRET !== '';
}
}

if (!function_exists('sm_naver_search_movies')) {
function sm_naver_search_movies($query, $display = 20, $start = 1, $yearfrom = null, $yearto = null) {
    $display = max(1, min(100, (int)$display));
    $start = max(1, min(1000, (int)$start));

    if (!sm_naver_api_enabled()) {
        return ['_error'=>true, '_reason'=>'naver_key_missing', 'items'=>[]];
    }

    $params = [
        'query' => $query,
        'display' => $display,
        'start' => $start,
    ];
    if ($yearfrom !== null) $params['yearfrom'] = (int)$yearfrom;
    if ($yearto !== null) $params['yearto'] = (int)$yearto;

    $url = 'https://openapi.naver.com/v1/search/movie.json?' . http_build_query($params);

    $raw = false; $code = 0;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => [
                'X-Naver-Client-Id: ' . NAVER_CLIENT_ID,
                'X-Naver-Client-Secret: ' . NAVER_CLIENT_SECRET,
                'Accept: application/json'
            ]
        ]);
        $raw = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
    } else {
        $ctx = stream_context_create([
            'http' => [
                'timeout' => 10,
                'header' => "X-Naver-Client-Id: " . NAVER_CLIENT_ID . "
"
                          . "X-Naver-Client-Secret: " . NAVER_CLIENT_SECRET . "
"
                          . "Accept: application/json
"
            ],
            'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]
        ]);
        $raw = @file_get_contents($url, false, $ctx);
        if ($raw !== false) $code = 200;
    }

    $json = json_decode((string)$raw, true);
    if (!$json || $code >= 400) return ['_error'=>true, '_code'=>$code, 'items'=>[]];
    return $json;
}
}

if (!function_exists('sm_clean_html_text')) {
function sm_clean_html_text($s){
    $s = preg_replace('/<[^>]+>/', '', (string)$s);
    return trim(html_entity_decode((string)$s, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
}
}

if (!function_exists('sm_kr_theatrical_trending')) {
function sm_kr_theatrical_trending($limit = 10) {
    $limit = max(4, min(30, (int)$limit));
    $year = (int)date('Y');

    return tmdb_cache('kr_theatrical_trending_' . $limit, 1800, function() use ($limit, $year) {
        $items = [];

        if (sm_naver_api_enabled()) {
            $queries = [
                ['q' => '현재 개봉 한국영화', 'status' => '개봉중'],
                ['q' => '개봉 예정 한국영화', 'status' => '예정'],
            ];
            foreach ($queries as $q) {
                $nav = sm_naver_search_movies($q['q'], 30, 1, $year - 1, $year + 1);
                foreach (($nav['items'] ?? []) as $it) {
                    $title = sm_clean_html_text($it['title'] ?? '');
                    if ($title === '') continue;
                    $pub = trim((string)($it['pubDate'] ?? ''));
                    $tm = tmdb_search($title, 'movie');
                    $picked = null;
                    foreach (($tm['results'] ?? []) as $m) {
                        if (($m['original_language'] ?? '') === 'ko') { $picked = $m; break; }
                        if (!$picked) $picked = $m;
                    }
                    $items[] = [
                        'title' => $title,
                        'status' => $q['status'],
                        'year' => $pub,
                        'tmdb_id' => (int)($picked['id'] ?? 0),
                        'poster_path' => (string)($picked['poster_path'] ?? ''),
                        'vote_average' => (float)($picked['vote_average'] ?? 0),
                        'external_url' => (string)($it['link'] ?? ''),
                    ];
                }
            }
            // dedupe by title
            $seen = []; $dedup = [];
            foreach ($items as $it) {
                $k = sm_mb_lc_tmdb($it['title']);
                if (isset($seen[$k])) continue;
                $seen[$k] = true;
                $dedup[] = $it;
                if (count($dedup) >= $limit) break;
            }
            if ($dedup) {
                return ['results'=>$dedup, 'source'=>'naver+tmdb', 'updated_at'=>date('c')];
            }
        }

        // Fallback: TMDB 기반 (한국어, 개봉중+예정)
        $now = tmdb_discover('movie', [
            'with_original_language' => 'ko',
            'region' => 'KR',
            'sort_by' => 'popularity.desc',
            'release_date.lte' => date('Y-m-d'),
            'vote_count.gte' => 5,
            'page' => 1
        ]);
        $up = tmdb_discover('movie', [
            'with_original_language' => 'ko',
            'region' => 'KR',
            'sort_by' => 'popularity.desc',
            'release_date.gte' => date('Y-m-d'),
            'page' => 1
        ]);

        $mix = [];
        foreach (array_slice($now['results'] ?? [], 0, (int)ceil($limit/2)) as $m) {
            $mix[] = [
                'title' => (string)($m['title'] ?? ''),
                'status' => '개봉중',
                'year' => substr((string)($m['release_date'] ?? ''), 0, 4),
                'tmdb_id' => (int)($m['id'] ?? 0),
                'poster_path' => (string)($m['poster_path'] ?? ''),
                'vote_average' => (float)($m['vote_average'] ?? 0),
                'external_url' => ''
            ];
        }
        foreach (array_slice($up['results'] ?? [], 0, (int)floor($limit/2)) as $m) {
            $mix[] = [
                'title' => (string)($m['title'] ?? ''),
                'status' => '예정',
                'year' => substr((string)($m['release_date'] ?? ''), 0, 4),
                'tmdb_id' => (int)($m['id'] ?? 0),
                'poster_path' => (string)($m['poster_path'] ?? ''),
                'vote_average' => (float)($m['vote_average'] ?? 0),
                'external_url' => ''
            ];
        }

        return ['results'=>array_slice($mix,0,$limit), 'source'=>'tmdb_fallback', 'updated_at'=>date('c')];
    });
}
}

