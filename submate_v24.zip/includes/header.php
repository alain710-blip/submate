<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/tmdb.php';

// HTTPS 강제 비활성화 (인증서 정상화 후 재활성화 권장)


// 호스트 일관성: www -> non-www (스킴 유지)
if (isset($_SERVER['HTTP_HOST']) && strtolower($_SERVER['HTTP_HOST']) === 'www.submate.co.kr' && !headers_sent()) {
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $scheme = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
               (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443) ||
               (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https'))
              ? 'https' : 'http';
    header('Location: ' . $scheme . '://submate.co.kr' . $uri, true, 301);
    exit;
}

$_user = current_user();
$_logged = is_logged_in();
$_admin = is_admin_user();
$_page_title = $page_title ?? 'SubMate PRO';
$_cur = basename($_SERVER['SCRIPT_NAME'] ?? '');
function sm_nav_active($page) { global $_cur; return ($_cur === $page) ? ' style="color:#ff8c00;font-weight:900"' : ''; }
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="format-detection" content="telephone=no">
<meta name="theme-color" content="#0a0e1a">
<title><?php echo htmlspecialchars($_page_title); ?></title>
<link rel="icon" href="assets/img/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="sm-header">
  <div class="sm-header-inner">
    <a href="index.php" class="sm-logo"><img src="assets/img/logo.svg" alt="SubMate" height="32"></a>
    <nav class="sm-nav">
      <a href="index.php"<?php echo sm_nav_active('index.php'); ?>>홈</a>
      <a href="trending.php"<?php echo sm_nav_active('trending.php'); ?>>트렌딩</a>
      <a href="search.php"<?php echo sm_nav_active('search.php'); ?>>검색</a>
      <a href="match.php"<?php echo sm_nav_active('match.php'); ?>>OTT매칭</a>
      <?php if($_logged): ?><a href="mypage.php"<?php echo sm_nav_active('mypage.php'); ?>>나의구독</a><?php endif; ?>
      <a href="ott_info.php"<?php echo sm_nav_active('ott_info.php'); ?>>OTT비교</a>
      <a href="boxoffice.php"<?php echo sm_nav_active('boxoffice.php'); ?>>박스오피스</a>
      <a href="sports.php"<?php echo sm_nav_active('sports.php'); ?>>스포츠</a>
      <a href="community.php"<?php echo sm_nav_active('community.php'); ?>>커뮤니티</a>
      <a href="ranking.php"<?php echo sm_nav_active('ranking.php'); ?>>포인트랭킹</a>
      <?php if($_admin): ?><a href="admin_dashboard.php" style="color:var(--red)">관리자</a><?php endif; ?>
    </nav>
    <div class="sm-nav-right">
      <?php if($_logged): ?>
        <span style="font-size:12px;color:#94a3b8;font-weight:700"><?php echo htmlspecialchars($_user['name'] ?? $_user['email']); ?>님</span>
        <a href="logout.php" class="sm-btn sm-btn-sm">로그아웃</a>
      <?php else: ?>
        <a href="login.php" class="sm-btn sm-btn-primary sm-btn-sm">로그인</a>
        <a href="register.php" class="sm-btn sm-btn-sm">회원가입</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<div class="sm-mobile-nav">
  <a href="index.php"<?php echo sm_nav_active('index.php'); ?>><strong>🏠</strong>홈</a>
  <a href="trending.php"<?php echo sm_nav_active('trending.php'); ?>><strong>🔥</strong>트렌딩</a>
  <a href="community.php"<?php echo sm_nav_active('community.php'); ?>><strong>💬</strong>커뮤니티</a>
  <a href="boxoffice.php"<?php echo sm_nav_active('boxoffice.php'); ?>><strong>🎬</strong>박스오피스</a>
  <?php if($_logged): ?><a href="mypage.php"<?php echo sm_nav_active('mypage.php'); ?>><strong>👤</strong>내정보</a><?php else: ?><a href="login.php"<?php echo sm_nav_active('login.php'); ?>><strong>👤</strong>로그인</a><?php endif; ?>
</div>
<div class="sm-wrap sm-fadein">
