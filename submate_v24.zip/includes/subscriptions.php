<?php
require_once __DIR__ . '/auth.php';

function get_subs($uid) {
    $all = read_json('subscriptions.json');
    return array_values(array_filter($all, function($s) use($uid) { return ($s['user_id'] ?? '') == $uid; }));
}

function add_sub($uid, $d) {
    $all = read_json('subscriptions.json'); $id = 1;
    foreach ($all as $s) $id = max($id, (int)($s['id'] ?? 0) + 1);
    $d['id'] = $id; $d['user_id'] = $uid; $d['created_at'] = date('c');
    $all[] = $d; write_json('subscriptions.json', $all); return $id;
}

function update_sub($uid, $id, $d) {
    $all = read_json('subscriptions.json');
    foreach ($all as &$s) { if ((int)($s['id'] ?? 0) === (int)$id && ($s['user_id'] ?? '') == $uid) { foreach ($d as $k => $v) $s[$k] = $v; break; } }
    write_json('subscriptions.json', $all);
}

function delete_sub($uid, $id) {
    $all = read_json('subscriptions.json');
    $all = array_values(array_filter($all, function($s) use($uid, $id) { return !((int)($s['id'] ?? 0) === (int)$id && ($s['user_id'] ?? '') == $uid); }));
    write_json('subscriptions.json', $all);
}

function next_charge($day, $cyc = 'monthly', $start = null) {
    $t = new DateTime('today');
    if (strtolower($cyc) === 'yearly' && $start) {
        $sd = DateTime::createFromFormat('Y-m-d', $start);
        if ($sd) { $c = new DateTime($t->format('Y') . '-' . $sd->format('m-d')); if ($c < $t) $c->modify('+1 year'); return $c->format('Y-m-d'); }
    }
    $y = (int)$t->format('Y'); $m = (int)$t->format('m'); $l = cal_days_in_month(CAL_GREGORIAN, $m, $y);
    $d = min(max(1, (int)$day), $l); $c = new DateTime("$y-$m-$d");
    if ($c < $t) { $c->modify('first day of next month'); $y2 = (int)$c->format('Y'); $m2 = (int)$c->format('m'); $l2 = cal_days_in_month(CAL_GREGORIAN, $m2, $y2); $c->setDate($y2, $m2, min((int)$day, $l2)); }
    return $c->format('Y-m-d');
}

function days_until($ymd) { $d = DateTime::createFromFormat('Y-m-d', $ymd); if (!$d) return null; return (int)(new DateTime('today'))->diff($d)->format('%r%a'); }
function monthly_equiv($cost, $cyc) { return strtolower(trim($cyc)) === 'yearly' ? (int)round($cost / 12) : (int)$cost; }
