</div>
<footer class="sm-footer"><p><b>SubMate PRO</b> — 스마트 구독 관리 플랫폼 · TMDB API</p></footer>
<script src="assets/js/submate.js"></script>
</body>
</html>
