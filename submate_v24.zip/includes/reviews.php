<?php
require_once __DIR__ . '/auth.php';

function get_reviews($media, $id) {
    $all = read_json('reviews.json');
    return array_values(array_filter($all, function($r) use($media, $id) {
        return ($r['media']??'')===$media && (int)($r['content_id']??0)===(int)$id;
    }));
}

function add_review($media, $id, $uid, $uname, $rating, $text) {
    $all = read_json('reviews.json');
    // 기존 리뷰 업데이트
    foreach ($all as &$r) {
        if (($r['media']??'')===$media && (int)($r['content_id']??0)===(int)$id && (int)($r['user_id']??0)===(int)$uid) {
            $r['rating'] = $rating; $r['text'] = $text; $r['updated_at'] = date('c');
            write_json('reviews.json', $all); return;
        }
    }
    $all[] = ['media'=>$media, 'content_id'=>$id, 'user_id'=>$uid, 'user_name'=>$uname, 'rating'=>$rating, 'text'=>$text, 'created_at'=>date('c')];
    write_json('reviews.json', $all);
}

function avg_rating($media, $id) {
    $revs = get_reviews($media, $id);
    if (!$revs) return ['avg'=>0, 'count'=>0];
    $sum = 0; foreach ($revs as $r) $sum += (float)($r['rating']??0);
    return ['avg'=>round($sum/count($revs), 1), 'count'=>count($revs)];
}

// YouTube API 호출
if (!function_exists('youtube_trending')) {
function youtube_trending($max = 10) {
    if (!defined('YOUTUBE_API_KEY') || !YOUTUBE_API_KEY) return [];
    $dir = __DIR__ . '/../data/cache';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $f = $dir . '/yt_trending.json';
    if (file_exists($f) && (time() - filemtime($f)) < 3600) {
        $d = json_decode(file_get_contents($f), true);
        if ($d) return $d;
    }
    $url = "https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&chart=mostPopular&regionCode=KR&maxResults={$max}&key=" . YOUTUBE_API_KEY;
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>8, CURLOPT_SSL_VERIFYPEER=>false]);
    $r = curl_exec($ch); curl_close($ch);
    $d = json_decode($r, true);
    if ($d && isset($d['items'])) { @file_put_contents($f, $r); return $d; }
    return [];
}
}

// OTT 이벤트/할인 정보
function get_ott_events() {
    return [
        ['ott'=>'넷플릭스','logo'=>'images/ottlogo/netflix.png','event'=>'광고형 스탠다드 첫달 50% 할인','expire'=>'2026-03-31','color'=>'#E50914','url'=>'https://www.netflix.com'],
        ['ott'=>'티빙','logo'=>'images/ottlogo/tving.png','event'=>'연간구독 30% 할인 프로모션','expire'=>'2026-02-28','color'=>'#FF0000','url'=>'https://www.tving.com'],
        ['ott'=>'웨이브','logo'=>'images/ottlogo/wavve.png','event'=>'신규가입 첫달 100원','expire'=>'2026-03-15','color'=>'#00C8FF','url'=>'https://www.wavve.com'],
        ['ott'=>'디즈니+','logo'=>'images/ottlogo/disneyplus.png','event'=>'연간 구독 2개월 무료 혜택','expire'=>'2026-04-30','color'=>'#113CCF','url'=>'https://www.disneyplus.com'],
        ['ott'=>'왓챠','logo'=>'images/ottlogo/watcha.png','event'=>'프리미엄 업그레이드 3개월 무료','expire'=>'2026-03-31','color'=>'#FF0066','url'=>'https://watcha.com'],
        ['ott'=>'쿠팡플레이','logo'=>'images/ottlogo/coupangplay.png','event'=>'로켓와우 무료체험 30일','expire'=>'상시','color'=>'#ff7a00','url'=>'https://www.coupangplay.com'],
        ['ott'=>'Apple TV+','logo'=>'images/ottlogo/appletvplus.png','event'=>'Apple 기기 구매시 3개월 무료','expire'=>'상시','color'=>'#0A84FF','url'=>'https://tv.apple.com'],
        ['ott'=>'Prime Video','logo'=>'images/ottlogo/primevideo.png','event'=>'프라임 연간 결제시 할인','expire'=>'2026-06-30','color'=>'#00A8E1','url'=>'https://www.primevideo.com'],
        ['ott'=>'유튜브 프리미엄','logo'=>'images/ottlogo/youtubepremium.png','event'=>'가족요금제 첫달 무료','expire'=>'2026-04-30','color'=>'#FF0000','url'=>'https://www.youtube.com/premium'],
    ];
}
