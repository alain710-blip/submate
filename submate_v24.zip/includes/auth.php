<?php
session_start();

function data_path() {
    $d = __DIR__ . '/../data';
    if (!is_dir($d)) @mkdir($d, 0755, true);
    return $d;
}

function read_json($file) {
    $p = data_path() . '/' . $file;
    return file_exists($p) ? (json_decode(file_get_contents($p), true) ?: []) : [];
}

function write_json($file, $data) {
    $p = data_path() . '/' . $file;
    $fp = fopen($p, 'c+');
    if ($fp && flock($fp, LOCK_EX)) {
        ftruncate($fp, 0); rewind($fp);
        fwrite($fp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        fflush($fp); flock($fp, LOCK_UN);
    }
    if ($fp) fclose($fp);
}

function current_user() { return $_SESSION['user'] ?? null; }
function is_logged_in() { return isset($_SESSION['user']['email']); }
function require_login() { if (!is_logged_in()) { header('Location: login.php'); exit; } }
function require_admin() { require_login(); if ((current_user()['role'] ?? '') !== 'admin') { http_response_code(403); echo '관리자만 접근 가능'; exit; } }
function is_admin_user() { return (current_user()['role'] ?? '') === 'admin'; }

function find_user($email) {
    foreach (read_json('users.json') as $u) { if (($u['email'] ?? '') === $email) return $u; }
    return null;
}

function find_user_by_id($id) {
    foreach (read_json('users.json') as $u) { if ((int)($u['id'] ?? 0) === (int)$id) return $u; }
    return null;
}

function save_user($data) {
    $users = read_json('users.json'); $id = 1;
    foreach ($users as $u) $id = max($id, (int)($u['id'] ?? 0) + 1);
    $data['id'] = $id;
    $data['created_at'] = date('c');
    $data['last_login'] = date('c');
    if (!isset($data['role'])) $data['role'] = 'user';
    if (!isset($data['status'])) $data['status'] = 'active';
    if (!isset($data['phone'])) $data['phone'] = '';
    if (!isset($data['memo'])) $data['memo'] = '';
    if (!isset($data['login_count'])) $data['login_count'] = 0;
    $users[] = $data;
    write_json('users.json', $users);
    return $id;
}

function update_user($email, $fields) {
    $users = read_json('users.json');
    foreach ($users as &$u) {
        if (($u['email'] ?? '') === $email) { foreach ($fields as $k => $v) $u[$k] = $v; break; }
    }
    write_json('users.json', $users);
}

function update_user_by_id($id, $fields) {
    $users = read_json('users.json');
    foreach ($users as &$u) {
        if ((int)($u['id'] ?? 0) === (int)$id) { foreach ($fields as $k => $v) $u[$k] = $v; break; }
    }
    write_json('users.json', $users);
}

function delete_user_by_id($id) {
    $users = read_json('users.json');
    $users = array_values(array_filter($users, function($u) use($id) {
        return !((int)($u['id'] ?? 0) === (int)$id && ($u['role'] ?? '') !== 'admin');
    }));
    write_json('users.json', $users);
}

function add_admin_user($data) {
    if (find_user($data['email'])) return false;
    $data['password_hash'] = password_hash($data['password'], PASSWORD_BCRYPT);
    unset($data['password']);
    return save_user($data);
}

// 접속 기록
function log_access($uid, $extra = []) {
    $logs = read_json('access_logs.json');
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $device = 'PC';
    if (preg_match('/Mobile|Android|iPhone|iPad/i', $ua)) $device = preg_match('/iPad|Tablet/i', $ua) ? 'Tablet' : 'Mobile';
    $browser = 'Other';
    if (preg_match('/Chrome/i', $ua) && !preg_match('/Edg/i', $ua)) $browser = 'Chrome';
    elseif (preg_match('/Safari/i', $ua) && !preg_match('/Chrome/i', $ua)) $browser = 'Safari';
    elseif (preg_match('/Firefox/i', $ua)) $browser = 'Firefox';
    elseif (preg_match('/Edg/i', $ua)) $browser = 'Edge';
    elseif (preg_match('/MSIE|Trident/i', $ua)) $browser = 'IE';
    $os = 'Other';
    if (preg_match('/Windows/i', $ua)) $os = 'Windows';
    elseif (preg_match('/Mac OS/i', $ua)) $os = 'macOS';
    elseif (preg_match('/Android/i', $ua)) $os = 'Android';
    elseif (preg_match('/iPhone|iPad/i', $ua)) $os = 'iOS';
    elseif (preg_match('/Linux/i', $ua)) $os = 'Linux';
    $logs[] = array_merge(['user_id'=>$uid, 'ip'=>$_SERVER['REMOTE_ADDR']??'', 'ua'=>$ua, 'device'=>$device, 'browser'=>$browser, 'os'=>$os, 'time'=>date('c')], $extra);
    if (count($logs) > 5000) $logs = array_slice($logs, -5000);
    write_json('access_logs.json', $logs);
}

function get_access_logs($uid = null) {
    $logs = read_json('access_logs.json');
    if ($uid !== null) $logs = array_filter($logs, function($l) use($uid) { return ($l['user_id'] ?? '') == $uid; });
    return array_values($logs);
}

// 가입 추이 (월별)
function get_signup_trend() {
    $users = read_json('users.json'); $m = [];
    foreach ($users as $u) {
        $ym = substr($u['created_at'] ?? '', 0, 7);
        if ($ym) $m[$ym] = ($m[$ym] ?? 0) + 1;
    }
    ksort($m); return $m;
}

// 기기 분포
function get_device_stats() {
    $logs = read_json('access_logs.json');
    $d = ['PC'=>0,'Mobile'=>0,'Tablet'=>0]; $b = []; $o = [];
    foreach ($logs as $l) {
        $d[$l['device'] ?? 'PC'] = ($d[$l['device'] ?? 'PC'] ?? 0) + 1;
        $bn = $l['browser'] ?? 'Other'; $b[$bn] = ($b[$bn] ?? 0) + 1;
        $on = $l['os'] ?? 'Other'; $o[$on] = ($o[$on] ?? 0) + 1;
    }
    return ['device'=>$d, 'browser'=>$b, 'os'=>$o, 'total'=>count($logs)];
}
