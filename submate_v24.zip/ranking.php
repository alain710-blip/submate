<?php
ini_set("display_errors", 1); error_reporting(E_ALL);
$page_title = '포인트 랭킹'; require_once 'includes/header.php'; require_once 'includes/community.php';
$ranking = get_point_ranking(100);
?>
<div class="sm-panel" style="text-align:center;padding:24px"><h1 style="font-size:24px;font-weight:900">🏆 포인트 랭킹 TOP 100</h1><p style="color:var(--muted)">커뮤니티 활동으로 포인트를 모아보세요</p>
<div style="display:flex;gap:10px;justify-content:center;margin-top:12px">
<span class="sm-badge"><span class="dot" style="background:var(--green)"></span>글 작성 3~10P</span>
<span class="sm-badge"><span class="dot" style="background:var(--accent)"></span>댓글 2P</span>
<span class="sm-badge"><span class="dot" style="background:var(--accent2)"></span>리뷰 10P</span>
</div></div>

<?php if(empty($ranking)): ?>
<div class="sm-panel" style="text-align:center;padding:40px;color:var(--muted)">아직 랭킹 데이터가 없습니다. 커뮤니티에 글을 작성해보세요!</div>
<?php else: ?>
<!-- TOP 3 특별 표시 -->
<?php if(count($ranking) >= 3): ?>
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:20px">
<?php foreach(array_slice($ranking, 0, 3) as $i => $r): $medal = ['🥇','🥈','🥉'][$i]; $colors = ['#ffd700','#c0c0c0','#cd7f32'][$i]; ?>
<div class="sm-panel" style="text-align:center;padding:20px;border:2px solid <?php echo $colors; ?>40">
<div style="font-size:36px;margin-bottom:4px"><?php echo $medal; ?></div>
<div style="width:50px;height:50px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;font-weight:900;color:#fff;font-size:18px;margin:0 auto 8px"><?php echo mb_substr($r['user']['name']??'?',0,1); ?></div>
<div style="font-weight:900;font-size:16px"><?php echo htmlspecialchars($r['user']['name']??''); ?></div>
<div style="font-size:24px;font-weight:900;color:var(--accent);margin-top:4px"><?php echo number_format($r['points']); ?>P</div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<div class="sm-panel" style="overflow:auto">
<table class="sm-table"><thead><tr><th>순위</th><th>회원</th><th style="text-align:right">포인트</th></tr></thead><tbody>
<?php foreach($ranking as $r): $rc = $r['user']['role']==='admin'?'var(--red)':($r['user']['role']==='premium'?'var(--accent2)':'var(--accent)'); ?>
<tr><td style="font-weight:900;font-size:16px;color:var(--accent)"><?php echo $r['rank']; ?></td>
<td><div style="display:flex;align-items:center;gap:8px"><div style="width:30px;height:30px;border-radius:50%;background:<?php echo $rc; ?>;display:flex;align-items:center;justify-content:center;font-weight:900;color:#fff;font-size:12px"><?php echo mb_substr($r['user']['name']??'?',0,1); ?></div><div><div style="font-weight:800"><?php echo htmlspecialchars($r['user']['name']??''); ?></div><div style="font-size:10px;color:var(--muted)"><span class="sm-pill" style="color:<?php echo $rc; ?>"><?php echo $r['user']['role']??'user'; ?></span></div></div></div></td>
<td style="text-align:right;font-weight:900;font-size:16px;color:var(--green)"><?php echo number_format($r['points']); ?>P</td></tr>
<?php endforeach; ?>
</tbody></table></div>
<?php endif; ?>
<?php require_once 'includes/footer.php'; ?>
