<?php
ini_set("display_errors",1); error_reporting(E_ALL);
$page_title = '박스오피스 · 개봉영화'; require_once 'includes/header.php';

if (isset($_GET['clear_cache']) && function_exists('is_admin_user') && is_admin_user()) {
    $cd = __DIR__ . '/data/cache';
    if (is_dir($cd)) foreach(glob($cd.'/tmdb_*.json') as $cf) @unlink($cf);
    echo '<div class="sm-alert sm-alert-success">✓ 캐시 초기화</div>';
}

$sel_year  = (int)($_GET['y'] ?? date('Y'));
$sel_month = (int)($_GET['m'] ?? date('m'));

$daily_box  = @kobis_daily_boxoffice() ?: [];
$weekly_box = @kobis_weekly_boxoffice() ?: [];
$now_play   = @tmdb_now_playing() ?: [];
$upcoming   = @tmdb_upcoming() ?: [];

// KOBIS → TMDB 매칭 + 카드 변환
function kobis_match($box_list) {
    $cards = [];
    foreach ($box_list as $m) {
        $title = $m['movieNm']??'';
        $sr = @tmdb_search($title, 'movie');
        $tid = 0; $poster = '';
        if (!empty($sr['results'])) { $tid=(int)$sr['results'][0]['id']; $poster=$sr['results'][0]['poster_path']??''; }
        $cards[] = ['title'=>$title,'rank'=>(int)($m['rank']??0),'tmdb_id'=>$tid,'poster_path'=>$poster,
            'audiAcc'=>(int)($m['audiAcc']??0),'audiDay'=>(int)($m['audiCnt']??0),
            'salesAcc'=>(int)($m['salesAcc']??0),'openDt'=>$m['openDt']??'',
            'isNew'=>($m['rankOldAndNew']??'')==='NEW','movieCd'=>$m['movieCd']??''];
    }
    return $cards;
}

// 리스트 렌더링 (순위 리스트 형식)
function render_box_list($cards, $sectionId) {
    if (empty($cards)) {
        echo '<div class="sm-panel" style="text-align:center;padding:30px;color:var(--muted)"><p>KOBIS 박스오피스 데이터를 불러올 수 없습니다.</p><p style="font-size:11px;margin-top:6px">서버의 외부 HTTPS 접속 또는 캐시를 확인해주세요.</p></div>';
        return;
    }
    echo '<div class="sm-panel" style="padding:0;overflow:hidden" id="'.$sectionId.'">';
    foreach ($cards as $i => $m) {
        $hidden = ($i >= 10) ? ' style="display:none"' : '';
        $rank = $m['rank'];
        $rc = ($rank<=3) ? '#ff8c00' : 'var(--text)';
        $poster = $m['poster_path'] ? TMDB_IMG.$m['poster_path'] : '';
        $link = $m['tmdb_id'] ? 'movie.php?id='.$m['tmdb_id'].'&media=movie' : '#';
        $audiTxt = ($m['audiAcc']>=10000) ? number_format(round($m['audiAcc']/10000,1),1).'만명' : number_format($m['audiAcc']).'명';
        $dayTxt = number_format($m['audiDay']);
        $salesTxt = ($m['salesAcc']>0) ? number_format(round($m['salesAcc']/100000000)).'억원' : '';
        // 예매 링크
        $q = urlencode($m['title']);
        $cgv = "http://www.cgv.co.kr/search/?query={$q}";
        $lotte = "https://www.lottecinema.co.kr/NLCHS/Movie/MovieSearch?find={$q}";
        $mega = "https://www.megabox.co.kr/movie?searchText={$q}";

        echo '<div class="sm-grid-item" data-idx="'.$i.'"'.$hidden.'>';
        echo '<div style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-bottom:1px solid var(--stroke)">';
        // 순위
        echo '<span style="font-weight:900;font-size:20px;color:'.$rc.';min-width:30px;text-align:center">'.$rank.'</span>';
        // 포스터
        if ($poster) echo '<a href="'.$link.'"><img src="'.$poster.'" style="width:42px;height:60px;border-radius:6px;object-fit:cover"></a>';
        // 정보
        echo '<div style="flex:1;min-width:0">';
        echo '<a href="'.$link.'" style="font-weight:900;font-size:14px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'.htmlspecialchars($m['title']);
        if ($m['isNew']) echo ' <span style="color:var(--yellow);font-size:9px;font-weight:900">NEW</span>';
        echo '</a>';
        echo '<div style="font-size:11px;color:var(--muted);margin-top:2px">'.$m['openDt'].' · 오늘 '.$dayTxt.'명</div>';
        // 예매 링크
        echo '<div style="display:flex;gap:4px;margin-top:4px">';
        echo '<a href="'.$cgv.'" target="_blank" style="font-size:9px;padding:1px 6px;border:1px solid #e01a22;border-radius:4px;color:#e01a22;font-weight:800">CGV</a>';
        echo '<a href="'.$lotte.'" target="_blank" style="font-size:9px;padding:1px 6px;border:1px solid #cf2127;border-radius:4px;color:#cf2127;font-weight:800">롯데시네마</a>';
        echo '<a href="'.$mega.'" target="_blank" style="font-size:9px;padding:1px 6px;border:1px solid #352263;border-radius:4px;color:#9b8bd4;font-weight:800">메가박스</a>';
        echo '</div></div>';
        // 관객수/매출
        echo '<div style="text-align:right;flex-shrink:0">';
        echo '<div style="font-weight:900;font-size:13px">👥 '.$audiTxt.'</div>';
        if ($salesTxt) echo '<div style="font-size:10px;color:var(--muted)">💰 '.$salesTxt.'</div>';
        echo '</div>';
        echo '</div></div>';
    }
    echo '</div>';
    if (count($cards) > 10) {
        echo '<div class="sm-more-wrap" id="'.$sectionId.'More"><button class="sm-btn sm-btn-sm" onclick="smMore(\''.$sectionId.'\',10)" style="margin:8px auto;display:block">더보기 ▼</button></div>';
    }
}

// TMDB 그리드
function render_tmdb_grid($items, $media, $titleKey, $sectionId, $initCount = 10) {
    if (empty($items)) { echo '<div style="text-align:center;padding:20px;color:var(--muted)">데이터가 없습니다.</div>'; return; }
    echo '<div class="sm-grid-wrap" id="'.$sectionId.'">';
    foreach ($items as $i => $m) {
        $hidden = ($i >= $initCount) ? ' style="display:none"' : '';
        $id = (int)($m['id']??0);
        $poster = ($m['poster_path']??'') ? TMDB_IMG.$m['poster_path'] : '';
        $title = htmlspecialchars($m[$titleKey] ?? $m['title'] ?? $m['name'] ?? '');
        $vote = $m['vote_average'] ?? 0;
        $rd = $m['release_date'] ?? '';
        echo '<div class="sm-grid-item" data-idx="'.$i.'"'.$hidden.'>';
        echo '<div class="sm-card sm-grid-card"><a href="movie.php?id='.$id.'&media='.$media.'">';
        echo '<div style="position:relative;overflow:hidden;border-radius:14px">';
        if ($poster) echo '<img class="sm-poster" src="'.$poster.'" loading="lazy">';
        else echo '<div class="sm-poster" style="display:flex;align-items:center;justify-content:center;background:var(--panel);font-size:36px">🎬</div>';
        echo '<span class="sm-rank">'.($i+1).'</span>';
        if ($rd) echo '<span style="position:absolute;top:6px;right:6px;background:rgba(0,0,0,.75);color:var(--yellow);font-size:9px;font-weight:800;padding:2px 6px;border-radius:4px">'.$rd.'</span>';
        echo '</div><div class="sm-card-body"><div class="sm-card-title">'.$title.'</div>';
        echo '<div class="sm-card-meta"><span>⭐ '.number_format((float)$vote,1).'</span></div></div></a></div></div>';
    }
    echo '</div>';
    if (count($items) > $initCount) echo '<div class="sm-more-wrap" id="'.$sectionId.'More"><button class="sm-btn sm-btn-sm" onclick="smMore(\''.$sectionId.'\',10)" style="margin:8px auto;display:block">더보기 ▼</button></div>';
}

$daily_cards  = kobis_match($daily_box);
$weekly_cards = kobis_match($weekly_box);
?>

<div style="text-align:center;padding:24px 16px 12px">
  <h1 style="font-size:clamp(18px,4vw,26px);font-weight:900;margin-bottom:4px">🎬 박스오피스 · 개봉영화</h1>
  <p style="color:var(--muted);font-size:13px">실시간 순위 · 누적관객수 · 극장 예매</p>
</div>

<!-- 📊 일별 박스오피스 -->
<div class="sm-section-header">
  <h2>📊 일별 박스오피스 <span style="font-size:12px;color:var(--muted);font-weight:400"><?php echo date('Y-m-d', strtotime('-1 day')); ?></span></h2>
</div>
<?php render_box_list($daily_cards, 'secDaily'); ?>

<!-- 📈 주간 박스오피스 -->
<div class="sm-section-header"><h2>📈 주간 박스오피스</h2></div>
<?php render_box_list($weekly_cards, 'secWeekly'); ?>

<!-- 🎞️ 현재 상영중 -->
<div class="sm-section-header"><h2>🎞️ 현재 상영중</h2></div>
<?php render_tmdb_grid($now_play['results'] ?? [], 'movie', 'title', 'secNowPlay', 10); ?>

<!-- 🔜 개봉 예정 -->
<div class="sm-section-header"><h2>🔜 개봉 예정작</h2></div>
<?php render_tmdb_grid($upcoming['results'] ?? [], 'movie', 'title', 'secUpcoming', 10); ?>

<!-- 📅 월별 개봉 -->
<div class="sm-section-header"><h2>📅 <?php echo $sel_year; ?>년 월별 개봉</h2></div>
<div style="display:flex;gap:4px;margin-bottom:12px;flex-wrap:wrap">
<?php for($mm=1;$mm<=12;$mm++): $ac=($mm==$sel_month)?'sm-btn-primary':''; ?>
<a href="?y=<?php echo $sel_year; ?>&m=<?php echo $mm; ?>" class="sm-btn sm-btn-sm <?php echo $ac; ?>"><?php echo $mm; ?>월</a>
<?php endfor; ?>
</div>
<?php
$from = "{$sel_year}-".str_pad($sel_month,2,'0',STR_PAD_LEFT)."-01";
$to = date('Y-m-t', strtotime($from));
$monthly = @tmdb_discover('movie', ['region'=>'KR','sort_by'=>'primary_release_date.asc','primary_release_date.gte'=>$from,'primary_release_date.lte'=>$to]) ?: [];
render_tmdb_grid($monthly['results'] ?? [], 'movie', 'title', 'secMonthly', 10);
?>

<script>
function smMore(sid,step){
  var wrap=document.getElementById(sid);if(!wrap)return;
  var items=wrap.querySelectorAll('.sm-grid-item[style*="display:none"]');
  var shown=0;for(var i=0;i<items.length&&shown<step;i++){items[i].style.display='';shown++;}
  if(wrap.querySelectorAll('.sm-grid-item[style*="display:none"]').length===0){var btn=document.getElementById(sid+'More');if(btn)btn.style.display='none';}
}
</script>
<?php require_once 'includes/footer.php'; ?>
