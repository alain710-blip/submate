<?php
ini_set("display_errors",1); error_reporting(E_ALL);
require_once __DIR__ . '/includes/community.php';
if (!function_exists('sm_trim_text_board')) {
    function sm_trim_text_board($text, $width = 30) {
        $text = (string)$text;
        if (function_exists('mb_strimwidth')) return mb_strimwidth($text, 0, $width, '...', 'UTF-8');
        return (strlen($text) > $width) ? substr($text, 0, $width) . '...' : $text;
    }
}
$bk = $_GET['b'] ?? 'free';
$boards = get_boards();
if (!isset($boards[$bk])) { header('Location: community.php'); exit; }
$board = $boards[$bk];
$upload_dir = __DIR__ . '/data/uploads/';
if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action']??'') === 'write') {
    require_login();
    if ($board['admin_only'] && !is_admin_user()) die('관리자만');
    $u = current_user(); $image_url = '';
    if ($bk === 'gallery' && isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','webp']) && $_FILES['image']['size'] <= 5*1024*1024) {
            $fname = 'gl_' . time() . '_' . mt_rand(1000,9999) . '.' . $ext;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $fname)) $image_url = 'data/uploads/' . $fname;
        }
    }
    if (!$image_url && $bk==='gallery' && ($_POST['image_url']??'')) $image_url = $_POST['image_url'];
    add_post($bk, ['title'=>trim($_POST['title']??''), 'content'=>trim($_POST['content']??''), 'image_url'=>$image_url, 'author_id'=>$u['id'], 'author_name'=>$u['name']??$u['email']]);
    header("Location: board.php?b={$bk}&msg=ok"); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action']??'') === 'comment') {
    require_login(); $u = current_user();
    add_comment($bk, (int)$_POST['post_id'], ['content'=>trim($_POST['content']??''), 'author_id'=>$u['id'], 'author_name'=>$u['name']??$u['email']]);
    header("Location: board.php?b={$bk}&view={$_POST['post_id']}&msg=cmt"); exit;
}
if (($_GET['del']??'') && is_logged_in()) {
    $pid=(int)$_GET['del']; $p=get_post($bk,$pid);
    if ($p && ($p['author_id']==current_user()['id'] || is_admin_user())) delete_post($bk,$pid);
    header("Location: board.php?b={$bk}&msg=del"); exit;
}

// 글 수정 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action']??'') === 'edit') {
    require_login(); $u = current_user();
    $eid = (int)($_POST['post_id']??0);
    $ep = get_post($bk, $eid);
    if ($ep && ($ep['author_id']==$u['id'] || is_admin_user())) {
        $fields = ['title'=>trim($_POST['title']??$ep['title']), 'content'=>trim($_POST['content']??$ep['content'])];
        if ($bk === 'gallery') {
            $new_img = '';
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg','jpeg','png','gif','webp']) && $_FILES['image']['size'] <= 5*1024*1024) {
                    $fname = 'gl_' . time() . '_' . mt_rand(1000,9999) . '.' . $ext;
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $fname)) $new_img = 'data/uploads/' . $fname;
                }
            }
            if (!$new_img && ($_POST['image_url']??'')) $new_img = $_POST['image_url'];
            if ($new_img) $fields['image_url'] = $new_img;
        }
        update_post($bk, $eid, $fields);
    }
    header("Location: board.php?b={$bk}&view={$eid}&msg=edited"); exit;
}

$view_id = (int)($_GET['view'] ?? 0);
if ($view_id) {
    increment_views($bk, $view_id);
    $post = get_post($bk, $view_id);
    if (!$post) { header("Location: board.php?b={$bk}"); exit; }
    $page_title = $post['title']; require_once __DIR__ . '/includes/header.php';
    $can_del = is_logged_in() && ($post['author_id']==current_user()['id'] || is_admin_user());
    $can_edit = $can_del;
    $edit_mode = (int)($_GET['edit'] ?? 0) === 1 && $can_edit;
    ?>
    <div style="margin-bottom:8px"><a href="board.php?b=<?php echo $bk; ?>" class="sm-btn sm-btn-sm">← <?php echo $board['name']; ?></a></div>

    <?php if($edit_mode): ?>
    <!-- 수정 폼 -->
    <div class="sm-panel">
    <h2 style="font-size:16px;font-weight:900;margin-bottom:12px">✏️ 글 수정</h2>
    <form method="post" <?php echo $bk==='gallery'?'enctype="multipart/form-data"':''; ?>>
    <input type="hidden" name="action" value="edit">
    <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
    <div class="sm-form-group"><label class="sm-label">제목</label><input name="title" class="sm-input" value="<?php echo htmlspecialchars($post['title']??''); ?>" required></div>
    <?php if($bk==='gallery'): ?>
    <div class="sm-form-group"><label class="sm-label">이미지 변경 (선택)</label>
    <?php if($post['image_url']??''): ?><img src="<?php echo htmlspecialchars($post['image_url']); ?>" style="max-width:200px;border-radius:8px;margin-bottom:6px;display:block"><?php endif; ?>
    <input name="image" type="file" accept="image/*" class="sm-input" style="padding:8px">
    <div style="font-size:10px;color:var(--muted);margin-top:4px">또는 URL: <input name="image_url" class="sm-input" placeholder="https://..." style="margin-top:4px"></div></div>
    <?php endif; ?>
    <div class="sm-form-group"><label class="sm-label">내용</label><textarea name="content" class="sm-input" rows="8" required><?php echo htmlspecialchars($post['content']??''); ?></textarea></div>
    <div style="display:flex;gap:6px"><button type="submit" class="sm-btn sm-btn-primary" style="flex:1">수정 완료</button>
    <a href="?b=<?php echo $bk; ?>&view=<?php echo $post['id']; ?>" class="sm-btn" style="flex:1;text-align:center">취소</a></div></form></div>
    <?php else: ?>
    <!-- 일반 보기 -->
    <div class="sm-panel">
    <h1 style="font-size:clamp(16px,3vw,20px);font-weight:900;margin-bottom:6px"><?php echo htmlspecialchars($post['title']); ?></h1>
    <div style="display:flex;gap:10px;font-size:11px;color:var(--muted);margin-bottom:12px;flex-wrap:wrap">
      <span><?php echo htmlspecialchars($post['author_name']??''); ?></span><span><?php echo substr($post['created_at']??'',0,16); ?></span><span>조회 <?php echo $post['views']??0; ?></span>
      <?php if($can_edit): ?><a href="?b=<?php echo $bk; ?>&view=<?php echo $post['id']; ?>&edit=1" style="color:var(--accent)">수정</a><?php endif; ?>
      <?php if($can_del): ?><a href="?b=<?php echo $bk; ?>&del=<?php echo $post['id']; ?>" onclick="return confirm('삭제?')" style="color:var(--red)">삭제</a><?php endif; ?>
    </div>
    <?php if($bk==='gallery' && ($post['image_url']??'')):
        $img_url = $post['image_url'];
        // 상대경로 처리
        if (strpos($img_url, 'http') !== 0 && strpos($img_url, '/') !== 0) {
            // data/uploads/... 형태 그대로 사용
        }
    ?><img src="<?php echo htmlspecialchars($img_url); ?>" style="max-width:100%;border-radius:14px;margin-bottom:12px"><?php endif; ?>
    <div style="line-height:1.8;white-space:pre-wrap;font-size:14px"><?php echo nl2br(htmlspecialchars($post['content']??'')); ?></div></div>
    <?php endif; ?>
    <div class="sm-panel"><h3 style="margin:0 0 10px;font-size:14px">💬 댓글 <?php echo count($post['comments']??[]); ?></h3>
    <?php foreach(($post['comments']??[]) as $c): ?>
    <div style="padding:8px 0;border-bottom:1px solid var(--stroke)"><div style="display:flex;justify-content:space-between;font-size:11px;color:var(--muted)"><b><?php echo htmlspecialchars($c['author_name']??''); ?></b><span><?php echo substr($c['created_at']??'',0,16); ?></span></div><div style="margin-top:3px;font-size:13px"><?php echo nl2br(htmlspecialchars($c['content']??'')); ?></div></div>
    <?php endforeach; ?>
    <?php if(is_logged_in()): ?>
    <form method="post" style="margin-top:10px"><input type="hidden" name="action" value="comment"><input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
    <textarea name="content" class="sm-input" rows="2" placeholder="댓글" required></textarea>
    <button type="submit" class="sm-btn sm-btn-primary sm-btn-sm" style="margin-top:6px">등록(+2P)</button></form>
    <?php endif; ?></div>
    <?php require_once __DIR__ . '/includes/footer.php'; exit;
}

$page = max(1,(int)($_GET['page']??1));
$search = trim($_GET['q']??'');
$data = get_posts($bk, $page, 20, $search);
$page_title = $board['name']; require_once __DIR__ . '/includes/header.php';
$can_write = is_logged_in() && (!$board['admin_only'] || is_admin_user());
$write_open = (int)($_GET['write'] ?? 0) === 1;
?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;flex-wrap:wrap;gap:8px">
<div class="sm-badge"><span class="dot"></span><?php echo $board['icon']; ?> <?php echo $board['name']; ?> (<?php echo $data['total']; ?>)</div>
<div style="display:flex;gap:6px;flex-wrap:wrap">
<form method="get" style="display:flex;gap:4px"><input type="hidden" name="b" value="<?php echo $bk; ?>"><input name="q" class="sm-input" style="width:160px;padding:6px 10px;font-size:12px" placeholder="검색" value="<?php echo htmlspecialchars($search); ?>"><button class="sm-btn sm-btn-sm">🔍</button></form>
<?php if($can_write): ?><button class="sm-btn sm-btn-primary sm-btn-sm" onclick="document.getElementById('wf').style.display=document.getElementById('wf').style.display==='none'?'block':'none'">✏️ 글쓰기</button><?php else: ?><a href="login.php" class="sm-btn sm-btn-sm">로그인 후 글쓰기</a><?php endif; ?>
</div></div>

<?php if($can_write): ?>
<div id="wf" class="sm-panel" style="display:<?php echo $write_open?'block':'none'; ?>;margin-bottom:12px">
<form method="post" <?php echo $bk==='gallery'?'enctype="multipart/form-data"':''; ?>>
<input type="hidden" name="action" value="write">
<div class="sm-form-group"><label class="sm-label">제목</label><input name="title" class="sm-input" required></div>
<?php if($bk==='gallery'): ?>
<div class="sm-form-group"><label class="sm-label">이미지 첨부</label>
<input name="image" type="file" accept="image/*" class="sm-input" style="padding:8px">
<div style="font-size:10px;color:var(--muted);margin-top:4px">또는 이미지 URL: <input name="image_url" class="sm-input" placeholder="https://..." style="margin-top:4px"></div>
</div>
<?php endif; ?>
<div class="sm-form-group"><label class="sm-label">내용</label><textarea name="content" class="sm-input" rows="5" required></textarea></div>
<button type="submit" class="sm-btn sm-btn-primary" style="width:100%">등록 (+<?php echo $board['points']; ?>P)</button></form></div>
<?php endif; ?>

<?php if($_GET['msg']??''): ?><div class="sm-alert sm-alert-success">✓ 완료</div><?php endif; ?>

<?php if($bk==='gallery'): ?>
<!-- 갤러리 그리드 뷰 -->
<div class="sm-gallery-grid">
<?php foreach($data['posts'] as $p): if(!($p['image_url']??'')) continue; ?>
<a href="board.php?b=gallery&view=<?php echo $p['id']; ?>" class="sm-gallery-item">
<img src="<?php echo htmlspecialchars($p['image_url']); ?>" loading="lazy">
<div class="sm-gallery-info"><?php echo htmlspecialchars(sm_trim_text_board($p['title']??'',30)); ?></div></a>
<?php endforeach; ?>
</div>
<?php else: ?>
<div class="sm-panel">
<?php if(empty($data['posts'])): ?><div style="text-align:center;padding:24px;color:var(--muted)">게시글이 없습니다.</div>
<?php else: foreach($data['posts'] as $p): ?>
<a href="board.php?b=<?php echo $bk; ?>&view=<?php echo $p['id']; ?>" style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--stroke)">
<div style="flex:1"><div style="font-weight:800;font-size:13px"><?php echo htmlspecialchars($p['title']??''); ?>
<?php $cc=count($p['comments']??[]); if($cc): ?><span style="color:var(--accent);font-size:10px">[<?php echo $cc; ?>]</span><?php endif; ?></div>
<div style="font-size:10px;color:var(--muted);margin-top:2px"><?php echo htmlspecialchars($p['author_name']??''); ?> · <?php echo substr($p['created_at']??'',0,10); ?> · 조회 <?php echo $p['views']??0; ?></div></div></a>
<?php endforeach; endif; ?></div>
<?php endif; ?>

<?php if($data['pages']>1): ?>
<div style="display:flex;gap:4px;justify-content:center;margin:14px 0"><?php for($i=1;$i<=$data['pages'];$i++): ?>
<a href="?b=<?php echo $bk; ?>&page=<?php echo $i; ?><?php echo $search?"&q=".urlencode($search):''; ?>" class="sm-btn sm-btn-sm<?php echo $i===$data['page']?' sm-btn-primary':''; ?>"><?php echo $i; ?></a>
<?php endfor; ?></div>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
