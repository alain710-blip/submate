<?php require_once 'includes/subscriptions.php'; require_login();
$uid = current_user()['id']; $mine = get_subs($uid);
if ($_GET['del'] ?? '') { delete_sub($uid, (int)$_GET['del']); header('Location: mypage.php?msg=ok'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $d = ['category'=>$_POST['category']??'OTT','platform'=>$_POST['platform']??'','plan'=>$_POST['plan']??'','cycle'=>$_POST['cycle']??'monthly','cost'=>(int)($_POST['cost']??0),'billing_day'=>max(1,min(31,(int)($_POST['billing_day']??1))),'start_date'=>$_POST['start_date']??'','payment'=>$_POST['payment']??'','status'=>$_POST['status']??'active','note'=>$_POST['note']??''];
    if (($_POST['action']??'')==='edit' && $_POST['id']) update_sub($uid,(int)$_POST['id'],$d); else add_sub($uid,$d);
    header('Location: mypage.php?msg=ok'); exit;
}
$mine = get_subs($uid); $edit_id = (int)($_GET['edit'] ?? 0); $edit = null;
if ($edit_id) { foreach($mine as $s) { if ((int)($s['id']??0)===$edit_id) $edit=$s; } }
$mT = 0; foreach($mine as $s) { if (($s['status']??'active')==='active') $mT += monthly_equiv((int)($s['cost']??0),$s['cycle']??'monthly'); }
$page_title = '구독관리'; require_once 'includes/header.php';
?>
<div class="sm-panel"><div class="sm-badge"><span class="dot"></span> 💳 나의 구독</div>
<?php if($_GET['msg']??''): ?><p style="margin-top:8px;color:var(--green);font-weight:900">✓ 처리 완료</p><?php endif; ?>
<div class="sm-kpi-row" style="margin-top:14px">
<div class="sm-kpi"><div class="sm-kpi-label">월 구독비</div><div class="sm-kpi-value" style="color:var(--accent)"><?php echo number_format($mT); ?>원</div></div>
<div class="sm-kpi"><div class="sm-kpi-label">연간 예상</div><div class="sm-kpi-value" style="color:var(--accent2)"><?php echo number_format($mT*12); ?>원</div></div>
<div class="sm-kpi"><div class="sm-kpi-label">활성</div><div class="sm-kpi-value" style="color:var(--green)"><?php echo count(array_filter($mine,function($s){return($s['status']??'active')==='active';})); ?></div></div>
<div class="sm-kpi"><div class="sm-kpi-label">전체</div><div class="sm-kpi-value"><?php echo count($mine); ?></div></div>
</div></div>
<?php foreach($mine as $s): $days=days_until(next_charge($s['billing_day']??1,$s['cycle']??'monthly',$s['start_date']??null)); $nd=next_charge($s['billing_day']??1,$s['cycle']??'monthly',$s['start_date']??null); $st=$s['status']??'active'; ?>
<div style="background:var(--panel);border:1px solid var(--stroke);border-radius:16px;padding:16px 20px;margin-bottom:8px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
<div style="display:flex;align-items:center;gap:12px;flex:1"><div style="font-size:22px"><?php echo['OTT'=>'🎬','음악'=>'🎵','오피스'=>'💼'][$s['category']??'']??'📦'; ?></div>
<div><div style="font-weight:900"><?php echo htmlspecialchars($s['platform']??''); ?> <span class="sm-pill" style="color:<?php echo $st==='active'?'var(--green)':($st==='paused'?'var(--yellow)':'var(--red)'); ?>"><?php echo $st==='active'?'사용중':($st==='paused'?'일시정지':'해지'); ?></span></div>
<div style="font-size:11px;color:var(--muted)"><?php echo htmlspecialchars($s['plan']??''); ?> · <?php echo ($s['cycle']??'monthly')==='yearly'?'연간':'월간'; ?></div></div></div>
<div style="font-weight:900;font-size:15px"><?php echo number_format((int)($s['cost']??0)); ?>원</div>
<div style="min-width:60px;text-align:right"><div style="font-weight:800;color:<?php echo $days!==null&&$days<=3?'var(--yellow)':'var(--green)'; ?>"><?php echo $days===0?'D-DAY':($days>0?'D-'.$days:''); ?></div><div style="font-size:10px;color:var(--muted)"><?php echo $nd; ?></div></div>
<div style="display:flex;gap:5px"><a class="sm-btn sm-btn-sm" href="?edit=<?php echo(int)$s['id']; ?>">수정</a><a class="sm-btn sm-btn-sm sm-btn-danger" href="?del=<?php echo(int)$s['id']; ?>" onclick="return confirm('삭제?')">삭제</a></div></div>
<?php endforeach; ?>
<div class="sm-panel" style="margin-top:20px;max-width:800px"><h3 style="margin:0 0 14px"><?php echo $edit?'✏️ 수정':'➕ 구독 추가'; ?></h3>
<form method="post"><input type="hidden" name="action" value="<?php echo $edit?'edit':'add'; ?>"><?php if($edit): ?><input type="hidden" name="id" value="<?php echo(int)$edit['id']; ?>"><?php endif; ?>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
<div class="sm-form-group"><label class="sm-label">카테고리</label><select name="category" class="sm-input"><?php foreach(['OTT','음악','오피스','기타'] as $c): ?><option <?php echo($edit['category']??'OTT')===$c?'selected':''; ?>><?php echo $c; ?></option><?php endforeach; ?></select></div>
<div class="sm-form-group"><label class="sm-label">서비스명*</label><input name="platform" class="sm-input" required value="<?php echo htmlspecialchars($edit['platform']??''); ?>"></div>
<div class="sm-form-group"><label class="sm-label">비용(원)*</label><input name="cost" type="number" class="sm-input" required value="<?php echo $edit['cost']??''; ?>"></div>
<div class="sm-form-group"><label class="sm-label">결제일(1~31)</label><input name="billing_day" type="number" min="1" max="31" class="sm-input" value="<?php echo $edit['billing_day']??1; ?>"></div>
<div class="sm-form-group"><label class="sm-label">플랜</label><input name="plan" class="sm-input" value="<?php echo htmlspecialchars($edit['plan']??''); ?>"></div>
<div class="sm-form-group"><label class="sm-label">주기</label><select name="cycle" class="sm-input"><option value="monthly" <?php echo($edit['cycle']??'monthly')==='monthly'?'selected':''; ?>>월간</option><option value="yearly" <?php echo($edit['cycle']??'')==='yearly'?'selected':''; ?>>연간</option></select></div>
<div class="sm-form-group"><label class="sm-label">시작일</label><input name="start_date" type="date" class="sm-input" value="<?php echo $edit['start_date']??''; ?>"></div>
<div class="sm-form-group"><label class="sm-label">결제수단</label><input name="payment" class="sm-input" value="<?php echo htmlspecialchars($edit['payment']??''); ?>"></div>
<div class="sm-form-group"><label class="sm-label">인원</label><input name="seats" type="number" min="1" class="sm-input" value="<?php echo $edit['seats']??1; ?>"></div>
<div class="sm-form-group"><label class="sm-label">상태</label><select name="status" class="sm-input"><option value="active" <?php echo($edit['status']??'active')==='active'?'selected':''; ?>>사용중</option><option value="paused" <?php echo($edit['status']??'')==='paused'?'selected':''; ?>>일시정지</option><option value="canceled" <?php echo($edit['status']??'')==='canceled'?'selected':''; ?>>해지</option></select></div>
</div><div class="sm-form-group"><label class="sm-label">메모</label><input name="note" class="sm-input" value="<?php echo htmlspecialchars($edit['note']??''); ?>"></div>
<button type="submit" class="sm-btn sm-btn-primary" style="width:100%"><?php echo $edit?'수정':'추가'; ?></button></form></div>
<?php require_once 'includes/footer.php'; ?>
