<?php
ini_set("display_errors",1); error_reporting(E_ALL);
require_once __DIR__ . '/includes/tmdb.php';
require_once __DIR__ . '/includes/community.php';
require_once __DIR__ . '/includes/reviews.php';

$id = (int)($_GET['id'] ?? 0); $media = ($_GET['media'] ?? 'movie') === 'tv' ? 'tv' : 'movie';
if (!$id) { header('Location: index.php'); exit; }

// 리뷰 저장 처리
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='review' && is_logged_in()) {
    $u = current_user();
    add_review($media, $id, $u['id'], $u['name']??$u['email'], (int)$_POST['rating'], trim($_POST['text']??''));
    header("Location: movie.php?id={$id}&media={$media}&msg=review_ok"); exit;
}

if (!function_exists('tmdb_detail')) {
    // tmdb.php 로드 재시도
    $tmdb_path = __DIR__ . '/includes/tmdb.php';
    if (file_exists($tmdb_path)) {
        require_once $tmdb_path;
    }
    if (!function_exists('tmdb_detail')) {
        http_response_code(500);
        echo '<div style="padding:40px;text-align:center;font-family:sans-serif">';
        echo '<h2>⚠️ TMDB 모듈 로딩 실패</h2>';
        echo '<p>includes/tmdb.php 파일을 확인하세요.</p>';
        echo '<p style="color:#999;font-size:12px">경로: ' . htmlspecialchars($tmdb_path) . '</p>';
        echo '<a href="index.php" style="color:#38bdf8">← 메인으로 돌아가기</a></div>';
        exit;
    }
}

$data = tmdb_detail($media, $id);
$title = $data['title'] ?? ($data['name'] ?? '');
$page_title = $title . ' - SubMate';
require_once __DIR__ . '/includes/header.php';

// OTT 제공처 (Netflix Standard with Ads 제거)
$providers = [];
foreach (($data['watch/providers']['results']['KR']['flatrate'] ?? []) as $p) {
    $pn = $p['provider_name'] ?? '';
    if (stripos($pn, 'Ads') !== false || stripos($pn, 'ads') !== false || stripos($pn, '광고') !== false) continue;
    $providers[] = $p;
}
$cast = array_slice($data['credits']['cast'] ?? [], 0, 12);
$similar = array_slice($data['similar']['results'] ?? [], 0, 10);
$yt = null;
foreach(($data['videos']['results'] ?? []) as $v) { if (($v['site']??'')==='YouTube' && ($v['type']??'')==='Trailer') { $yt=$v; break; } }
if (!$yt) foreach(($data['videos']['results'] ?? []) as $v) { if (($v['site']??'')==='YouTube') { $yt=$v; break; } }
$genres = $data['genres'] ?? [];
$reviews = get_reviews($media, $id);
$avgR = avg_rating($media, $id);
?>

<div style="display:grid;grid-template-columns:280px 1fr;gap:20px;margin-bottom:20px">
<div>
<img class="sm-poster" style="border-radius:18px;width:100%" src="<?php echo TMDB_IMG . ($data['poster_path'] ?? ''); ?>">
<?php if($providers): ?>
<div style="margin-top:12px"><div style="font-weight:800;font-size:13px;margin-bottom:6px">📺 지금 바로 시청</div>
<?php foreach($providers as $p): $logo = $p['logo_path'] ? 'https://image.tmdb.org/t/p/w92'.$p['logo_path'] : '';
  $q = urlencode($title);
  $link = '#';
  $pn = $p['provider_name']??'';
  if(stripos($pn,'Netflix')!==false) $link="https://www.netflix.com/search?q={$q}";
  elseif(stripos($pn,'TVING')!==false||stripos($pn,'티빙')!==false) $link="https://www.tving.com/search?keyword={$q}";
  elseif(stripos($pn,'wavve')!==false||stripos($pn,'웨이브')!==false) $link="https://www.wavve.com/search?searchWord={$q}";
  elseif(stripos($pn,'Disney')!==false) $link="https://www.disneyplus.com/search?q={$q}";
  elseif(stripos($pn,'Apple')!==false) $link="https://tv.apple.com/search?term={$q}";
  elseif(stripos($pn,'Amazon')!==false||stripos($pn,'Prime')!==false) $link="https://www.primevideo.com/search?phrase={$q}";
  elseif(stripos($pn,'WATCHA')!==false||stripos($pn,'왓챠')!==false) $link="https://watcha.com/search?query={$q}";
  else $link="https://www.google.com/search?q=".urlencode($pn.' '.$title.' 보기');
?>
<a href="<?php echo $link; ?>" target="_blank" style="display:flex;align-items:center;gap:8px;padding:8px 12px;margin-bottom:4px;background:var(--panel);border:1px solid var(--stroke);border-radius:10px">
<?php if($logo): ?><img src="<?php echo $logo; ?>" style="width:32px;height:32px;border-radius:6px"><?php endif; ?>
<div style="flex:1"><div style="font-weight:800;font-size:12px"><?php echo htmlspecialchars($pn); ?></div><div style="font-size:10px;color:var(--accent)">시청하기 →</div></div></a>
<?php endforeach; ?></div>
<?php endif; ?>
</div>

<div>
<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:6px"><?php foreach($genres as $g): ?><span class="sm-pill"><?php echo htmlspecialchars($g['name']); ?></span><?php endforeach; ?></div>
<h1 style="font-size:clamp(20px,4vw,28px);font-weight:900;line-height:1.2;margin-bottom:8px"><?php echo htmlspecialchars($title); ?></h1>
<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">
<span class="sm-badge">⭐ TMDB <?php echo number_format((float)($data['vote_average']??0),1); ?></span>
<?php if($avgR['count']): ?><span class="sm-badge" style="color:var(--yellow)">⭐ SubMate <?php echo $avgR['avg']; ?> (<?php echo $avgR['count']; ?>명)</span><?php endif; ?>
<span class="sm-badge">📅 <?php echo $data['release_date']??($data['first_air_date']??'-'); ?></span>
</div>
<p style="color:var(--muted);line-height:1.7;font-size:14px;margin-bottom:14px"><?php echo htmlspecialchars($data['overview'] ?? ''); ?></p>

<!-- 출연진 -->
<?php if($cast): ?>
<div style="margin-bottom:14px"><div style="font-weight:800;font-size:13px;margin-bottom:6px">🎭 출연진</div>
<div style="display:flex;gap:8px;overflow-x:auto;padding-bottom:6px">
<?php foreach($cast as $c): $pp=$c['profile_path']?TMDB_IMG.$c['profile_path']:''; ?>
<a href="person.php?id=<?php echo (int)$c['id']; ?>" style="flex:0 0 70px;text-align:center">
<?php if($pp): ?><img src="<?php echo $pp; ?>" style="width:60px;height:60px;border-radius:50%;object-fit:cover;border:2px solid var(--stroke)"><?php else: ?><div style="width:60px;height:60px;border-radius:50%;background:var(--panel);border:2px solid var(--stroke);display:flex;align-items:center;justify-content:center">🎭</div><?php endif; ?>
<div style="font-size:10px;font-weight:800;margin-top:3px"><?php echo htmlspecialchars($c['name']??''); ?></div>
<div style="font-size:9px;color:var(--muted)"><?php echo htmlspecialchars($c['character']??''); ?></div></a>
<?php endforeach; ?></div></div>
<?php endif; ?>
</div></div>

<?php if($yt): ?>
<div class="sm-panel" style="padding:8px"><div style="position:relative;padding-bottom:56.25%;height:0"><iframe style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;border-radius:12px" src="https://www.youtube.com/embed/<?php echo htmlspecialchars($yt['key']); ?>" allowfullscreen></iframe></div></div>
<?php endif; ?>

<!-- 별점/리뷰 (6번) -->
<div class="sm-panel">
<h3 style="margin:0 0 12px;font-size:16px">⭐ 회원 별점 & 리뷰 (<?php echo count($reviews); ?>개)</h3>
<?php if($_GET['msg']??''): ?><div class="sm-alert sm-alert-success">✓ 리뷰 등록 완료</div><?php endif; ?>
<?php if(is_logged_in()): ?>
<form method="post" style="margin-bottom:14px;padding:12px;background:var(--panel);border:1px solid var(--stroke);border-radius:12px">
<input type="hidden" name="action" value="review">
<div style="margin-bottom:8px;font-weight:800;font-size:13px">내 별점</div>
<div class="sm-stars" id="starWidget"><?php for($s=1;$s<=5;$s++): ?><span data-v="<?php echo $s; ?>" onclick="document.getElementById('ratingVal').value=<?php echo $s; ?>;document.querySelectorAll('#starWidget span').forEach(function(x,i){x.className=i<<?php echo $s; ?>?'active':''})">★</span><?php endfor; ?></div>
<input type="hidden" name="rating" id="ratingVal" value="5">
<textarea name="text" class="sm-input" rows="2" placeholder="간단 리뷰 (선택)" style="margin-top:8px"></textarea>
<button type="submit" class="sm-btn sm-btn-primary sm-btn-sm" style="margin-top:8px">리뷰 등록</button>
</form>
<?php else: ?><p style="font-size:13px;color:var(--muted);margin-bottom:10px"><a href="login.php" style="color:var(--accent)">로그인</a> 후 별점을 남길 수 있습니다.</p><?php endif; ?>
<?php foreach(array_reverse($reviews) as $rv): ?>
<div style="padding:10px 0;border-bottom:1px solid var(--stroke)">
<div style="display:flex;justify-content:space-between;align-items:center"><span style="font-weight:800;font-size:13px"><?php echo htmlspecialchars($rv['user_name']??''); ?></span><span style="color:var(--yellow);font-size:14px"><?php echo str_repeat('★',(int)$rv['rating']).str_repeat('☆',5-(int)$rv['rating']); ?></span></div>
<?php if($rv['text']??''): ?><p style="font-size:13px;color:var(--muted);margin-top:4px"><?php echo htmlspecialchars($rv['text']); ?></p><?php endif; ?>
<div style="font-size:10px;color:var(--muted);margin-top:2px"><?php echo substr($rv['created_at']??'',0,10); ?></div>
</div>
<?php endforeach; ?>
</div>

<?php if($similar): ?>
<div class="sm-section-header"><h2>🎯 비슷한 작품</h2></div>
<div class="sm-scroll-row"><?php foreach($similar as $m): ?>
<div class="sm-card"><a href="movie.php?id=<?php echo (int)$m['id']; ?>&media=<?php echo $media; ?>"><img class="sm-poster" src="<?php echo TMDB_IMG.($m['poster_path']??''); ?>" loading="lazy"><div class="sm-card-body"><div class="sm-card-title"><?php echo htmlspecialchars($m['title']??($m['name']??'')); ?></div></div></a></div>
<?php endforeach; ?></div>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
