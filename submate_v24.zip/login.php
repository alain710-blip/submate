<?php
ini_set("display_errors", 1); error_reporting(E_ALL);
require_once 'includes/auth.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? ''); $pw = $_POST['password'] ?? '';
    $u = find_user($email);
    if (!$u) $err = '등록되지 않은 이메일입니다.';
    elseif (!password_verify($pw, $u['password_hash'])) $err = '비밀번호가 틀렸습니다.';
    elseif (($u['status'] ?? '') === 'suspended') $err = '정지된 계정입니다.';
    elseif (($u['status'] ?? '') === 'dormant') $err = '휴면 계정입니다. 관리자에게 문의하세요.';
    else {
        $_SESSION['user'] = ['id'=>$u['id'],'email'=>$u['email'],'name'=>$u['name']??'','role'=>$u['role']??'user'];
        update_user($email, ['last_login'=>date('c'), 'login_count'=>(int)($u['login_count']??0)+1, 'last_ip'=>$_SERVER['REMOTE_ADDR']??'']);
        log_access($u['id'], ['action'=>'login']);
        header('Location: index.php'); exit;
    }
}
$page_title = '로그인'; require_once 'includes/header.php';
?>
<div class="sm-login-wrap"><div class="sm-login-card">
<h1 style="font-size:24px;font-weight:900;text-align:center;margin-bottom:20px"><span style="color:var(--accent)">Sub</span>Mate 로그인</h1>
<?php if($err): ?><div class="sm-alert sm-alert-danger"><?php echo $err; ?></div><?php endif; ?>
<form method="post">
<div class="sm-form-group"><label class="sm-label">이메일</label><input name="email" type="email" class="sm-input" required></div>
<div class="sm-form-group"><label class="sm-label">비밀번호</label><input name="password" type="password" class="sm-input" required></div>
<button type="submit" class="sm-btn sm-btn-primary" style="width:100%;padding:14px">로그인</button>
</form><p style="margin-top:14px;text-align:center;font-size:13px;color:var(--muted)"><a href="register.php" style="color:var(--accent)">회원가입</a></p>
</div></div>
<?php require_once 'includes/footer.php'; ?>
