<?php
ini_set("display_errors", 1); error_reporting(E_ALL);
require_once 'includes/subscriptions.php';
require_admin();

$users = read_json('users.json'); $subs = read_json('subscriptions.json');
$mTotal = 0; foreach($subs as $s) $mTotal += monthly_equiv((int)($s['cost']??0), $s['cycle']??'monthly');
$devStats = get_device_stats();
$page_title = '관리자 대시보드'; require_once 'includes/header.php';
$total = count($users);
$admins = count(array_filter($users, function($u) { return ($u['role']??'')==='admin'; }));
$premiums = count(array_filter($users, function($u) { return ($u['role']??'')==='premium'; }));
$actives = count(array_filter($users, function($u) { return ($u['status']??'active')==='active'; }));
$dormants = count(array_filter($users, function($u) { return ($u['status']??'')==='dormant'; }));
$suspends = count(array_filter($users, function($u) { return ($u['status']??'')==='suspended'; }));
?>
<div class="sm-panel"><div class="sm-badge"><span class="dot"></span> 🛡 관리자 대시보드</div>
<div class="sm-kpi-row" style="margin-top:14px">
  <div class="sm-kpi"><div class="sm-kpi-label">전체 회원</div><div class="sm-kpi-value"><?php echo $total; ?></div></div>
  <div class="sm-kpi"><div class="sm-kpi-label">전체 구독</div><div class="sm-kpi-value" style="color:var(--accent)"><?php echo count($subs); ?></div></div>
  <div class="sm-kpi"><div class="sm-kpi-label">월 총 구독비</div><div class="sm-kpi-value" style="color:var(--green)"><?php echo number_format($mTotal); ?>원</div></div>
  <div class="sm-kpi"><div class="sm-kpi-label">총 접속</div><div class="sm-kpi-value" style="color:var(--yellow)"><?php echo $devStats['total']; ?></div></div>
</div></div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
  <div class="sm-panel"><div class="sm-badge" style="margin-bottom:8px"><span class="dot"></span>회원 상태</div>
    <div style="display:flex;gap:8px">
      <div style="flex:1;background:rgba(52,211,153,.06);border:1px solid rgba(52,211,153,.12);border-radius:12px;padding:14px;text-align:center"><div style="font-size:24px;font-weight:900;color:var(--green)"><?php echo $actives; ?></div><div style="font-size:11px;color:var(--muted)">활성</div></div>
      <div style="flex:1;background:rgba(251,191,36,.06);border:1px solid rgba(251,191,36,.12);border-radius:12px;padding:14px;text-align:center"><div style="font-size:24px;font-weight:900;color:var(--yellow)"><?php echo $dormants; ?></div><div style="font-size:11px;color:var(--muted)">휴면</div></div>
      <div style="flex:1;background:rgba(248,113,113,.06);border:1px solid rgba(248,113,113,.12);border-radius:12px;padding:14px;text-align:center"><div style="font-size:24px;font-weight:900;color:var(--red)"><?php echo $suspends; ?></div><div style="font-size:11px;color:var(--muted)">정지</div></div>
    </div>
  </div>
  <div class="sm-panel"><div class="sm-badge" style="margin-bottom:8px"><span class="dot"></span>기기 접속 현황</div>
    <div style="display:flex;gap:8px">
      <?php foreach(($devStats['device']??[]) as $dk => $dv): ?>
      <div style="flex:1;background:var(--panel);border:1px solid var(--stroke);border-radius:12px;padding:14px;text-align:center"><div style="font-size:20px;font-weight:900;color:var(--accent)"><?php echo $dv; ?></div><div style="font-size:11px;color:var(--muted)"><?php echo $dk; ?></div></div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div style="display:flex;gap:10px;margin-bottom:16px"><a href="admin_members.php" class="sm-btn sm-btn-primary">👥 회원관리 →</a></div>

<div class="sm-panel" style="overflow:auto"><h3 style="margin:0 0 12px">최근 가입 회원</h3>
<table class="sm-table"><thead><tr><th>이름</th><th>이메일</th><th>등급</th><th>상태</th><th>접속</th><th>가입일</th></tr></thead><tbody>
<?php foreach(array_slice(array_reverse($users), 0, 15) as $u): $rc = ($u['role']??'')==='admin'?'var(--red)':(($u['role']??'')==='premium'?'var(--accent2)':'var(--accent)'); ?>
<tr><td style="font-weight:800"><?php echo htmlspecialchars($u['name']??''); ?></td><td style="color:var(--muted);font-size:12px"><?php echo htmlspecialchars($u['email']??''); ?></td>
<td><span class="sm-pill" style="color:<?php echo $rc; ?>"><?php echo $u['role']??'user'; ?></span></td>
<td><span class="sm-pill" style="color:<?php echo ($u['status']??'active')==='active'?'var(--green)':'var(--yellow)'; ?>"><?php echo ($u['status']??'active')==='active'?'활성':(($u['status']??'')==='dormant'?'휴면':'정지'); ?></span></td>
<td style="font-size:11px;color:var(--muted)"><?php echo (int)($u['login_count']??0); ?>회</td>
<td style="font-size:11px;color:var(--muted)"><?php echo substr($u['created_at']??'',0,10); ?></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php require_once 'includes/footer.php'; ?>
