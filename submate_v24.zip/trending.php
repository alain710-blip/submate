<?php $page_title = '트렌딩'; require_once 'includes/header.php';
$media = $_GET['media'] ?? 'movie'; $page = max(1, (int)($_GET['page'] ?? 1));
$data = tmdb_req("trending/{$media}/day", ["page" => $page]); $results = $data['results'] ?? [];
?>
<div class="sm-section-header"><h2>🔥 트렌딩 <?php echo $media === 'tv' ? 'TV' : '영화'; ?></h2>
<div style="display:flex;gap:4px"><a href="?media=movie" class="sm-btn sm-btn-sm <?php echo $media === 'movie' ? 'sm-btn-primary' : ''; ?>">영화</a><a href="?media=tv" class="sm-btn sm-btn-sm <?php echo $media === 'tv' ? 'sm-btn-primary' : ''; ?>">TV</a></div></div>
<div class="sm-grid"><?php foreach($results as $i => $m): $fp = tmdb_kr_prov($media, (int)$m['id']); ?>
<div class="sm-card"><a href="movie.php?id=<?php echo (int)$m['id']; ?>&media=<?php echo $media; ?>">
<div style="position:relative;overflow:hidden;border-radius:14px"><img class="sm-poster" src="<?php echo TMDB_IMG . ($m['poster_path'] ?? ''); ?>" loading="lazy"><span class="sm-rank"><?php echo ($page-1)*20+$i+1; ?></span>
<?php if($fp['has']): ?><div class="sm-ott-tags"><?php foreach(array_slice($fp['pn'], 0, 2) as $pn): ?><span class="sm-pill"><?php echo htmlspecialchars($pn); ?></span><?php endforeach; ?></div><?php endif; ?>
</div><div class="sm-card-body"><div class="sm-card-title"><?php echo htmlspecialchars($m['title'] ?? ($m['name'] ?? '')); ?></div></div></a></div>
<?php endforeach; ?></div>
<div style="display:flex;gap:8px;justify-content:center;margin:20px 0"><?php if($page > 1): ?><a class="sm-btn" href="?media=<?php echo $media; ?>&page=<?php echo $page-1; ?>">← 이전</a><?php endif; ?><a class="sm-btn" href="?media=<?php echo $media; ?>&page=<?php echo $page+1; ?>">다음 →</a></div>
<?php require_once 'includes/footer.php'; ?>
