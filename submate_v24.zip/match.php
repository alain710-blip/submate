<?php
ini_set("display_errors", 1); error_reporting(E_ALL);
$page_title = 'OTT 매칭 추천'; require_once 'includes/header.php';
require_once 'includes/community.php';
$result = null; $sel = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $genres = $_POST['genres'] ?? []; $budget = (int)($_POST['budget'] ?? 15000);
    $prefs = $_POST['prefs'] ?? []; $watch = $_POST['watch'] ?? [];
    $scores = [];
    $plats = [
        ['n'=>'넷플릭스','c'=>'#E50914','logo'=>'https://image.tmdb.org/t/p/w92/pbpMk2JmcoNnQwN5JGpXngfoWtp.jpg','price'=>5500,'max'=>17000,'strong'=>['액션','스릴러','SF','드라마','다큐'],'features'=>['오리지널','4K','다운로드','AI추천'],'url'=>'https://www.netflix.com'],
        ['n'=>'티빙','c'=>'#FF0000','logo'=>'https://image.tmdb.org/t/p/w92/dNAz0MMIPiqCD2axGUZPAMq2gio.jpg','price'=>7900,'max'=>13900,'strong'=>['예능','드라마','스포츠'],'features'=>['국내예능','실시간','tvN'],'url'=>'https://www.tving.com'],
        ['n'=>'웨이브','c'=>'#00C8FF','logo'=>'https://image.tmdb.org/t/p/w92/2ioan5BX5L9tz4fIGU93blTeFhv.jpg','price'=>7900,'max'=>10900,'strong'=>['드라마','뉴스','예능'],'features'=>['지상파','KBS/MBC/SBS'],'url'=>'https://www.wavve.com'],
        ['n'=>'왓챠','c'=>'#FF0066','logo'=>'https://image.tmdb.org/t/p/w92/cNi4Nv5EPsnvf5WR3bm0WGFCid0.jpg','price'=>7900,'max'=>9900,'strong'=>['독립영화','클래식','애니'],'features'=>['취향추천','숨은명작'],'url'=>'https://watcha.com'],
        ['n'=>'디즈니+','c'=>'#113CCF','logo'=>'https://image.tmdb.org/t/p/w92/7rwgEs15tFwyR9NPQ5vpzxTj19Q.jpg','price'=>9900,'max'=>13900,'strong'=>['액션','애니','가족','SF'],'features'=>['마블','픽사','스타워즈','4K'],'url'=>'https://www.disneyplus.com'],
        ['n'=>'쿠팡플레이','c'=>'#ff7a00','logo'=>'','price'=>7890,'max'=>7890,'strong'=>['스포츠','예능','드라마'],'features'=>['로켓와우','쇼핑혜택','SNL'],'url'=>'https://www.coupangplay.com'],
        ['n'=>'Apple TV+','c'=>'#0A84FF','logo'=>'https://image.tmdb.org/t/p/w92/6uhKBfmtzFqOcLousHwZuzcrScK.jpg','price'=>9900,'max'=>9900,'strong'=>['드라마','스릴러','SF'],'features'=>['오리지널','4K HDR','에미상'],'url'=>'https://tv.apple.com'],
        ['n'=>'Prime Video','c'=>'#00A8E1','logo'=>'https://image.tmdb.org/t/p/w92/emthp39XA2YScoYL1p0sdbAH2WA.jpg','price'=>5900,'max'=>5900,'strong'=>['액션','SF','드라마'],'features'=>['글로벌오리지널','X-Ray'],'url'=>'https://www.primevideo.com'],
    ];
    foreach ($plats as &$pl) {
        $s = 50;
        // 장르 매칭
        foreach ($genres as $g) { if (in_array($g, $pl['strong'])) $s += 15; }
        // 예산 체크
        if ($pl['price'] <= $budget) $s += 10;
        if ($pl['price'] > $budget) $s -= 20;
        // 시청 습관
        if (in_array('original', $watch) && in_array('오리지널', $pl['features'])) $s += 10;
        if (in_array('korean', $watch) && (in_array('국내예능', $pl['features']) || in_array('지상파', $pl['features']))) $s += 15;
        if (in_array('kids', $watch) && ($pl['n']==='디즈니+' || in_array('가족', $pl['strong']))) $s += 15;
        if (in_array('sports', $watch) && in_array('스포츠', $pl['strong'])) $s += 15;
        if (in_array('4k', $prefs) && in_array('4K', $pl['features'])) $s += 8;
        if (in_array('cheap', $prefs)) $s += max(0, 20 - (int)($pl['price']/1000));
        $pl['score'] = min(99, max(10, $s));
    }
    usort($plats, function($a,$b) { return $b['score'] <=> $a['score']; });
    $result = $plats; $sel = ['genres'=>$genres,'budget'=>$budget,'prefs'=>$prefs,'watch'=>$watch];
}
?>

<div class="sm-panel" style="text-align:center;padding:30px">
<h1 style="font-size:26px;font-weight:900;margin-bottom:8px">🎯 나에게 맞는 OTT 찾기</h1>
<p style="color:var(--muted)">취향과 예산을 알려주시면 최적의 OTT 플랫폼을 추천해드립니다</p>
</div>

<div class="sm-panel" style="max-width:800px;margin:0 auto 20px">
<form method="post">
<h3 style="margin:0 0 12px">1. 좋아하는 장르 (복수선택)</h3>
<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px">
<?php foreach(['액션','드라마','코미디','스릴러','SF','애니','다큐','예능','스포츠','독립영화','가족','로맨스'] as $g): ?>
<label style="display:flex;align-items:center;gap:4px;padding:6px 12px;border-radius:10px;border:1px solid var(--stroke);background:var(--panel);cursor:pointer;font-size:12px;font-weight:700">
<input type="checkbox" name="genres[]" value="<?php echo $g; ?>" <?php echo in_array($g, $sel['genres']??[]) ? 'checked' : ''; ?> style="accent-color:var(--accent)"><?php echo $g; ?></label>
<?php endforeach; ?>
</div>

<h3 style="margin:0 0 12px">2. 월 예산 (원)</h3>
<div style="margin-bottom:16px"><input type="range" name="budget" min="5000" max="30000" step="1000" value="<?php echo $sel['budget'] ?? 15000; ?>" id="budgetRange" style="width:100%;accent-color:var(--accent)" oninput="document.getElementById('budgetVal').textContent=Number(this.value).toLocaleString()+'원'">
<div style="text-align:center;font-weight:900;font-size:18px;color:var(--accent)" id="budgetVal"><?php echo number_format($sel['budget'] ?? 15000); ?>원</div></div>

<h3 style="margin:0 0 12px">3. 시청 습관</h3>
<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px">
<?php foreach(['original'=>'오리지널 중심','korean'=>'국내 콘텐츠','kids'=>'키즈/가족','sports'=>'스포츠'] as $k=>$v): ?>
<label style="display:flex;align-items:center;gap:4px;padding:6px 12px;border-radius:10px;border:1px solid var(--stroke);background:var(--panel);cursor:pointer;font-size:12px;font-weight:700">
<input type="checkbox" name="watch[]" value="<?php echo $k; ?>" <?php echo in_array($k, $sel['watch']??[]) ? 'checked' : ''; ?> style="accent-color:var(--accent)"><?php echo $v; ?></label>
<?php endforeach; ?>
</div>

<h3 style="margin:0 0 12px">4. 선호 조건</h3>
<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px">
<?php foreach(['4k'=>'4K 화질','cheap'=>'가성비 우선','download'=>'다운로드'] as $k=>$v): ?>
<label style="display:flex;align-items:center;gap:4px;padding:6px 12px;border-radius:10px;border:1px solid var(--stroke);background:var(--panel);cursor:pointer;font-size:12px;font-weight:700">
<input type="checkbox" name="prefs[]" value="<?php echo $k; ?>" <?php echo in_array($k, $sel['prefs']??[]) ? 'checked' : ''; ?> style="accent-color:var(--accent)"><?php echo $v; ?></label>
<?php endforeach; ?>
</div>

<button type="submit" class="sm-btn sm-btn-primary" style="width:100%;padding:16px;font-size:16px">🎯 매칭 결과 보기</button>
</form>
</div>

<?php if($result): ?>
<div style="max-width:800px;margin:0 auto">
<h2 style="text-align:center;margin-bottom:16px">📊 추천 결과</h2>
<?php foreach($result as $i => $pl): $medal = $i===0?'🥇':($i===1?'🥈':($i===2?'🥉':'')); ?>
<div class="sm-panel" style="border-left:3px solid <?php echo $pl['c']; ?>;margin-bottom:10px">
<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
<div style="display:flex;align-items:center;gap:12px">
<div style="font-size:28px"><?php echo $medal ?: ($i+1).'위'; ?></div>
<?php if($pl['logo']): ?><img src="<?php echo $pl['logo']; ?>" style="width:42px;height:42px;border-radius:10px"><?php endif; ?>
<div><div style="font-weight:900;font-size:16px"><?php echo $pl['n']; ?></div>
<div style="font-size:12px;color:var(--muted)">월 <?php echo number_format($pl['price']); ?>원~</div></div>
</div>
<div style="text-align:right">
<div style="font-size:28px;font-weight:900;color:<?php echo $pl['score']>=80?'var(--green)':($pl['score']>=60?'var(--accent)':'var(--muted)'); ?>"><?php echo $pl['score']; ?>점</div>
<div style="width:100px;height:6px;background:var(--panel);border-radius:3px;overflow:hidden"><div style="height:100%;width:<?php echo $pl['score']; ?>%;background:<?php echo $pl['c']; ?>;border-radius:3px"></div></div>
</div>
</div>
<div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:8px">
<?php foreach($pl['features'] as $f): ?><span class="sm-pill"><?php echo $f; ?></span><?php endforeach; ?>
</div>
<a href="<?php echo $pl['url']; ?>" target="_blank" class="sm-btn sm-btn-sm" style="margin-top:8px;border-color:<?php echo $pl['c']; ?>">바로가기 →</a>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
