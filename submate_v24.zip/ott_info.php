<?php
ini_set("display_errors",1); error_reporting(E_ALL);
$page_title = 'OTT 플랫폼 비교'; require_once 'includes/header.php'; require_once 'includes/reviews.php';
$events = get_ott_events();
$otts = [
    ["n"=>"Netflix","nk"=>"넷플릭스","f"=>sm_ott_logo("넷플릭스"),"c"=>"#E50914","p"=>"월 5,500원 ~","sub"=>"12M+","url"=>"https://www.netflix.com","pro"=>"글로벌 오리지널/다양한 장르","con"=>"요금제/정책 변경 빈도"],
    ["n"=>"Disney+","nk"=>"디즈니+","f"=>sm_ott_logo("디즈니+"),"c"=>"#113CCF","p"=>"월 9,900원","sub"=>"2.8M+","url"=>"https://www.disneyplus.com","pro"=>"마블·픽사·스타워즈","con"=>"취향 편차"],
    ["n"=>"TVING","nk"=>"티빙","f"=>sm_ott_logo("티빙"),"c"=>"#FF0000","p"=>"월 5,500원 ~","sub"=>"5.5M+","url"=>"https://www.tving.com","pro"=>"국내 예능/드라마 강점","con"=>"일부 장르 편중"],
    ["n"=>"wavve","nk"=>"웨이브","f"=>sm_ott_logo("웨이브"),"c"=>"#00C8FF","p"=>"월 7,900원 ~","sub"=>"4.3M+","url"=>"https://www.wavve.com","pro"=>"지상파 VOD 강점","con"=>"오리지널 체감 편차"],
    ["n"=>"Watcha","nk"=>"왓챠","f"=>sm_ott_logo("왓챠"),"c"=>"#FF0066","p"=>"월 7,900원","sub"=>"0.8M+","url"=>"https://watcha.com","pro"=>"취향 추천/인디 영화","con"=>"규모 제한"],
    ["n"=>"Coupang Play","nk"=>"쿠팡플레이","f"=>sm_ott_logo("쿠팡플레이"),"c"=>"#ff7a00","p"=>"와우 멤버십 포함","sub"=>"5.0M+","url"=>"https://www.coupangplay.com","pro"=>"가성비/스포츠 중계","con"=>"콘텐츠 볼륨 편차"],
    ["n"=>"Apple TV+","nk"=>"Apple TV+","f"=>sm_ott_logo("Apple TV+"),"c"=>"#0A84FF","p"=>"월 6,500원","sub"=>"1.2M+","url"=>"https://tv.apple.com","pro"=>"완성도 높은 오리지널","con"=>"라이브러리 규모"],
    ["n"=>"Prime Video","nk"=>"Prime Video","f"=>sm_ott_logo("Prime Video"),"c"=>"#00A8E1","p"=>"월 9,900원 ~","sub"=>"0.9M+","url"=>"https://www.primevideo.com","pro"=>"글로벌 히트작/장르물","con"=>"국내 UI 익숙함"],
    ["n"=>"YouTube Premium","nk"=>"유튜브 프리미엄","f"=>sm_ott_logo("유튜브 프리미엄"),"c"=>"#FF0000","p"=>"월 14,900원","sub"=>"13M+","url"=>"https://www.youtube.com/premium","pro"=>"광고 제거+음악","con"=>"영상형 OTT와 성격 다름"],
];
$eventMap = [];
foreach($events as $ev) { $eventMap[$ev['ott']] = $ev; }

function ott_card($o, $ev) { ?>
<div class="sm-panel" style="padding:16px;border-top:2px solid <?php echo $o['c']; ?>;margin-bottom:0">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
    <img src="<?php echo $o['f']; ?>" style="width:32px;height:32px;border-radius:6px">
    <div><div style="font-weight:900;font-size:14px"><?php echo $o['n']; ?></div>
    <div style="font-size:11px;color:var(--muted)"><?php echo $o['p']; ?></div></div>
  </div>
  <div style="display:flex;gap:4px;margin-bottom:8px">
    <span class="sm-pill">구독자 <?php echo $o['sub']; ?></span>
    <span class="sm-pill" style="color:var(--green)">강점</span>
  </div>
  <div style="font-size:11px;margin-bottom:4px">✓ <?php echo $o['pro']; ?></div>
  <div style="font-size:11px;color:var(--muted)">· <?php echo $o['con']; ?></div>
<?php if($ev): ?>
  <div style="margin-top:8px;background:rgba(251,191,36,.06);border:1px solid rgba(251,191,36,.15);border-radius:8px;padding:6px 8px;font-size:10px">
    <span style="color:var(--yellow);font-weight:800">🎁</span> <?php echo $ev['event']; ?>
    <span style="color:var(--muted);font-size:9px">(~<?php echo $ev['expire']; ?>)</span>
  </div>
<?php endif; ?>
</div>
<?php }
?>

<div class="sm-panel" style="text-align:center;padding:28px 20px">
  <h1 style="font-size:clamp(20px,4vw,28px);font-weight:900;margin-bottom:6px">📡 OTT 플랫폼 비교</h1>
  <p style="color:var(--muted);font-size:14px">주요 요금/특징/추천 포인트를 한눈에 비교하세요.</p>
</div>

<div class="sm-ott-cards-top" style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-bottom:16px">
<?php foreach(array_slice($otts,0,5) as $o) ott_card($o, $eventMap[$o['nk']]??null); ?>
</div>
<div class="sm-ott-cards-bottom" style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px">
<?php foreach(array_slice($otts,5) as $o) ott_card($o, $eventMap[$o['nk']]??null); ?>
</div>

<div class="sm-section-header"><h2>📊 플랫폼 상세 비교표</h2></div>
<div class="sm-panel" style="overflow-x:auto;padding:0">
<table class="sm-table" style="min-width:800px">
<thead><tr><th>플랫폼</th><th>대표 요금</th><th>추정 구독자</th><th>강점</th><th>보완점</th></tr></thead>
<tbody>
<?php foreach($otts as $o): ?>
<tr>
<td><div style="display:flex;align-items:center;gap:6px"><img src="<?php echo $o['f']; ?>" style="width:20px;height:20px;border-radius:4px"><strong><?php echo $o['n']; ?></strong></div></td>
<td style="font-size:12px"><?php echo $o['p']; ?></td>
<td style="font-size:12px"><?php echo $o['sub']; ?></td>
<td style="font-size:12px"><?php echo $o['pro']; ?></td>
<td style="font-size:12px;color:var(--muted)"><?php echo $o['con']; ?></td>
</tr>
<?php endforeach; ?>
</tbody></table></div>

<?php if(!empty($events)): ?>
<div class="sm-section-header" style="margin-top:24px"><h2>🎉 현재 할인/이벤트</h2></div>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px;margin-bottom:16px">
<?php foreach($events as $ev): ?>
<a href="<?php echo $ev['url']; ?>" target="_blank" class="sm-panel" style="padding:14px 16px;border-left:3px solid <?php echo $ev['color']; ?>;display:flex;align-items:center;gap:12px;margin-bottom:0">
<img src="<?php echo $ev['logo']; ?>" style="width:36px;height:36px;border-radius:8px;flex-shrink:0">
<div style="flex:1;min-width:0"><div style="font-weight:900;font-size:13px;color:<?php echo $ev['color']; ?>"><?php echo $ev['ott']; ?></div>
<div style="font-size:12px;color:var(--muted);margin-top:2px"><?php echo $ev['event']; ?></div></div>
<span class="sm-pill" style="color:var(--yellow);flex-shrink:0">~<?php echo $ev['expire']; ?></span></a>
<?php endforeach; ?>
</div>
<?php endif; ?>

<style>
@media(max-width:1024px){.sm-ott-cards-top{grid-template-columns:repeat(3,1fr)!important}.sm-ott-cards-bottom{grid-template-columns:repeat(2,1fr)!important}}
@media(max-width:640px){.sm-ott-cards-top{grid-template-columns:1fr 1fr!important}.sm-ott-cards-bottom{grid-template-columns:1fr!important}}
</style>
<?php require_once 'includes/footer.php'; ?>
