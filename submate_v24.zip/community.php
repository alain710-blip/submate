<?php
if (!function_exists('sm_trim_text')) {
  function sm_trim_text($text, $width=100){
    $text=(string)$text;
    if (function_exists('mb_strimwidth')) return mb_strimwidth($text,0,$width,'...','UTF-8');
    return (strlen($text)>$width)?substr($text,0,$width).'...':$text;
  }
}
ini_set("display_errors", 1); error_reporting(E_ALL);
$page_title = '커뮤니티'; require_once __DIR__ . '/includes/header.php'; require_once __DIR__ . '/includes/community.php';
$boards = get_boards();
?>
<div class="sm-panel" style="text-align:center;padding:24px"><h1 style="font-size:24px;font-weight:900">💬 커뮤니티</h1><p style="color:var(--muted)">OTT 이야기를 나눠보세요</p></div>
<?php $canWriteCommunity = is_logged_in(); ?>
<div class="sm-panel" style="margin-bottom:14px">
  <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
    <div style="font-size:13px;font-weight:800">✏️ 커뮤니티 글쓰기</div>
    <div style="display:flex;gap:6px;flex-wrap:wrap">
      <?php if($canWriteCommunity): ?>
        <?php foreach($boards as $bk2 => $b2):
          if ($b2['admin_only'] && !is_admin_user()) continue;
        ?>
        <a href="board.php?b=<?php echo $bk2; ?>&write=1" class="sm-btn sm-btn-sm<?php echo $bk2==='free' ? ' sm-btn-primary' : ''; ?>"><?php echo $b2['icon']; ?> <?php echo $b2['name']; ?></a>
        <?php endforeach; ?>
      <?php else: ?>
        <a href="login.php" class="sm-btn sm-btn-primary sm-btn-sm">로그인 후 글쓰기</a>
      <?php endif; ?>
    </div>
  </div>
</div>
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px">
<?php foreach($boards as $bk => $b): $cnt = count(read_json("board_{$bk}.json")); ?>
<a href="board.php?b=<?php echo $bk; ?>" class="sm-panel" style="text-align:center;padding:20px;transition:transform .2s" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform=''">
<div style="font-size:32px;margin-bottom:6px"><?php echo $b['icon']; ?></div>
<div style="font-weight:900;font-size:14px"><?php echo $b['name']; ?></div>
<div style="font-size:11px;color:var(--muted);margin-top:4px"><?php echo $b['desc']; ?></div>
<div style="margin-top:6px"><span class="sm-pill">글 <?php echo $cnt; ?>개</span>
<?php if($b['points']): ?><span class="sm-pill" style="color:var(--green)">+<?php echo $b['points']; ?>P</span><?php endif; ?>
</div></a>
<?php endforeach; ?>
</div>

<!-- 각 게시판 최신글 -->
<?php foreach($boards as $bk => $b):
  $posts = get_posts($bk, 1, 5);
  if(empty($posts['posts'])) continue;
?>
<div class="sm-panel" style="margin-bottom:12px">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><div class="sm-badge"><span class="dot"></span><?php echo $b['icon']; ?> <?php echo $b['name']; ?></div><a href="board.php?b=<?php echo $bk; ?>" style="font-size:11px;color:var(--accent);font-weight:700">더보기 →</a></div>
<?php foreach($posts['posts'] as $p): ?>
<a href="board.php?b=<?php echo $bk; ?>&view=<?php echo $p['id']; ?>" style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--stroke)">
<span style="font-size:13px;font-weight:700"><?php echo htmlspecialchars(sm_trim_text($p['title']??'',50)); ?></span>
<span style="font-size:10px;color:var(--muted)"><?php echo htmlspecialchars($p['author_name']??''); ?> · <?php echo substr($p['created_at']??'',0,10); ?></span>
</a>
<?php endforeach; ?>
</div>
<?php endforeach; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
