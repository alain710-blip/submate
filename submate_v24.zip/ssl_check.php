<?php
header('Content-Type: text/plain; charset=utf-8');
$https_on = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
            (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443) ||
            ((isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https'));

echo "HTTPS_ON=" . ($https_on ? 'YES' : 'NO') . "\n";
echo "HTTP_HOST=" . ($_SERVER['HTTP_HOST'] ?? '') . "\n";
echo "REQUEST_SCHEME=" . ($_SERVER['REQUEST_SCHEME'] ?? '') . "\n";
echo "SERVER_PORT=" . ($_SERVER['SERVER_PORT'] ?? '') . "\n";
echo "X_FORWARDED_PROTO=" . ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') . "\n";
