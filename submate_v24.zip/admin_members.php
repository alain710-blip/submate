<?php
ini_set("display_errors", 1); error_reporting(E_ALL);
require_once 'includes/subscriptions.php';
require_admin();

// AJAX API 처리
if (isset($_GET['api'])) {
    header('Content-Type: application/json; charset=utf-8');
    $api = $_GET['api'];

    if ($api === 'get_user' && isset($_GET['uid'])) {
        $u = find_user_by_id((int)$_GET['uid']);
        if ($u) { unset($u['password_hash']); echo json_encode($u, JSON_UNESCAPED_UNICODE); }
        else echo json_encode(['error'=>'not found']);
        exit;
    }

    if ($api === 'get_user_logs' && isset($_GET['uid'])) {
        $logs = array_slice(array_reverse(get_access_logs((int)$_GET['uid'])), 0, 20);
        echo json_encode($logs, JSON_UNESCAPED_UNICODE); exit;
    }

    if ($api === 'get_user_subs' && isset($_GET['uid'])) {
        $subs = get_subs((int)$_GET['uid']);
        echo json_encode($subs, JSON_UNESCAPED_UNICODE); exit;
    }

    if ($api === 'device_stats') {
        echo json_encode(get_device_stats(), JSON_UNESCAPED_UNICODE); exit;
    }

    if ($api === 'signup_trend') {
        echo json_encode(get_signup_trend(), JSON_UNESCAPED_UNICODE); exit;
    }

    echo json_encode(['error'=>'unknown']); exit;
}

// POST 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? '';
    $uid = (int)($_POST['uid'] ?? 0);
    $email = $_POST['email'] ?? '';

    // 등급 변경 (원클릭)
    if ($act === 'set_role' && $uid) {
        $role = $_POST['role'] ?? 'user';
        if (in_array($role, ['user','premium','admin'])) update_user_by_id($uid, ['role'=>$role]);
        header('Location: admin_members.php?msg=role_ok'); exit;
    }

    // 상태 변경 (원클릭)
    if ($act === 'set_status' && $uid) {
        $st = $_POST['status'] ?? 'active';
        if (in_array($st, ['active','dormant','suspended'])) update_user_by_id($uid, ['status'=>$st]);
        header('Location: admin_members.php?msg=status_ok'); exit;
    }

    // 프로필 편집 (모달)
    if ($act === 'edit_profile' && $uid) {
        $fields = [];
        if (isset($_POST['name'])) $fields['name'] = trim($_POST['name']);
        if (isset($_POST['phone'])) $fields['phone'] = trim($_POST['phone']);
        if (isset($_POST['memo'])) $fields['memo'] = trim($_POST['memo']);
        if (isset($_POST['role']) && in_array($_POST['role'], ['user','premium','admin'])) $fields['role'] = $_POST['role'];
        if (isset($_POST['status']) && in_array($_POST['status'], ['active','dormant','suspended'])) $fields['status'] = $_POST['status'];
        if (!empty($_POST['new_password'])) $fields['password_hash'] = password_hash($_POST['new_password'], PASSWORD_BCRYPT);
        update_user_by_id($uid, $fields);
        header('Location: admin_members.php?msg=edit_ok'); exit;
    }

    // 회원 삭제
    if ($act === 'delete' && $uid) {
        delete_user_by_id($uid);
        header('Location: admin_members.php?msg=del_ok'); exit;
    }

    // 회원 추가
    if ($act === 'add_user') {
        $name = trim($_POST['name'] ?? '');
        $email_new = trim($_POST['email'] ?? '');
        $pw = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? 'user';
        if ($name && $email_new && $pw) {
            if (!find_user($email_new)) {
                save_user(['name'=>$name, 'email'=>$email_new, 'password_hash'=>password_hash($pw, PASSWORD_BCRYPT), 'role'=>$role, 'phone'=>$_POST['phone']??'', 'memo'=>$_POST['memo']??'']);
            }
        }
        header('Location: admin_members.php?msg=add_ok'); exit;
    }
}

// 목록
$all_users = read_json('users.json');
$search = trim($_GET['q'] ?? '');
$filter_role = $_GET['role'] ?? '';
$filter_status = $_GET['status'] ?? '';
$users = $all_users;
if ($search) $users = array_filter($users, function($u) use($search) { return stripos($u['name']??'', $search) !== false || stripos($u['email']??'', $search) !== false || stripos($u['phone']??'', $search) !== false; });
if ($filter_role) $users = array_filter($users, function($u) use($filter_role) { return ($u['role']??'user') === $filter_role; });
if ($filter_status) $users = array_filter($users, function($u) use($filter_status) { return ($u['status']??'active') === $filter_status; });
$users = array_values($users);
$total = count($all_users);
$admins = count(array_filter($all_users, function($u) { return ($u['role']??'') === 'admin'; }));
$premiums = count(array_filter($all_users, function($u) { return ($u['role']??'') === 'premium'; }));
$normals = $total - $admins - $premiums;
$actives = count(array_filter($all_users, function($u) { return ($u['status']??'active') === 'active'; }));
$dormants = count(array_filter($all_users, function($u) { return ($u['status']??'') === 'dormant'; }));
$suspends = count(array_filter($all_users, function($u) { return ($u['status']??'') === 'suspended'; }));

$page_title = '회원관리'; require_once 'includes/header.php';
?>

<!-- KPI -->
<div class="sm-panel">
  <div class="sm-badge"><span class="dot"></span> 🛡 회원 관리</div>
  <?php
  $msgs = ['role_ok'=>'등급 변경 완료','status_ok'=>'상태 변경 완료','edit_ok'=>'프로필 수정 완료','del_ok'=>'회원 삭제 완료','add_ok'=>'회원 추가 완료'];
  $mk = $_GET['msg'] ?? '';
  if (isset($msgs[$mk])): ?><p style="margin-top:8px;color:var(--green);font-weight:900">✓ <?php echo $msgs[$mk]; ?></p><?php endif; ?>
  <div class="sm-kpi-row" style="margin-top:14px">
    <div class="sm-kpi"><div class="sm-kpi-label">전체 회원</div><div class="sm-kpi-value"><?php echo $total; ?></div></div>
    <div class="sm-kpi"><div class="sm-kpi-label">관리자</div><div class="sm-kpi-value" style="color:var(--red)"><?php echo $admins; ?></div></div>
    <div class="sm-kpi"><div class="sm-kpi-label">프리미엄</div><div class="sm-kpi-value" style="color:var(--accent2)"><?php echo $premiums; ?></div></div>
    <div class="sm-kpi"><div class="sm-kpi-label">일반</div><div class="sm-kpi-value" style="color:var(--accent)"><?php echo $normals; ?></div></div>
  </div>
</div>

<!-- 차트: 등급분포 + 가입추이 + 기기분석 -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;margin-bottom:16px">
  <div class="sm-panel" style="text-align:center"><div class="sm-badge" style="margin-bottom:10px"><span class="dot"></span>등급 분포</div>
    <canvas id="roleChart" height="180"></canvas></div>
  <div class="sm-panel" style="text-align:center"><div class="sm-badge" style="margin-bottom:10px"><span class="dot"></span>가입 추이</div>
    <canvas id="signupChart" height="180"></canvas></div>
  <div class="sm-panel" style="text-align:center"><div class="sm-badge" style="margin-bottom:10px"><span class="dot"></span>기기 분석</div>
    <canvas id="deviceChart" height="180"></canvas></div>
</div>

<!-- 검색 + 필터 + 추가 버튼 -->
<div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;align-items:center">
  <form method="get" style="display:flex;gap:6px;flex:1;min-width:250px">
    <input class="sm-input" name="q" placeholder="이름/이메일/전화번호 검색" value="<?php echo htmlspecialchars($search); ?>" style="max-width:300px">
    <select name="role" class="sm-input" style="width:auto"><option value="">전체등급</option><option value="admin" <?php echo $filter_role==='admin'?'selected':''; ?>>관리자</option><option value="premium" <?php echo $filter_role==='premium'?'selected':''; ?>>프리미엄</option><option value="user" <?php echo $filter_role==='user'?'selected':''; ?>>일반</option></select>
    <select name="status" class="sm-input" style="width:auto"><option value="">전체상태</option><option value="active" <?php echo $filter_status==='active'?'selected':''; ?>>활성</option><option value="dormant" <?php echo $filter_status==='dormant'?'selected':''; ?>>휴면</option><option value="suspended" <?php echo $filter_status==='suspended'?'selected':''; ?>>정지</option></select>
    <button class="sm-btn sm-btn-primary sm-btn-sm">검색</button>
  </form>
  <button class="sm-btn sm-btn-primary sm-btn-sm" onclick="document.getElementById('addModal').style.display='flex'">➕ 회원 추가</button>
</div>

<!-- 회원 테이블 -->
<div class="sm-panel" style="overflow:auto">
<table class="sm-table"><thead><tr><th>회원</th><th>등급</th><th>상태</th><th>접속</th><th>가입일</th><th style="min-width:240px">관리</th></tr></thead><tbody>
<?php foreach($users as $u):
  $rl = $u['role']??'user'; $rc = $rl==='admin'?'var(--red)':($rl==='premium'?'var(--accent2)':'var(--accent)');
  $st = $u['status']??'active'; $sc = $st==='active'?'var(--green)':($st==='dormant'?'var(--yellow)':'var(--red)');
  $sl = $st==='active'?'활성':($st==='dormant'?'휴면':'정지');
?>
<tr>
<td><div style="display:flex;align-items:center;gap:8px;cursor:pointer" onclick="openDetail(<?php echo (int)$u['id']; ?>)">
  <div style="width:34px;height:34px;border-radius:50%;background:<?php echo $rc; ?>;display:flex;align-items:center;justify-content:center;font-weight:900;color:#fff;font-size:13px"><?php echo mb_substr($u['name']??'?',0,1); ?></div>
  <div><div style="font-weight:800"><?php echo htmlspecialchars($u['name']??''); ?></div><div style="font-size:10px;color:var(--muted)"><?php echo htmlspecialchars($u['email']??''); ?></div>
  <?php if($u['phone']??''): ?><div style="font-size:10px;color:var(--muted)"><?php echo htmlspecialchars($u['phone']); ?></div><?php endif; ?>
</div></div></td>
<td>
  <?php if($rl !== 'admin'): ?>
  <div style="display:flex;gap:3px">
    <?php foreach(['user'=>'일반','premium'=>'프리미엄','admin'=>'관리자'] as $rv=>$rn): ?>
    <form method="post" style="display:inline"><input type="hidden" name="action" value="set_role"><input type="hidden" name="uid" value="<?php echo $u['id']; ?>"><input type="hidden" name="role" value="<?php echo $rv; ?>">
    <button class="sm-btn sm-btn-sm" style="<?php echo $rl===$rv?'background:'.($rv==='admin'?'var(--red)':($rv==='premium'?'var(--accent2)':'var(--accent)')).';color:#fff;border:none':''; ?>;padding:3px 7px;font-size:10px"><?php echo $rn; ?></button></form>
    <?php endforeach; ?>
  </div>
  <?php else: ?><span class="sm-pill" style="color:var(--red)">관리자</span><?php endif; ?>
</td>
<td>
  <?php if($rl !== 'admin'): ?>
  <div style="display:flex;gap:3px">
    <?php foreach(['active'=>'활성','dormant'=>'휴면','suspended'=>'정지'] as $sv=>$sn): ?>
    <form method="post" style="display:inline"><input type="hidden" name="action" value="set_status"><input type="hidden" name="uid" value="<?php echo $u['id']; ?>"><input type="hidden" name="status" value="<?php echo $sv; ?>">
    <button class="sm-btn sm-btn-sm" style="<?php echo $st===$sv?'background:'.($sv==='active'?'var(--green)':($sv==='dormant'?'var(--yellow)':'var(--red)')).';color:#fff;border:none':''; ?>;padding:3px 7px;font-size:10px"><?php echo $sn; ?></button></form>
    <?php endforeach; ?>
  </div>
  <?php else: ?><span class="sm-pill" style="color:var(--green)">활성</span><?php endif; ?>
</td>
<td style="font-size:11px;color:var(--muted)"><?php echo (int)($u['login_count']??0); ?>회<br><span style="font-size:9px"><?php echo $u['last_ip']??''; ?></span></td>
<td style="font-size:11px;color:var(--muted)"><?php echo substr($u['created_at']??'',0,10); ?><br><span style="font-size:9px">최근: <?php echo substr($u['last_login']??'',0,10); ?></span></td>
<td>
  <div style="display:flex;gap:4px">
    <button class="sm-btn sm-btn-sm" onclick="openDetail(<?php echo (int)$u['id']; ?>)">📋 상세</button>
    <?php if($rl !== 'admin'): ?>
    <form method="post" style="display:inline" onsubmit="return confirm('정말 삭제하시겠습니까?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="uid" value="<?php echo $u['id']; ?>"><button class="sm-btn sm-btn-sm sm-btn-danger">🗑 삭제</button></form>
    <?php endif; ?>
  </div>
</td>
</tr>
<?php endforeach; ?>
</tbody></table>
<div style="margin-top:10px;font-size:12px;color:var(--muted)">총 <?php echo count($users); ?>명 표시 (전체 <?php echo $total; ?>명)</div>
</div>

<!-- 회원 추가 모달 -->
<div id="addModal" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.6);align-items:center;justify-content:center;padding:20px" onclick="if(event.target===this)this.style.display='none'">
<div class="sm-panel" style="max-width:500px;width:100%;max-height:90vh;overflow:auto">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px"><h3 style="margin:0">➕ 회원 추가</h3><button onclick="document.getElementById('addModal').style.display='none'" style="background:none;border:none;color:var(--text);font-size:20px;cursor:pointer">&times;</button></div>
<form method="post">
<input type="hidden" name="action" value="add_user">
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
<div class="sm-form-group"><label class="sm-label">이름*</label><input name="name" class="sm-input" required></div>
<div class="sm-form-group"><label class="sm-label">이메일*</label><input name="email" type="email" class="sm-input" required></div>
<div class="sm-form-group"><label class="sm-label">비밀번호*</label><input name="password" type="password" class="sm-input" required></div>
<div class="sm-form-group"><label class="sm-label">전화번호</label><input name="phone" class="sm-input"></div>
<div class="sm-form-group"><label class="sm-label">등급</label><select name="role" class="sm-input"><option value="user">일반</option><option value="premium">프리미엄</option><option value="admin">관리자</option></select></div>
</div>
<div class="sm-form-group"><label class="sm-label">메모</label><input name="memo" class="sm-input"></div>
<button type="submit" class="sm-btn sm-btn-primary" style="width:100%">추가</button>
</form></div></div>

<!-- 회원 상세 모달 -->
<div id="detailModal" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.6);align-items:center;justify-content:center;padding:20px" onclick="if(event.target===this)this.style.display='none'">
<div class="sm-panel" style="max-width:700px;width:100%;max-height:90vh;overflow:auto" id="detailContent">로딩중...</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
// 등급 분포 차트
new Chart(document.getElementById('roleChart'), {
    type: 'doughnut',
    data: { labels: ['관리자','프리미엄','일반'], datasets: [{ data: [<?php echo "$admins,$premiums,$normals"; ?>], backgroundColor: ['#f87171','#8b5cf6','#38bdf8'], borderWidth: 0 }] },
    options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { color: '#94a3b8', font: { size: 11 } } } } }
});

// 가입 추이
fetch('?api=signup_trend').then(r=>r.json()).then(d=>{
    new Chart(document.getElementById('signupChart'), {
        type: 'bar',
        data: { labels: Object.keys(d), datasets: [{ label: '가입자', data: Object.values(d), backgroundColor: '#38bdf8', borderRadius: 6 }] },
        options: { responsive: true, scales: { x: { ticks: { color: '#64748b', font: { size: 10 } } }, y: { ticks: { color: '#64748b' }, beginAtZero: true } }, plugins: { legend: { display: false } } }
    });
});

// 기기 분석
fetch('?api=device_stats').then(r=>r.json()).then(d=>{
    var dev = d.device || {}; var labels = Object.keys(dev); var vals = Object.values(dev);
    new Chart(document.getElementById('deviceChart'), {
        type: 'doughnut',
        data: { labels: labels.length ? labels : ['데이터없음'], datasets: [{ data: vals.length ? vals : [1], backgroundColor: ['#38bdf8','#34d399','#fbbf24','#f87171'], borderWidth: 0 }] },
        options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { color: '#94a3b8', font: { size: 11 } } } } }
    });
});

// 회원 상세 모달
function openDetail(uid) {
    document.getElementById('detailModal').style.display = 'flex';
    var c = document.getElementById('detailContent');
    c.innerHTML = '<div style="text-align:center;padding:40px;color:var(--muted)">로딩중...</div>';

    Promise.all([
        fetch('?api=get_user&uid='+uid).then(r=>r.json()),
        fetch('?api=get_user_logs&uid='+uid).then(r=>r.json()),
        fetch('?api=get_user_subs&uid='+uid).then(r=>r.json())
    ]).then(function(res) {
        var u = res[0], logs = res[1], subs = res[2];
        if (u.error) { c.innerHTML = '<p>회원을 찾을 수 없습니다.</p>'; return; }
        var rc = u.role==='admin'?'var(--red)':(u.role==='premium'?'var(--accent2)':'var(--accent)');
        var roles = {'user':'일반','premium':'프리미엄','admin':'관리자'};
        var stats = {'active':'활성','dormant':'휴면','suspended':'정지'};
        var isAdmin = u.role === 'admin';
        var html = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px"><h3 style="margin:0">📋 회원 상세</h3><button onclick="document.getElementById(\'detailModal\').style.display=\'none\'" style="background:none;border:none;color:var(--text);font-size:20px;cursor:pointer">&times;</button></div>';

        // 프로필
        html += '<div style="display:flex;align-items:center;gap:14px;margin-bottom:16px"><div style="width:50px;height:50px;border-radius:50%;background:'+rc+';display:flex;align-items:center;justify-content:center;font-weight:900;color:#fff;font-size:20px">'+(u.name||'?').substring(0,1)+'</div>';
        html += '<div><div style="font-weight:900;font-size:16px">'+(u.name||'')+'</div><div style="font-size:12px;color:var(--muted)">'+(u.email||'')+'</div>';
        if(u.phone) html += '<div style="font-size:12px;color:var(--muted)">📞 '+u.phone+'</div>';
        html += '</div></div>';

        // 편집 폼
        html += '<form method="post" style="margin-bottom:16px"><input type="hidden" name="action" value="edit_profile"><input type="hidden" name="uid" value="'+u.id+'">';
        html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">';
        html += '<div class="sm-form-group"><label class="sm-label">이름</label><input name="name" class="sm-input" value="'+(u.name||'')+'"></div>';
        html += '<div class="sm-form-group"><label class="sm-label">전화번호</label><input name="phone" class="sm-input" value="'+(u.phone||'')+'"></div>';
        if(!isAdmin) {
            html += '<div class="sm-form-group"><label class="sm-label">등급</label><select name="role" class="sm-input">';
            for(var rk in roles) html += '<option value="'+rk+'"'+(u.role===rk?' selected':'')+'>'+roles[rk]+'</option>';
            html += '</select></div>';
            html += '<div class="sm-form-group"><label class="sm-label">상태</label><select name="status" class="sm-input">';
            for(var sk in stats) html += '<option value="'+sk+'"'+(u.status===sk?' selected':'')+'>'+stats[sk]+'</option>';
            html += '</select></div>';
        }
        html += '<div class="sm-form-group"><label class="sm-label">새 비밀번호 (변경시)</label><input name="new_password" type="password" class="sm-input" placeholder="비워두면 유지"></div>';
        html += '</div>';
        html += '<div class="sm-form-group"><label class="sm-label">관리자 메모</label><input name="memo" class="sm-input" value="'+(u.memo||'')+'"></div>';
        html += '<div style="display:flex;gap:8px"><button type="submit" class="sm-btn sm-btn-primary sm-btn-sm">저장</button>';
        if(!isAdmin) html += '<button type="button" class="sm-btn sm-btn-sm sm-btn-danger" onclick="if(confirm(\'삭제?\')){{var f=document.createElement(\'form\');f.method=\'post\';f.innerHTML=\'<input name=action value=delete><input name=uid value='+u.id+'>\';document.body.appendChild(f);f.submit();}}">삭제</button>';
        html += '</div></form>';

        // 정보
        html += '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:14px">';
        html += '<div style="background:var(--panel);border:1px solid var(--stroke);border-radius:12px;padding:10px"><div style="font-size:10px;color:#64748b">가입일</div><div style="font-weight:800;font-size:12px">'+(u.created_at||'').substring(0,10)+'</div></div>';
        html += '<div style="background:var(--panel);border:1px solid var(--stroke);border-radius:12px;padding:10px"><div style="font-size:10px;color:#64748b">최근로그인</div><div style="font-weight:800;font-size:12px">'+(u.last_login||'').substring(0,10)+'</div></div>';
        html += '<div style="background:var(--panel);border:1px solid var(--stroke);border-radius:12px;padding:10px"><div style="font-size:10px;color:#64748b">접속횟수</div><div style="font-weight:800;font-size:12px">'+(u.login_count||0)+'회</div></div>';
        html += '</div>';

        // 구독
        if(subs.length) {
            html += '<div style="margin-bottom:12px"><div class="sm-badge" style="margin-bottom:8px"><span class="dot"></span>구독 '+subs.length+'건</div>';
            subs.forEach(function(s) { html += '<div style="background:var(--panel);border:1px solid var(--stroke);border-radius:10px;padding:8px 12px;margin-bottom:4px;display:flex;justify-content:space-between;font-size:12px"><span style="font-weight:800">'+(s.platform||'')+'</span><span>'+Number(s.cost||0).toLocaleString()+'원/'+(s.cycle==='yearly'?'년':'월')+'</span></div>'; });
            html += '</div>';
        }

        // 접속 로그
        if(logs.length) {
            html += '<div><div class="sm-badge" style="margin-bottom:8px"><span class="dot"></span>최근 접속 기록</div>';
            html += '<div style="max-height:200px;overflow:auto">';
            logs.forEach(function(l) { html += '<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--stroke);font-size:11px;color:var(--muted)"><span>'+l.device+' · '+l.browser+' · '+l.os+'</span><span>'+l.ip+' · '+(l.time||'').substring(0,16)+'</span></div>'; });
            html += '</div></div>';
        }

        c.innerHTML = html;
    });
}
</script>
<?php require_once 'includes/footer.php'; ?>
