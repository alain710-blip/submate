SubMate PRO v10 - 독립형 OTT 구독관리 웹앱
===========================================

[설치]
1. 전체 파일을 웹서버 루트에 업로드
2. config/tmdb.php 에서 TMDB API 키 확인
3. data/ 폴더 쓰기 권한 설정 (755)
4. 브라우저에서 index.php 접속

[기본 관리자 계정]
이메일: admin@submate.kr
비밀번호: password

[요구사항]
- PHP 7.4+
- cURL 확장
- TMDB API 키

[파일 구조]
index.php          메인 (히어로+트렌딩+OTT플랫폼별 콘텐츠)
movie.php          작품 상세 (예고편, 출연진, OTT제공처)
search.php         콘텐츠 검색
trending.php       트렌딩 전체보기
mypage.php         구독관리 CRUD
ott_info.php       OTT 플랫폼 비교
match.php          OTT 매칭
login.php          로그인
register.php       회원가입
admin_dashboard.php 관리자 대시보드
admin_members.php   회원관리
