<?php
ini_set("display_errors", 1); error_reporting(E_ALL);
require_once 'includes/auth.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? ''); $pw = $_POST['password'] ?? ''; $pw2 = $_POST['password2'] ?? '';
    if (!$name || !$email || !$pw) $err = '모든 필드를 입력하세요.';
    elseif (strlen($pw) < 6) $err = '비밀번호 6자 이상';
    elseif ($pw !== $pw2) $err = '비밀번호 불일치';
    elseif (find_user($email)) $err = '이미 등록된 이메일';
    else { $id = save_user(['name'=>$name,'email'=>$email,'password_hash'=>password_hash($pw, PASSWORD_BCRYPT)]); $_SESSION['user'] = ['id'=>$id,'email'=>$email,'name'=>$name,'role'=>'user']; header('Location: index.php'); exit; }
}
$page_title = '회원가입'; require_once 'includes/header.php';
?>
<div class="sm-login-wrap"><div class="sm-login-card">
<h1 style="font-size:24px;font-weight:900;text-align:center;margin-bottom:20px"><span style="color:var(--accent)">Sub</span>Mate 회원가입</h1>
<?php if($err): ?><div class="sm-alert sm-alert-danger"><?php echo $err; ?></div><?php endif; ?>
<form method="post">
<div class="sm-form-group"><label class="sm-label">이름</label><input name="name" class="sm-input" required></div>
<div class="sm-form-group"><label class="sm-label">이메일</label><input name="email" type="email" class="sm-input" required></div>
<div class="sm-form-group"><label class="sm-label">비밀번호(6자이상)</label><input name="password" type="password" class="sm-input" required></div>
<div class="sm-form-group"><label class="sm-label">비밀번호 확인</label><input name="password2" type="password" class="sm-input" required></div>
<button type="submit" class="sm-btn sm-btn-primary" style="width:100%;padding:14px">가입하기</button>
</form><p style="margin-top:14px;text-align:center;font-size:13px;color:var(--muted)"><a href="login.php" style="color:var(--accent)">로그인</a></p>
</div></div>
<?php require_once 'includes/footer.php'; ?>
